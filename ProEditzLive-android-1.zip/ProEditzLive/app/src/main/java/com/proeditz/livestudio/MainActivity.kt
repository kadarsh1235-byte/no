package com.proeditz.livestudio

import android.Manifest
import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.animation.ValueAnimator
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.AdapterView
import android.widget.SeekBar
import android.widget.Toast
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.google.android.gms.auth.api.identity.Identity
import com.google.android.material.tabs.TabLayout
import com.proeditz.livestudio.databinding.ActivityMainBinding
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream

class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding
    private lateinit var prefs: SharedPreferences

    private val music = mutableListOf<String>()
    private val videos = mutableListOf<String>()
    private var thumb: String? = null
    private var channel: String? = null
    private var thumbBg: Bitmap? = null
    private var pulse: ObjectAnimator? = null

    private var ideaIndex = 0
    private var ideaTitles: List<String> = emptyList()
    private var ideaTags = ""
    private var ideaDesc = ""

    private val privacyValues = listOf("public", "unlisted", "private")
    private val qualities = listOf(480 to 2000, 720 to 4000, 1080 to 6000) // height to kbps
    private val tileSizes = listOf("small", "medium", "large", "half")
    private val thumbColors = listOf(0xFF00F0FF.toInt(), 0xFFFF2BD6.toInt(), 0xFFFFE600.toInt(), 0xFF39FF88.toInt())

    // ---------- activity result launchers ----------
    private val authLauncher = registerForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { res ->
        try {
            Identity.getAuthorizationClient(this).getAuthorizationResultFromIntent(res.data)
            loadChannel()
        } catch (e: Exception) {
            toast("Sign-in was cancelled.")
        }
    }

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        if (hasMic()) askScreenCapture()
        else toast("Allow the microphone permission. It is needed to capture game sound.")
    }

    private val projectionLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        val data = res.data
        if (res.resultCode == RESULT_OK && data != null) {
            Live.set("creating", "Creating your YouTube broadcast...")
            StreamService.start(this, buildConfig(), res.resultCode, data)
            if (b.swVideo.isChecked) {
                startActivity(
                    Intent(this, PlayerActivity::class.java)
                        .putStringArrayListExtra("videos", ArrayList(videos))
                        .putExtra("portrait", b.swPortrait.isChecked)
                )
            }
        } else {
            toast("Screen sharing was not allowed.")
        }
    }

    private val musicPicker = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        uris.forEach {
            runCatching { contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            music.add(it.toString())
        }
        refresh(); save()
    }

    private val videoPicker = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        uris.forEach {
            runCatching { contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            videos.add(it.toString())
        }
        refresh(); save()
    }

    private val thumbPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            runCatching { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            thumb = uri.toString()
            refresh(); save()
        }
    }

    private val thumbBgPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            loadThumbBg(uri)
            renderThumbPreview()
        }
    }

    private val tileVideoPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            runCatching { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            overlay(OverlayService.A_TILE) {
                putExtra("type", "video")
                putExtra("uri", uri.toString())
                putExtra("size", tileSizeKey())
            }
        }
    }

    private val tileImagePicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            runCatching { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            overlay(OverlayService.A_TILE) {
                putExtra("type", "image")
                putExtra("uri", uri.toString())
                putExtra("size", tileSizeKey())
            }
        }
    }

    private val overlayPermLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        OverlayService.start(this)
    }

    private val camPermLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) toast("Camera allowed. Tap Stop floating tools, then Start floating tools, then add the face cam box.")
        else toast("The camera permission is needed for the face cam box.")
    }

    // ---------- lifecycle ----------
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)
        ViewCompat.setOnApplyWindowInsetsListener(b.root) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(0, bars.top, 0, bars.bottom)
            insets
        }
        prefs = getSharedPreferences("ui", MODE_PRIVATE)
        restore()
        setupTabs()

        b.btnSignIn.setOnClickListener { if (channel == null) signIn() else signOut() }
        b.btnLive.setOnClickListener { onLiveClicked() }
        b.btnOpen.setOnClickListener {
            val url = Live.state.value.url
            if (url.isNotEmpty()) startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        }
        b.btnMusic.setOnClickListener { musicPicker.launch(arrayOf("audio/*")) }
        b.btnClearMusic.setOnClickListener { music.clear(); refresh(); save() }
        b.btnVideos.setOnClickListener { videoPicker.launch(arrayOf("video/*")) }
        b.btnClearVideos.setOnClickListener { videos.clear(); refresh(); save() }
        b.swVideo.setOnCheckedChangeListener { _, _ -> save() }
        b.btnThumb.setOnClickListener { thumbPicker.launch(arrayOf("image/*")) }
        b.sbVolume.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { refresh() }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) { save() }
        })

        // Studio
        b.btnOverlay.setOnClickListener { toggleOverlay() }
        b.btnAddCam.setOnClickListener { addCameraTile() }
        b.btnAddVideoTile.setOnClickListener { if (overlayOn()) tileVideoPicker.launch(arrayOf("video/*")) }
        b.btnAddImageTile.setOnClickListener { if (overlayOn()) tileImagePicker.launch(arrayOf("image/*")) }
        b.btnClearTiles.setOnClickListener { overlay(OverlayService.A_CLEAR) }
        b.btnFxConfetti.setOnClickListener { overlay(OverlayService.A_FX) { putExtra("fx", "confetti") } }
        b.btnFxHearts.setOnClickListener { overlay(OverlayService.A_FX) { putExtra("fx", "hearts") } }
        b.btnFxSub.setOnClickListener { overlay(OverlayService.A_FX) { putExtra("fx", "sub") } }
        b.btnFxFlash.setOnClickListener { overlay(OverlayService.A_FX) { putExtra("fx", "flash") } }
        b.btnBrb.setOnClickListener { overlay(OverlayService.A_BRB) }
        b.swReadChat.setOnCheckedChangeListener { btn, on ->
            if (btn.isPressed) overlay(OverlayService.A_READ) { putExtra("on", on) }
        }

        // Tools
        b.btnThumbBg.setOnClickListener { thumbBgPicker.launch(arrayOf("image/*")) }
        b.btnMakeThumb.setOnClickListener { makeAndUseThumbnail() }
        b.etThumbText.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b4: Int, c: Int) { renderThumbPreview() }
            override fun afterTextChanged(s: Editable?) {}
        })
        b.spThumbStyle.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) { renderThumbPreview() }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        b.btnIdeas.setOnClickListener { makeIdeas() }
        b.btnApplyIdea.setOnClickListener { applyIdea() }

        refresh()
        renderOverlay()
        renderThumbPreview()
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch { Live.state.collect { render(it) } }
                launch { OverlayState.running.collect { renderOverlay() } }
                launch { OverlayState.tiles.collect { renderOverlay() } }
                launch {
                    while (true) {
                        val s = Live.state.value
                        if (s.phase == "live" && s.since > 0) b.tvTimer.text = hms((System.currentTimeMillis() - s.since) / 1000)
                        delay(500)
                    }
                }
            }
        }
    }

    override fun onPause() { super.onPause(); save() }

    private fun setupTabs() {
        val pages = listOf(b.pageLive, b.pageStudio, b.pageTools, b.pageAbout)
        listOf("Live", "Studio", "Tools", "About").forEach { b.tabs.addTab(b.tabs.newTab().setText(it)) }
        b.tabs.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab) {
                pages.forEachIndexed { i, v -> v.visibility = if (i == tab.position) View.VISIBLE else View.GONE }
            }
            override fun onTabUnselected(tab: TabLayout.Tab) {}
            override fun onTabReselected(tab: TabLayout.Tab) {}
        })
    }

    // ---------- account ----------
    private fun signIn() {
        lifecycleScope.launch {
            try {
                val r = Auth.authorize(this@MainActivity)
                if (r.hasResolution()) {
                    authLauncher.launch(IntentSenderRequest.Builder(r.pendingIntent!!.intentSender).build())
                } else {
                    loadChannel()
                }
            } catch (e: Exception) {
                toast("Sign-in failed: ${e.message}")
            }
        }
    }

    private fun loadChannel() {
        lifecycleScope.launch {
            try {
                val name = YouTubeApi.myChannel(this@MainActivity)
                if (name == null) toast("This Google account has no YouTube channel yet.")
                setChannel(name)
            } catch (e: Exception) {
                toast(e.message ?: "Could not reach YouTube.")
                setChannel(null)
            }
        }
    }

    private fun signOut() {
        lifecycleScope.launch {
            Auth.signOut(this@MainActivity)
            setChannel(null)
        }
    }

    private fun setChannel(name: String?) {
        channel = name
        prefs.edit().putString("channel", name).apply()
        b.tvAccount.text = name?.let { "Signed in as $it" } ?: "Not signed in"
        b.btnSignIn.text = if (name == null) "Sign in with Google" else "Sign out"
    }

    // ---------- go live ----------
    private fun onLiveClicked() {
        when (Live.state.value.phase) {
            "idle", "error" -> startFlow()
            else -> StreamService.stop(this)
        }
    }

    private fun startFlow() {
        if (channel == null) return toast("Sign in with Google first.")
        if (b.etTitle.text.isNullOrBlank()) return toast("Add a stream title.")
        if (b.swVideo.isChecked && videos.isEmpty()) return toast("Choose at least one video first.")
        save()
        val need = mutableListOf<String>()
        if (!hasMic()) need += Manifest.permission.RECORD_AUDIO
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) need += Manifest.permission.POST_NOTIFICATIONS
        if (need.isEmpty()) askScreenCapture() else permLauncher.launch(need.toTypedArray())
    }

    private fun hasMic() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun hasCamera() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED

    private fun askScreenCapture() {
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projectionLauncher.launch(mpm.createScreenCaptureIntent())
    }

    private fun buildConfig(): Config {
        val (height, kbps) = qualities[b.spQuality.selectedItemPosition.coerceIn(0, 2)]
        return Config(
            title = b.etTitle.text.toString().trim(),
            description = b.etDescription.text.toString(),
            tags = b.etTags.text.toString(),
            privacy = privacyValues[b.spPrivacy.selectedItemPosition.coerceIn(0, 2)],
            thumbUri = thumb,
            height = height,
            bitrateKbps = kbps,
            portrait = b.swPortrait.isChecked,
            mic = b.swMic.isChecked,
            music = music.toList(),
            musicVolume = b.sbVolume.progress,
            shuffle = b.swShuffle.isChecked,
        )
    }

    // ---------- studio (floating tools) ----------
    private fun overlayOn(): Boolean {
        if (!OverlayState.running.value) {
            toast("Start floating tools first.")
            return false
        }
        return true
    }

    private fun overlay(action: String, extra: Intent.() -> Unit = {}) {
        if (!overlayOn()) return
        OverlayService.send(this, action, extra)
    }

    private fun tileSizeKey() = tileSizes[b.spTileSize.selectedItemPosition.coerceIn(0, tileSizes.size - 1)]

    private fun toggleOverlay() {
        if (OverlayState.running.value) {
            OverlayService.send(this, OverlayService.A_STOP)
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            toast("Turn on Display over other apps for Pro Editz Live, come back, and tap again.")
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        val need = mutableListOf<String>()
        if (!hasCamera()) need += Manifest.permission.CAMERA
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) need += Manifest.permission.POST_NOTIFICATIONS
        if (need.isEmpty()) OverlayService.start(this) else overlayPermLauncher.launch(need.toTypedArray())
    }

    private fun addCameraTile() {
        if (!overlayOn()) return
        if (!hasCamera()) {
            camPermLauncher.launch(Manifest.permission.CAMERA)
            return
        }
        overlay(OverlayService.A_TILE) {
            putExtra("type", "camera")
            putExtra("size", tileSizeKey())
            putExtra("circle", b.swCamCircle.isChecked)
        }
    }

    private fun renderOverlay() {
        val on = OverlayState.running.value
        b.btnOverlay.text = if (on) "Stop floating tools" else "Start floating tools"
        b.tvOverlayState.text = if (on) "Floating tools are ON. Tap the neon bubble on your screen."
        else "Floating tools are OFF."
        b.tvTileCount.text = "Tiles on screen: ${OverlayState.tiles.value} / 10"
    }

    // ---------- tools: thumbnail maker ----------
    private fun loadThumbBg(uri: Uri) {
        thumbBg = runCatching {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            val opts = BitmapFactory.Options().apply { inSampleSize = maxOf(1, bounds.outWidth / 1600) }
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
        }.getOrNull()
        if (thumbBg == null) toast("Could not open that picture.")
    }

    private fun makeThumbnail(): Bitmap {
        val w = 1280
        val h = 720
        val neon = thumbColors[b.spThumbStyle.selectedItemPosition.coerceIn(0, thumbColors.size - 1)]
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)

        val bg = thumbBg
        if (bg != null) {
            val s = maxOf(w / bg.width.toFloat(), h / bg.height.toFloat())
            val dw = bg.width * s
            val dh = bg.height * s
            c.drawBitmap(bg, null, RectF((w - dw) / 2, (h - dh) / 2, (w + dw) / 2, (h + dh) / 2), Paint(Paint.FILTER_BITMAP_FLAG))
            c.drawColor(0x66000000)
        } else {
            val p = Paint()
            p.shader = LinearGradient(
                0f, 0f, w.toFloat(), h.toFloat(),
                intArrayOf(0xFF1B0B3A.toInt(), 0xFF0A2A5E.toInt(), 0xFF3A0B3A.toInt()), null, Shader.TileMode.CLAMP,
            )
            c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p)
        }

        val text = b.etThumbText.text.toString().ifBlank { "LIVE NOW" }.uppercase()
        val tp = TextPaint(Paint.ANTI_ALIAS_FLAG)
        tp.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        tp.color = Color.WHITE
        tp.setShadowLayer(40f, 0f, 0f, neon)
        var size = 150f
        fun build(): StaticLayout {
            tp.textSize = size
            return StaticLayout.Builder.obtain(text, 0, text.length, tp, w - 200)
                .setAlignment(Layout.Alignment.ALIGN_CENTER).build()
        }
        var layout = build()
        while (layout.height > h - 260 && size > 50f) {
            size -= 8f
            layout = build()
        }
        c.save()
        c.translate(100f, (h - layout.height) / 2f - 30f)
        layout.draw(c)
        c.restore()

        val border = Paint(Paint.ANTI_ALIAS_FLAG)
        border.style = Paint.Style.STROKE
        border.strokeWidth = 14f
        border.color = neon
        border.setShadowLayer(30f, 0f, 0f, neon)
        c.drawRoundRect(RectF(24f, 24f, w - 24f, h - 24f), 40f, 40f, border)

        val np = TextPaint(Paint.ANTI_ALIAS_FLAG)
        np.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        np.textSize = 48f
        np.color = Color.WHITE
        np.textAlign = Paint.Align.CENTER
        np.setShadowLayer(20f, 0f, 0f, neon)
        c.drawText("PRO EDITZ NEW", w / 2f, h - 60f, np)
        return bmp
    }

    private fun renderThumbPreview() {
        b.ivThumbPreview.setImageBitmap(makeThumbnail())
    }

    private fun makeAndUseThumbnail() {
        try {
            val bmp = makeThumbnail()
            val f = File(filesDir, "made_thumbnail.jpg")
            FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.JPEG, 92, it) }
            thumb = Uri.fromFile(f).toString()
            refresh(); save()
            toast("Thumbnail ready. It is used for your next stream.")
        } catch (e: Exception) {
            toast("Could not save the thumbnail: ${e.message}")
        }
    }

    // ---------- tools: smart ideas ----------
    private fun makeIdeas() {
        val topic = b.etTopic.text.toString().trim()
        if (topic.isEmpty()) return toast("Type your game or topic first.")
        val words = topic.split(" ").filter { it.isNotBlank() }
        val pretty = words.joinToString(" ") { w -> w.replaceFirstChar { c -> c.uppercase() } }
        ideaTitles = listOf(
            "🔴 LIVE: $pretty | Pro Editz NEW",
            "$pretty LIVE - Come Hang Out! 🔥",
            "Playing $pretty LIVE With You (Join the Chat!)",
            "$pretty Challenge LIVE | Can I Win?",
            "Late Night $pretty Stream | Pro Editz NEW",
        )
        ideaTags = (listOf(topic, "$topic live", "$topic gameplay", "live stream", "gaming live", "Pro Editz NEW") +
            words.map { it.lowercase() }).distinct().joinToString(", ")
        val hashtag = words.joinToString("") { w -> w.replaceFirstChar { c -> c.uppercase() } }
        ideaDesc = "Live now: $pretty on Pro Editz NEW!\n\n" +
            "Like, subscribe and turn on the bell so you never miss a stream.\n" +
            "Drop your questions in the live chat.\n\n#$hashtag #Live #ProEditzNEW"
        ideaIndex = 0
        b.tvIdeas.text = ideaTitles.mapIndexed { i, s -> "${i + 1}. $s" }.joinToString("\n") + "\n\nTags:\n$ideaTags"
    }

    private fun applyIdea() {
        if (ideaTitles.isEmpty()) return toast("Tap Get ideas first.")
        b.etTitle.setText(ideaTitles[ideaIndex % ideaTitles.size])
        ideaIndex++
        b.etTags.setText(ideaTags)
        b.etDescription.setText(ideaDesc)
        save()
        toast("Idea applied. Check the Live tab.")
    }

    // ---------- UI ----------
    private val phaseLabel = mapOf(
        "idle" to "Off air", "creating" to "Getting ready", "starting" to "Getting ready",
        "waiting" to "Connecting", "live" to "ON AIR", "ending" to "Ending", "error" to "Problem",
    )

    private fun setPulse(on: Boolean) {
        if (on && pulse == null) {
            val a = ObjectAnimator.ofPropertyValuesHolder(
                b.btnLive,
                PropertyValuesHolder.ofFloat("scaleX", 1f, 1.04f),
                PropertyValuesHolder.ofFloat("scaleY", 1f, 1.04f),
            )
            a.duration = 700L
            a.repeatCount = ValueAnimator.INFINITE
            a.repeatMode = ValueAnimator.REVERSE
            a.start()
            pulse = a
        } else if (!on) {
            pulse?.cancel()
            pulse = null
            b.btnLive.scaleX = 1f
            b.btnLive.scaleY = 1f
        }
    }

    private fun render(s: Live.State) {
        b.tvPhase.text = phaseLabel[s.phase] ?: s.phase
        b.tvPhase.setTextColor(ContextCompat.getColor(this, if (s.phase == "live") R.color.air else R.color.muted))
        b.tvStatus.text = s.text
        val running = s.phase in listOf("creating", "starting", "waiting", "live", "ending")
        b.btnLive.text = when {
            s.phase == "ending" -> "Ending..."
            running -> "END STREAM"
            else -> "GO LIVE"
        }
        b.btnLive.isEnabled = s.phase !in listOf("creating", "starting", "ending")
        b.btnOpen.visibility = if (running && s.url.isNotEmpty()) View.VISIBLE else View.GONE
        if (!running) b.tvTimer.text = "00:00:00"
        setPulse(s.phase == "live")
    }

    private fun refresh() {
        b.tvVolume.text = "Music volume ${b.sbVolume.progress}%"
        b.tvMusic.text = if (music.isEmpty()) "No music added. Songs you add play in a loop."
        else "${music.size} song${if (music.size == 1) "" else "s"} will loop: " +
            music.take(3).joinToString(", ") { Uri.parse(it).lastPathSegment?.substringAfterLast('/') ?: "track" } +
            if (music.size > 3) "..." else ""
        b.btnClearMusic.visibility = if (music.isEmpty()) View.GONE else View.VISIBLE
        b.tvVideos.text = if (videos.isEmpty()) "No videos chosen. Your videos play full screen in the app and loop."
        else "${videos.size} video${if (videos.size == 1) "" else "s"} will loop: " +
            videos.take(3).joinToString(", ") { Uri.parse(it).lastPathSegment?.substringAfterLast('/') ?: "video" } +
            if (videos.size > 3) "..." else ""
        b.btnClearVideos.visibility = if (videos.isEmpty()) View.GONE else View.VISIBLE
        b.tvThumb.text = thumb?.let { Uri.parse(it).lastPathSegment?.substringAfterLast('/') ?: "Thumbnail chosen" } ?: "No thumbnail"
    }

    // ---------- saved settings ----------
    private fun save() {
        prefs.edit()
            .putString("title", b.etTitle.text.toString())
            .putString("description", b.etDescription.text.toString())
            .putString("tags", b.etTags.text.toString())
            .putInt("privacy", b.spPrivacy.selectedItemPosition)
            .putInt("quality", b.spQuality.selectedItemPosition)
            .putBoolean("portrait", b.swPortrait.isChecked)
            .putBoolean("mic", b.swMic.isChecked)
            .putBoolean("shuffle", b.swShuffle.isChecked)
            .putInt("volume", b.sbVolume.progress)
            .putString("thumb", thumb)
            .putString("music", music.joinToString("\n"))
            .putBoolean("videoMode", b.swVideo.isChecked)
            .putString("videos", videos.joinToString("\n"))
            .apply()
    }

    private fun restore() {
        b.etTitle.setText(prefs.getString("title", "Pro Editz NEW | Live"))
        b.etDescription.setText(prefs.getString("description", "Live on Pro Editz NEW. Like, subscribe and turn on notifications!"))
        b.etTags.setText(prefs.getString("tags", "Pro Editz NEW, live, gaming"))
        b.spPrivacy.setSelection(prefs.getInt("privacy", 0))
        b.spQuality.setSelection(prefs.getInt("quality", 1))
        b.swPortrait.isChecked = prefs.getBoolean("portrait", false)
        b.swMic.isChecked = prefs.getBoolean("mic", false)
        b.swShuffle.isChecked = prefs.getBoolean("shuffle", false)
        b.sbVolume.progress = prefs.getInt("volume", 25)
        b.swVideo.isChecked = prefs.getBoolean("videoMode", false)
        videos.clear()
        prefs.getString("videos", "")?.split("\n")?.filter { it.isNotBlank() }?.let { videos.addAll(it) }
        thumb = prefs.getString("thumb", null)
        music.clear()
        prefs.getString("music", "")?.split("\n")?.filter { it.isNotBlank() }?.let { music.addAll(it) }
        setChannel(prefs.getString("channel", null))
    }

    private fun hms(sec: Long) = "%02d:%02d:%02d".format(sec / 3600, (sec / 60) % 60, sec % 60)
    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()
}
