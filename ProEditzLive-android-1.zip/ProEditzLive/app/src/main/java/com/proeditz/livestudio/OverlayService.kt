package com.proeditz.livestudio

import android.Manifest
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Outline
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioAttributes
import android.net.Uri
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import android.widget.VideoView
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.URL
import java.util.Locale
import kotlin.math.abs

/**
 * Floating studio tools that sit on top of your game. Because the app streams the whole screen,
 * everything shown here (bubble, bar, face cam, tiles, effects, pause screen) is part of the stream.
 */
class OverlayService : LifecycleService() {

    companion object {
        const val A_SHOW = "com.proeditz.livestudio.OVERLAY_SHOW"
        const val A_STOP = "com.proeditz.livestudio.OVERLAY_STOP"
        const val A_TILE = "com.proeditz.livestudio.OVERLAY_TILE"
        const val A_CLEAR = "com.proeditz.livestudio.OVERLAY_CLEAR"
        const val A_FX = "com.proeditz.livestudio.OVERLAY_FX"
        const val A_BRB = "com.proeditz.livestudio.OVERLAY_BRB"
        const val A_READ = "com.proeditz.livestudio.OVERLAY_READ"

        private const val CHANNEL = "overlay"
        private const val NOTIF_ID = 8
        private const val MAX_TILES = 10

        private val CYAN = 0xFF00F0FF.toInt()
        private val PINK = 0xFFFF2BD6.toInt()
        private val VIOLET = 0xFF8F5BFF.toInt()
        private val GREEN = 0xFF39FF88.toInt()
        private val PANEL = 0xFF12142A.toInt()

        fun start(ctx: Context) {
            ContextCompat.startForegroundService(ctx, Intent(ctx, OverlayService::class.java).setAction(A_SHOW))
        }

        fun send(ctx: Context, action: String, extra: Intent.() -> Unit = {}) {
            if (!OverlayState.running.value) return
            ctx.startService(Intent(ctx, OverlayService::class.java).setAction(action).apply(extra))
        }
    }

    private lateinit var wm: WindowManager
    private var density = 1f
    private var running = false

    private var bubble: FrameLayout? = null
    private var bar: LinearLayout? = null
    private var fx: FrameLayout? = null
    private var brb: View? = null
    private var fxRow: View? = null
    private var avatarView: ImageView? = null
    private var tvLikes: TextView? = null
    private var tvSubs: TextView? = null
    private var tvViewers: TextView? = null
    private var tvComment: TextView? = null
    private var chipRead: TextView? = null

    private val tiles = mutableListOf<FrameLayout>()
    private var camTile: FrameLayout? = null

    private var statsJob: Job? = null
    private var chatJob: Job? = null
    private var tts: TextToSpeech? = null
    private var readChat = false
    private var channelName = "Pro Editz NEW"
    private var avatarLoaded = false

    private val circleOutline = object : ViewOutlineProvider() {
        override fun getOutline(view: View, outline: Outline) {
            outline.setOval(0, 0, view.width, view.height)
        }
    }

    private fun roundOutline(radius: Int) = object : ViewOutlineProvider() {
        override fun getOutline(view: View, outline: Outline) {
            outline.setRoundRect(0, 0, view.width, view.height, radius.toFloat())
        }
    }

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        density = resources.displayMetrics.density
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        val cmd = intent ?: return START_NOT_STICKY
        when (cmd.action) {
            A_SHOW -> show()
            A_STOP -> shutdown()
            A_TILE -> if (running) {
                addTile(
                    cmd.getStringExtra("type") ?: "",
                    cmd.getStringExtra("uri"),
                    cmd.getStringExtra("size") ?: "medium",
                    cmd.getBooleanExtra("circle", false),
                )
            }
            A_CLEAR -> clearTiles()
            A_FX -> if (running) runFx(cmd.getStringExtra("fx") ?: "")
            A_BRB -> if (running) toggleBrb()
            A_READ -> if (running) setReadChat(cmd.getBooleanExtra("on", false))
        }
        return START_NOT_STICKY
    }

    // ---------------------------------------------------------------- setup

    private fun dp(v: Int): Int = (v * density).toInt()

    private fun show() {
        startForegroundCompat()
        if (running) return
        if (!Settings.canDrawOverlays(this)) {
            toast("Allow Display over other apps for Pro Editz Live first.")
            stopSelf()
            return
        }
        running = true
        OverlayState.running.value = true
        buildFxLayer()
        buildBar()
        buildBubble()
        startStats()
    }

    private fun startForegroundCompat() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Floating tools", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(
            this, 3, Intent(this, OverlayService::class.java).setAction(A_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val n = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("Pro Editz floating tools")
            .setContentText("Tap the neon bubble on your screen to open the tools")
            .setOngoing(true)
            .addAction(0, "Close tools", stop)
            .build()
        val cam = ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        val type = if (cam) ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA else ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
        ServiceCompat.startForeground(this, NOTIF_ID, n, type)
    }

    private fun params(w: Int, h: Int, touchable: Boolean = true): WindowManager.LayoutParams {
        var flags = WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        if (!touchable) flags = flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        val p = WindowManager.LayoutParams(
            w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, flags, PixelFormat.TRANSLUCENT,
        )
        p.gravity = Gravity.TOP or Gravity.START
        return p
    }

    private fun neon(
        corner: Float,
        color: Int,
        fill: Int = 0xCC0A0B14.toInt(),
        stroke: Int = 2,
        oval: Boolean = false,
    ): GradientDrawable {
        val g = GradientDrawable()
        g.shape = if (oval) GradientDrawable.OVAL else GradientDrawable.RECTANGLE
        g.cornerRadius = corner
        g.setColor(fill)
        g.setStroke(dp(stroke), color)
        return g
    }

    private fun chip(label: String, color: Int = CYAN, onClick: (() -> Unit)? = null): TextView {
        val t = TextView(this)
        t.text = label
        t.setTextColor(Color.WHITE)
        t.textSize = 13f
        t.setTypeface(null, Typeface.BOLD)
        t.setShadowLayer(8f, 0f, 0f, color)
        t.setPadding(dp(12), dp(8), dp(12), dp(8))
        t.background = neon(dp(14).toFloat(), color)
        t.gravity = Gravity.CENTER
        if (onClick != null) t.setOnClickListener { onClick() }
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.setMargins(dp(4), dp(2), dp(4), dp(2))
        t.layoutParams = lp
        return t
    }

    // ---------------------------------------------------------------- bubble and bar

    private fun buildFxLayer() {
        val layer = FrameLayout(this)
        fx = layer
        wm.addView(layer, params(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT, touchable = false))
    }

    private fun buildBar() {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(0xE60A0B14.toInt())
        root.setPadding(dp(6), dp(30), dp(6), dp(6))

        val scroll1 = HorizontalScrollView(this)
        scroll1.isHorizontalScrollBarEnabled = false
        val line1 = LinearLayout(this)
        line1.orientation = LinearLayout.HORIZONTAL

        val likes = chip("👍 --", GREEN)
        val subs = chip("👥 --", PINK)
        val viewers = chip("👁 --", CYAN)
        tvLikes = likes
        tvSubs = subs
        tvViewers = viewers
        line1.addView(likes)
        line1.addView(subs)
        line1.addView(viewers)
        line1.addView(chip("⏸ Pause", PINK) { toggleBrb() })
        val read = chip("💬 Read comments", VIOLET) { setReadChat(!readChat) }
        chipRead = read
        line1.addView(read)
        line1.addView(chip("✨ FX", PINK) {
            val r = fxRow
            if (r != null) r.visibility = if (r.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        })
        line1.addView(chip("✖ Close tools", PINK) { shutdown() })
        scroll1.addView(line1)
        root.addView(scroll1)

        val scroll2 = HorizontalScrollView(this)
        scroll2.isHorizontalScrollBarEnabled = false
        val line2 = LinearLayout(this)
        line2.orientation = LinearLayout.HORIZONTAL
        line2.addView(chip("🎉 Confetti", PINK) { runFx("confetti") })
        line2.addView(chip("❤️ Hearts", PINK) { runFx("hearts") })
        line2.addView(chip("🔔 Subscribe", CYAN) { runFx("sub") })
        line2.addView(chip("👍 Like", GREEN) { runFx("like") })
        line2.addView(chip("⚡ Flash", VIOLET) { runFx("flash") })
        scroll2.addView(line2)
        scroll2.visibility = View.GONE
        fxRow = scroll2
        root.addView(scroll2)

        val comment = TextView(this)
        comment.setTextColor(Color.WHITE)
        comment.textSize = 14f
        comment.setPadding(dp(8), dp(6), dp(8), dp(2))
        comment.visibility = View.GONE
        tvComment = comment
        root.addView(comment)

        root.visibility = View.GONE
        bar = root
        wm.addView(root, params(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
    }

    private fun toggleBar() {
        val b = bar ?: return
        b.visibility = if (b.visibility == View.VISIBLE) View.GONE else View.VISIBLE
    }

    private fun buildBubble() {
        val ring = FrameLayout(this)
        ring.setPadding(dp(3), dp(3), dp(3), dp(3))
        ring.background = neon(0f, PINK, fill = PANEL, stroke = 3, oval = true)

        val inner = FrameLayout(this)
        inner.clipToOutline = true
        inner.outlineProvider = circleOutline

        val label = TextView(this)
        label.text = "PE"
        label.setTextColor(Color.WHITE)
        label.gravity = Gravity.CENTER
        label.textSize = 18f
        label.setTypeface(null, Typeface.BOLD)

        val img = ImageView(this)
        img.scaleType = ImageView.ScaleType.CENTER_CROP
        avatarView = img

        inner.addView(label, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        inner.addView(img, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        ring.addView(inner, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        val p = params(dp(64), dp(64))
        p.x = dp(12)
        p.y = dp(200)
        bubble = ring
        attachDrag(ring, p, dp(40), dp(220), onTap = { toggleBar() }, onLong = null)
        wm.addView(ring, p)
    }

    /** Drag with one finger, resize with a pinch, tap and long-press callbacks. */
    @SuppressLint("ClickableViewAccessibility")
    private fun attachDrag(
        v: View,
        p: WindowManager.LayoutParams,
        minSize: Int,
        maxSize: Int,
        onTap: (() -> Unit)?,
        onLong: (() -> Unit)?,
    ) {
        val sd = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                val nw = (p.width * detector.scaleFactor).toInt().coerceIn(minSize, maxSize)
                val real = nw.toFloat() / p.width
                p.width = nw
                p.height = (p.height * real).toInt().coerceAtLeast(minSize / 2)
                runCatching { wm.updateViewLayout(v, p) }
                return true
            }
        })
        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var moved = false
        var pinching = false
        var downTime = 0L
        v.setOnTouchListener { _, e ->
            sd.onTouchEvent(e)
            if (sd.isInProgress) {
                pinching = true
                return@setOnTouchListener true
            }
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX
                    downY = e.rawY
                    startX = p.x
                    startY = p.y
                    moved = false
                    pinching = false
                    downTime = System.currentTimeMillis()
                }
                MotionEvent.ACTION_MOVE -> if (!pinching && e.pointerCount == 1) {
                    val dx = (e.rawX - downX).toInt()
                    val dy = (e.rawY - downY).toInt()
                    if (abs(dx) > 12 || abs(dy) > 12) moved = true
                    if (moved) {
                        p.x = startX + dx
                        p.y = startY + dy
                        runCatching { wm.updateViewLayout(v, p) }
                    }
                }
                MotionEvent.ACTION_UP -> if (!moved && !pinching) {
                    if (System.currentTimeMillis() - downTime > 600) onLong?.invoke() else onTap?.invoke()
                }
            }
            true
        }
    }

    // ---------------------------------------------------------------- tiles (face cam, video, picture)

    private fun addTile(type: String, uri: String?, sizeKey: String, circle: Boolean) {
        if (tiles.size >= MAX_TILES) {
            toast("Maximum is 10 tiles.")
            return
        }
        if (type == "camera") {
            if (camTile != null) {
                toast("The face cam box is already on screen.")
                return
            }
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                toast("Allow the camera permission, then stop and start floating tools again.")
                return
            }
        }
        val dm = resources.displayMetrics
        val sw = dm.widthPixels
        val sh = dm.heightPixels
        val square = type == "camera" && circle
        var w = when (sizeKey) {
            "small" -> (sw * 0.25f).toInt()
            "large" -> (sw * 0.60f).toInt()
            "half" -> sw / 2
            else -> (sw * 0.40f).toInt()
        }
        w = w.coerceIn(dp(90), sw)
        val h = when {
            sizeKey == "half" && !square -> sh
            type == "camera" -> w
            else -> w * 9 / 16
        }

        val content: View = when (type) {
            "camera" -> makeCamera()
            "video" -> makeVideo(uri ?: return)
            "image" -> makeImage(uri ?: return)
            else -> return
        }
        content.clipToOutline = true
        content.outlineProvider = if (square) circleOutline else roundOutline(dp(14))

        val color = when (type) {
            "camera" -> CYAN
            "video" -> VIOLET
            else -> GREEN
        }
        val box = FrameLayout(this)
        box.setPadding(dp(3), dp(3), dp(3), dp(3))
        box.background = neon(if (square) 0f else dp(17).toFloat(), color, fill = PANEL, stroke = 3, oval = square)
        box.addView(content, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        val p = params(w, if (square) w else h)
        val n = tiles.size
        p.x = dp(30) + n * dp(26)
        p.y = dp(120) + n * dp(26)
        attachDrag(box, p, dp(70), sw, onTap = null, onLong = { removeTile(box) })
        wm.addView(box, p)
        tiles.add(box)
        if (type == "camera") camTile = box
        OverlayState.tiles.value = tiles.size
    }

    private fun makeCamera(): View {
        val pv = PreviewView(this)
        pv.implementationMode = PreviewView.ImplementationMode.COMPATIBLE
        pv.scaleType = PreviewView.ScaleType.FILL_CENTER
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            runCatching {
                val provider = future.get()
                val preview = Preview.Builder().build()
                preview.setSurfaceProvider(pv.surfaceProvider)
                provider.unbindAll()
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_FRONT_CAMERA, preview)
            }.onFailure { toast("Camera could not start: ${it.message}") }
        }, ContextCompat.getMainExecutor(this))
        return pv
    }

    private fun makeVideo(uri: String): View {
        val v = VideoView(this)
        v.setVideoURI(Uri.parse(uri))
        v.setOnPreparedListener { mp ->
            mp.isLooping = true
            mp.setVolume(0f, 0f)
            v.start()
        }
        return v
    }

    private fun makeImage(uri: String): View {
        val i = ImageView(this)
        i.scaleType = ImageView.ScaleType.CENTER_CROP
        i.setImageURI(Uri.parse(uri))
        return i
    }

    private fun removeTile(box: FrameLayout) {
        runCatching { wm.removeView(box) }
        tiles.remove(box)
        if (box === camTile) {
            camTile = null
            val f = ProcessCameraProvider.getInstance(this)
            f.addListener({ runCatching { f.get().unbindAll() } }, ContextCompat.getMainExecutor(this))
        }
        OverlayState.tiles.value = tiles.size
    }

    private fun clearTiles() {
        tiles.toList().forEach { removeTile(it) }
    }

    // ---------------------------------------------------------------- effects

    private fun runFx(name: String) {
        when (name) {
            "confetti" -> burst(listOf("🎉", "🎊", "✨", "⭐"), 34, true)
            "hearts" -> burst(listOf("❤️", "💖", "💗"), 22, false)
            "sub" -> banner("🔔 Subscribe to $channelName!")
            "like" -> banner("👍 Smash the like button!")
            "flash" -> flash()
        }
    }

    private fun burst(symbols: List<String>, count: Int, fall: Boolean) {
        val layer = fx ?: return
        val w = resources.displayMetrics.widthPixels
        val h = resources.displayMetrics.heightPixels
        repeat(count) {
            val t = TextView(this)
            t.text = symbols.random()
            t.textSize = (22..44).random().toFloat()
            layer.addView(t, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            t.translationX = (0 until maxOf(1, w - dp(60))).random().toFloat()
            t.translationY = if (fall) -dp(60).toFloat() else h.toFloat()
            t.animate()
                .translationY(if (fall) h.toFloat() else -dp(80).toFloat())
                .alpha(0.1f)
                .rotation((-40..40).random().toFloat())
                .setStartDelay((0..700).random().toLong())
                .setDuration((2200..4200).random().toLong())
                .withEndAction { layer.removeView(t) }
                .start()
        }
    }

    private fun banner(message: String) {
        val layer = fx ?: return
        val t = TextView(this)
        t.text = message
        t.setTextColor(Color.WHITE)
        t.textSize = 20f
        t.setTypeface(null, Typeface.BOLD)
        t.setShadowLayer(14f, 0f, 0f, PINK)
        t.setPadding(dp(22), dp(12), dp(22), dp(12))
        t.background = neon(dp(22).toFloat(), PINK)
        val lp = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
            Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL,
        )
        lp.bottomMargin = dp(100)
        layer.addView(t, lp)
        t.alpha = 0f
        t.translationY = dp(80).toFloat()
        t.animate().alpha(1f).translationY(0f).setDuration(400L).withEndAction {
            t.postDelayed({
                t.animate().alpha(0f).setDuration(500L).withEndAction { layer.removeView(t) }.start()
            }, 4500L)
        }.start()
    }

    private fun flash() {
        val layer = fx ?: return
        val v = View(this)
        v.setBackgroundColor(Color.WHITE)
        v.alpha = 0f
        layer.addView(v, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        v.animate().alpha(0.85f).setDuration(120L).withEndAction {
            v.animate().alpha(0f).setDuration(380L).withEndAction { layer.removeView(v) }.start()
        }.start()
    }

    // ---------------------------------------------------------------- pause screen

    private fun toggleBrb() {
        val cur = brb
        if (cur != null) {
            runCatching { wm.removeView(cur) }
            brb = null
            return
        }
        val root = FrameLayout(this)
        root.setBackgroundColor(0xF2070815.toInt())

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER

        val big = TextView(this)
        big.text = "BE RIGHT BACK"
        big.textSize = 40f
        big.setTypeface(null, Typeface.BOLD)
        big.setTextColor(Color.WHITE)
        big.setShadowLayer(30f, 0f, 0f, CYAN)
        big.gravity = Gravity.CENTER

        val small = TextView(this)
        small.text = "$channelName will be back in a moment"
        small.textSize = 16f
        small.setTextColor(0xFFB8C4FF.toInt())
        small.gravity = Gravity.CENTER
        small.setPadding(0, dp(10), 0, 0)

        val hint = TextView(this)
        hint.text = "(tap anywhere to resume)"
        hint.textSize = 12f
        hint.setTextColor(0xFF6E78A8.toInt())
        hint.gravity = Gravity.CENTER
        hint.setPadding(0, dp(24), 0, 0)

        col.addView(big)
        col.addView(small)
        col.addView(hint)
        root.addView(col, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        val anim = ObjectAnimator.ofFloat(big, "alpha", 0.45f, 1f)
        anim.duration = 900L
        anim.repeatCount = ValueAnimator.INFINITE
        anim.repeatMode = ValueAnimator.REVERSE
        anim.start()

        root.setOnClickListener { toggleBrb() }
        brb = root
        wm.addView(root, params(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
    }

    // ---------------------------------------------------------------- stats and comment reader

    private suspend fun loadBitmap(url: String): Bitmap? = withContext(Dispatchers.IO) {
        runCatching { URL(url).openStream().use { BitmapFactory.decodeStream(it) } }.getOrNull()
    }

    private fun startStats() {
        statsJob = lifecycleScope.launch {
            var tick = 0
            while (true) {
                if (tick % 2 == 0) {
                    val info = runCatching { YouTubeApi.channelInfo(this@OverlayService) }.getOrNull()
                    if (info != null) {
                        if (info.title.isNotEmpty()) channelName = info.title
                        tvSubs?.text = "👥 ${info.subs ?: "hidden"}"
                        val av = info.avatar
                        if (!avatarLoaded && av != null) {
                            val bmp = loadBitmap(av)
                            if (bmp != null) {
                                avatarView?.setImageBitmap(bmp)
                                avatarLoaded = true
                            }
                        }
                    }
                }
                tick++
                val id = Live.broadcastId
                if (id != null) {
                    val stats = runCatching { YouTubeApi.videoStats(this@OverlayService, id) }.getOrNull()
                    if (stats != null) {
                        tvLikes?.text = "👍 ${stats.first}"
                        tvViewers?.text = "👁 ${stats.second}"
                    }
                }
                delay(30_000L)
            }
        }
    }

    private fun setReadChat(on: Boolean) {
        readChat = on
        chipRead?.text = if (on) "💬 Reading: ON" else "💬 Read comments"
        tvComment?.visibility = if (on) View.VISIBLE else View.GONE
        chatJob?.cancel()
        if (!on) {
            tts?.stop()
            return
        }
        if (tts == null) {
            tts = TextToSpeech(this) { status ->
                if (status == TextToSpeech.SUCCESS) {
                    tts?.language = Locale.getDefault()
                    // Not captured by the stream: only the streamer hears the comments.
                    tts?.setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ASSISTANCE_ACCESSIBILITY)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                            .build()
                    )
                }
            }
        }
        chatJob = lifecycleScope.launch {
            var token: String? = null
            var first = true
            while (true) {
                val chat = Live.chatId
                if (chat == null) {
                    delay(5_000L)
                    continue
                }
                try {
                    val page = YouTubeApi.chat(this@OverlayService, chat, token)
                    token = page.next
                    if (!first) {
                        for (m in page.messages) {
                            tvComment?.text = "${m.author}: ${m.text}"
                            tts?.speak("${m.author} says ${m.text}", TextToSpeech.QUEUE_ADD, null, null)
                        }
                    }
                    first = false
                    delay(maxOf(10_000L, page.waitMs))
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    delay(15_000L)
                }
            }
        }
    }

    // ---------------------------------------------------------------- shutdown

    private fun cleanup() {
        statsJob?.cancel()
        chatJob?.cancel()
        tts?.stop()
        tts?.shutdown()
        tts = null
        clearTiles()
        brb?.let { v -> runCatching { wm.removeView(v) } }
        brb = null
        bubble?.let { v -> runCatching { wm.removeView(v) } }
        bar?.let { v -> runCatching { wm.removeView(v) } }
        fx?.let { v -> runCatching { wm.removeView(v) } }
        bubble = null
        bar = null
        fx = null
        running = false
        OverlayState.running.value = false
        OverlayState.tiles.value = 0
    }

    private fun shutdown() {
        cleanup()
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        cleanup()
        super.onDestroy()
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()
}
