# Get the APK without Android Studio

1. Create a free account at github.com and a **new private repository** (for example `proeditz-live`).
2. Upload everything inside this folder to it (Add file > Upload files). Include the hidden `.github` folder.
   Easiest: unzip, then drag all files and folders into the GitHub upload page.
3. Open the **Actions** tab > **Build APK** > it runs by itself (about 5 minutes). If not, press **Run workflow**.
4. Open the finished run > **Artifacts** > download `ProEditzLive-apk` > unzip to get `app-debug.apk`.
5. Send the APK to your phone, tap it, and allow "Install unknown apps".

## Google sign-in
Use this fixed SHA-1 when you create the Android OAuth client in Google Cloud
(package name `com.proeditz.livestudio`):

    3D:1E:9C:35:9F:B0:B9:9D:B1:C8:F9:E4:CA:2D:C0:56:4E:6C:F2:70

It stays the same for every build, so sign-in keeps working.
