# Pro Editz Live (Android)

Stream your phone screen or game straight to the **Pro Editz NEW** YouTube channel.

- Google sign-in, one-tap Go live and End stream (creates the broadcast and gets the stream key for you)
- Streams the phone screen with game sound, plus looping background music (playlist, shuffle, volume)
- Optional microphone mix, 480p / 720p / 1080p, landscape or portrait
- Title, description, tags, visibility and thumbnail for every stream
- Keeps streaming in the background while you play. End it from the notification.

Needs Android 10 or newer with Google Play services.

## 1. Open and build
1. Install **Android Studio** (developer.android.com/studio).
2. File > Open > choose this `ProEditzLive` folder. Wait for Gradle sync (needs internet the first time).
3. Plug in your phone with USB debugging on, then press Run. Or Build > Build APK(s) and install the file.

## 2. Google setup (one time)
1. console.cloud.google.com > create a project > **Enable "YouTube Data API v3"**.
2. OAuth consent screen: External, add your email `kadarsh7991.2@gmail.com` under **Test users**.
3. Credentials > Create credentials > OAuth client ID > type **Android**:
   - Package name: `com.proeditz.livestudio`
   - SHA-1: in Android Studio open the Gradle panel > ProEditzLive > Tasks > android > **signingReport**, and copy the `SHA1` of the `debug` variant.
4. Open the app and tap **Sign in with Google**. There is no client ID to paste in the app.

Tip: set the consent screen to "In production" so sign-in does not expire every 7 days.

## 3. Turn on live streaming on your channel
youtube.com/features > verify phone. Mobile live streaming itself needs the channel to be enabled for live; this can take up to 24 hours the first time.

## Using it
1. Open the app, sign in, set the title and add music.
2. Tap **Go live**, allow screen capture. Rotate your phone to match (landscape for games) before tapping.
3. Switch to your game. Pull down the notification and tap **End stream** when finished.

## Good to know
- Game and music sound is captured from the phone, so viewers hear what you hear. Some games block sound capture; then use the microphone.
- Use headphones if the mic is on, so the speaker does not echo.
- Use royalty-free music, or YouTube can mute the stream.
- If the build fails on a RootEncoder method name, check the version in `app/build.gradle.kts` against github.com/pedroSG94/RootEncoder.
