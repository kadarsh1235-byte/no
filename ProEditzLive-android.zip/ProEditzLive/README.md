# Pro Editz Live (Android)

Stream your phone screen or game straight to the **Pro Editz NEW** YouTube channel.

- Google sign-in, one-tap Go live and End stream (creates the broadcast and gets the stream key for you)
- Streams the phone screen with game sound, plus looping background music (playlist, shuffle, volume)
- Optional microphone mix, 480p / 720p / 1080p, landscape or portrait
- Title, description, tags, visibility and thumbnail for every stream
- Keeps streaming in the background while you play. End it from the notification.

Needs Android 10 or newer with Google Play services.

## 1. Open and build
1. Install **Android Studio** (developer.android.com/studio).
2. File > Open > choose this `ProEditzLive` folder. Wait for Gradle sync (needs internet the first time).
3. Plug in your phone with USB debugging on, then press Run. Or Build > Build APK(s) and install the file.

## 2. Google setup (one time)
1. console.cloud.google.com > create a project > **Enable "YouTube Data API v3"**.
2. OAuth consent screen: External, add your email `kadarsh7991.2@gmail.com` under **Test users**.
3. Credentials > Create credentials > OAuth client ID > type **Android**:
   - Package name: `com.proeditz.livestudio`
   - SHA-1: in Android Studio open the Gradle panel > ProEditzLive > Tasks > android > **signingReport**, and copy the `SHA1` of the `debug` variant.
4. Open the app and tap **Sign in with Google**. There is no client ID to paste in the app.

Tip: set the consent screen to "In production" so sign-in does not expire every 7 days.

## 3. Turn on live streaming on your channel
youtube.com/features > verify phone. Mobile live streaming itself needs the channel to be enabled for live; this can take up to 24 hours the first time.

## Using it
1. Open the app, sign in, set the title and add music.
2. Tap **Go live**, allow screen capture. Rotate your phone to match (landscape for games) before tapping.
3. Switch to your game. Pull down the notification and tap **End stream** when finished.

## Good to know
- Game and music sound is captured from the phone, so viewers hear what you hear. Some games block sound capture; then use the microphone.
- Use headphones if the mic is on, so the speaker does not echo.
- Use royalty-free music, or YouTube can mute the stream.
- If the build fails on a RootEncoder method name, check the version in `app/build.gradle.kts` against github.com/pedroSG94/RootEncoder.

## Pre-recorded video loop
Turn on **Stream pre-recorded videos** in the app, choose one or more videos, then tap Go live.
The videos play full screen inside the app and repeat forever (several videos play one after another).
Viewers see and hear exactly what plays. Tap the screen to show End stream and Hide player.
Keep the phone awake and turn on Do Not Disturb so notifications do not appear on the stream.

## Studio Edition 2.0
Tabs: **Live**, **Studio**, **Tools**, **About**. Google sign-in is unchanged.

**Studio tab (floating tools)**
1. Tap **Start floating tools**. The first time, Android opens Display over other apps: turn it on, come back, tap again.
2. A neon bubble with your channel logo appears over every app. Drag it, pinch to resize it, tap it to open the top bar:
   likes, subscribers, viewers, pause screen, comment reader, effects and Close.
3. **Face cam box**: your front camera in a square or circle you can drag and pinch to resize.
4. **Multi-screen tiles**: up to 10 video loops, pictures or the face cam, in small, medium, large or half-screen sizes.
   Long-press a tile to remove it. Run two games with Android split-screen and put tiles on top.
5. **Effects**: confetti, hearts, subscribe pop-up, flash. **Pause screen**: Be Right Back cover, tap to resume.
6. **Comment reader**: reads new live comments aloud. Only you hear it, not your viewers.

**Tools tab**: thumbnail maker (neon text on your picture, used for the next stream) and smart title and tag ideas.

Notes: tiles and the bar are part of the stream because the app streams your screen. Video tiles are muted;
use the full-screen video mode on the Live tab for videos with sound. Like and viewer counts refresh every 30 seconds.

## Control Room 2.1 (developer: Adarsh)

**Live tab: changes apply instantly, even while streaming**
- Music volume is a real percentage (40% plays at 40% of full volume, for you and for the stream).
- Add many songs; they play one after another in a loop. Use the top bar to go to the previous or next song, pause, and change volume.
- Mic on/off works during the stream, from the app or from the floating bar.

**Floating top bar** (tap the neon bubble)
- Likes, a red SUBS badge with your subscribers (and how many you gained this stream), viewers.
- Pause screen, mic on/off, music controls, comment reader, effects.
- Studio tab: "Top bar" can auto-hide after 3, 5 or 10 seconds.

**Pause screen**: custom text and an option to mute the mic while paused. It covers the stream with an animated screen. It also covers your own screen; tap to resume.

**Comment box on the stream** (Studio tab): drag to move, pinch to resize, font, text colour, text size, text transparency,
background transparency, number of lines, and a liquid glass look (frosted, with real blur on phones that support it).

**Voice reader**: Hindi (India), English (India) or phone default, with speed control. Only you hear it.
Install the Hindi voice in Google Text-to-speech settings if the app says the voice is missing.

**Subscriber alerts**: checks for new subscribers every 45 seconds while you are live. Shows "Name subscribed!" with confetti and
fireworks, plays your chosen sound (viewers hear it) and shows your meme picture. Optional name announcement for you.
Only public subscribers appear. YouTube does not tell apps who liked a stream, only the like count.

**3D effects**: 3D coins, 3D hearts, fireworks, shockwave, confetti, subscribe and like pop-ups, flash.

**Tools tab**: SEO studio (type the game or describe the video; get ranked titles, description, tags, keywords and thumbnail text,
then "Apply all in 1 tap" fills the Live tab and makes the thumbnail) and the thumbnail maker.

**Security**: the stream key is created fresh for each stream, kept only in memory, never shown, saved or logged, and sent over RTMPS
(encrypted) with an automatic fallback if your network blocks it. The app is not debuggable, has backups off and blocks plain HTTP.
No app can be promised unhackable; keep your phone locked and only install your own build.

## Face cam from a second phone (version 2.2)
1. Put both phones on the same Wi-Fi, or turn on the second phone's hotspot and connect the main phone to it.
2. Second phone: install this same app, open **Studio**, tap **Use THIS phone as the camera**. It shows an address and a 6-digit PIN.
   Choose back or front camera, the background, and a face mask. Keep that screen open.
3. Main phone: **Studio**, **Start floating tools**, type the address and PIN, tap **Connect and add the camera tile**.
   A face cam tile appears. Drag it anywhere and pinch to resize it. Long-press it to remove it (that also hides it from your stream).

Background: normal, blur, **remove (see-through, your game shows behind you)**, solid colour, your own picture or 3D render, or a built-in neon studio room.
Face mask: emoji, robot, cat, pixelate, or a neon circle. All effects run on the camera phone using Google ML Kit on the device. Nothing is uploaded.
The link is encrypted with the PIN (AES-256). Five wrong PINs lock the camera phone for a minute. Use your own Wi-Fi or hotspot, not public Wi-Fi.
See-through background needs Android 11 or newer on the camera phone. On Android 10 it falls back to a normal picture.

## Version 2.3

**Voice studio** (Studio tab). Turn it on, then turn the Microphone switch on in the Live tab. Use headphones.
- Voice effects, live (also from the floating bar, tap the Voice chip to switch): Normal (clean mic), Deep man, Demon, Woman, Child, Robot, Alien, Echo hall, Megaphone.
- Remove background noise: the phone's noise suppressor and auto gain.
- Cut background voices and hiss: a noise gate. Raise it until the background goes quiet. It cannot separate two people speaking at the same time.
- The changed voice is played as normal media audio and captured with your game sound, so viewers hear it. You hear it too.

**Pre-recorded video streaming**
- Choose videos, switch on "Stream pre-recorded videos", tap Go live. The floating tools start by themselves, so the comment box, effects, pause screen, face cam and tiles all show on top of the video.
- Comment box position: Studio tab has quick buttons (top left, top right, bottom left, bottom right, right side). Drag and pinch also work.
- "Dim the screen" keeps the screen on but almost dark, to save battery.
- Auto-reconnect: if your internet drops, the app tries again every 5 seconds for a long time and the stream comes back by itself.
- Allow background streaming: tap the battery button in the Live tab so Android does not stop the app.

**Important:** this app sends the video from your phone, so the phone must stay on, charged and online. If the phone is switched off, or its screen is turned off with the power button, the stream stops. A stream that runs with the phone off needs a separate server (a computer that is always on).

## Version 2.4

**Cartoon avatars** (camera phone screen, Face mask list): Neon Spark, Bubble Bob, Cat Hoodie. They are original designs.
The avatar copies your smile, your blinks and your head tilt. Switch on "Avatar only" to hide your whole body too; then the
avatar shows on a transparent, colour, picture or neon studio background.

**Vertical stage for pre-recorded videos** (Live tab, Video layout): pick "Vertical stage", then choose where the video sits
(top, middle or bottom), what fills Slot A and Slot B (face cam from the camera phone, live comments, or a channel banner), and
the background. The comment look (font, colour, size, glass, transparency) comes from the Studio tab. Type the camera phone address
and PIN in the Studio tab before you tap Go live if you use the face cam slot. The player also has a Pause video button (freezes the
picture) next to Dim screen, Hide player and End stream (tap the screen to show them).

**Comments**: one shared reader now asks YouTube once, so the floating comment box, the voice reader and the stage share it
(saves your daily API quota).

**Server kit** (separate zip): loops a video and music 24/7 from an always-on computer, so the phone can be off.

**What cannot be done with this screen-capture method**
- Pause that only the audience sees, or a floating bar that only you can see, while you play a game. Everything on the phone screen,
  including the floating tools, is part of what is captured. (In video mode the vertical stage and the server kit are the answer.)
- A vertical layout with a game in the middle. A game needs the real screen, which is horizontal.
