package com.proeditz.livestudio

import android.content.Context
import com.google.android.gms.auth.api.identity.AuthorizationRequest
import com.google.android.gms.auth.api.identity.AuthorizationResult
import com.google.android.gms.auth.api.identity.Identity
import com.google.android.gms.common.api.Scope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** Google sign-in for YouTube using the Play Services authorization API (no passwords or secrets in the app). */
object Auth {
    private val SCOPES = listOf(
        Scope("https://www.googleapis.com/auth/youtube"),
        Scope("https://www.googleapis.com/auth/youtube.force-ssl"),
    )

    private fun request() = AuthorizationRequest.builder().setRequestedScopes(SCOPES).build()

    suspend fun authorize(ctx: Context): AuthorizationResult =
        Identity.getAuthorizationClient(ctx).authorize(request()).await()

    /** Fresh access token. Throws if the user must sign in again. */
    suspend fun token(ctx: Context): String {
        val r = authorize(ctx)
        if (r.hasResolution()) throw IllegalStateException("Please sign in with Google again from the app.")
        return r.accessToken ?: throw IllegalStateException("Google did not return an access token.")
    }

    /** Removes this app's access to the Google account, so the next sign-in shows the account chooser again. */
    suspend fun signOut(ctx: Context) {
        runCatching {
            val r = authorize(ctx)
            val token = r.accessToken
            if (!r.hasResolution() && token != null) {
                withContext(Dispatchers.IO) {
                    val conn = URL("https://oauth2.googleapis.com/revoke?token=" + URLEncoder.encode(token, "UTF-8"))
                        .openConnection() as HttpURLConnection
                    try {
                        conn.requestMethod = "POST"
                        conn.doOutput = true
                        conn.setFixedLengthStreamingMode(0)
                        conn.responseCode
                    } finally {
                        conn.disconnect()
                    }
                }
            }
        }
    }
}
