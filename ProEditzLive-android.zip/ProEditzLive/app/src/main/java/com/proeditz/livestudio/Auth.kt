package com.proeditz.livestudio

import android.content.Context
import com.google.android.gms.auth.api.identity.AuthorizationRequest
import com.google.android.gms.auth.api.identity.AuthorizationResult
import com.google.android.gms.auth.api.identity.Identity
import com.google.android.gms.auth.api.identity.RevokeAccessRequest
import com.google.android.gms.common.api.Scope
import kotlinx.coroutines.tasks.await

/** Google sign-in for YouTube using the Play Services authorization API (no passwords or secrets in the app). */
object Auth {
    private val SCOPES = listOf(
        Scope("https://www.googleapis.com/auth/youtube"),
        Scope("https://www.googleapis.com/auth/youtube.force-ssl"),
    )

    private fun request() = AuthorizationRequest.builder().setRequestedScopes(SCOPES).build()

    suspend fun authorize(ctx: Context): AuthorizationResult =
        Identity.getAuthorizationClient(ctx).authorize(request()).await()

    /** Fresh access token. Throws if the user must sign in again. */
    suspend fun token(ctx: Context): String {
        val r = authorize(ctx)
        if (r.hasResolution()) throw IllegalStateException("Please sign in with Google again from the app.")
        return r.accessToken ?: throw IllegalStateException("Google did not return an access token.")
    }

    suspend fun signOut(ctx: Context) {
        runCatching {
            val account = authorize(ctx).toGoogleSignInAccount()?.account
            if (account != null) {
                Identity.getAuthorizationClient(ctx)
                    .revokeAccess(RevokeAccessRequest.builder().setAccount(account).setScopes(SCOPES).build())
                    .await()
            }
        }
    }
}
