package com.proeditz.livestudio

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Size
import android.view.View
import android.view.WindowManager
import android.widget.AdapterView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.proeditz.livestudio.databinding.ActivityCameraPhoneBinding
import java.io.ByteArrayOutputStream
import java.net.Inet4Address
import java.net.NetworkInterface
import java.security.SecureRandom
import java.util.concurrent.Executors

/**
 * Open this on the SECOND phone. It becomes the face cam for the main phone:
 * it shows an address and a PIN, applies your background and mask, and sends the picture over Wi-Fi.
 */
class CameraPhoneActivity : AppCompatActivity() {

    private lateinit var b: ActivityCameraPhoneBinding
    private val processor = FaceCamProcessor()
    private val exec = Executors.newSingleThreadExecutor()
    private var server: CamServer? = null
    private var provider: ProcessCameraProvider? = null
    private var last = 0L
    private var starting = false
    private val resSizes = listOf(Size(320, 240), Size(480, 360), Size(640, 480))
    private val frameGaps = longArrayOf(100L, 66L, 41L)
    @Volatile private var gap = 66L

    @Volatile private var lens = CameraSelector.LENS_FACING_BACK

    private val bgColors = listOf(0xFF00B140.toInt(), 0xFF0047FF.toInt(), 0xFFFF2BD6.toInt(), 0xFF000000.toInt(), 0xFFFFFFFF.toInt())

    private val camPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) startAll() else toast("The camera permission is needed.")
    }

    private val picturePicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            processor.bgPicture = runCatching {
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
                val opts = BitmapFactory.Options().apply { inSampleSize = maxOf(1, bounds.outWidth / 1200) }
                contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
            }.getOrNull()
            if (processor.bgPicture == null) toast("Could not open that picture.") else b.spCamBg.setSelection(4)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityCameraPhoneBinding.inflate(layoutInflater)
        setContentView(b.root)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        ViewCompat.setOnApplyWindowInsetsListener(b.root) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(0, bars.top, 0, bars.bottom)
            insets
        }

        b.spCamLens.onItemSelectedListener = listener { pos ->
            val want = if (pos == 0) CameraSelector.LENS_FACING_BACK else CameraSelector.LENS_FACING_FRONT
            if (want != lens) {
                lens = want
                if (server != null) bindCamera()
            }
            processor.mirror = b.swCamMirror.isChecked
        }
        b.spCamBg.onItemSelectedListener = listener { pos -> processor.bgMode = pos }
        b.spCamRes.setSelection(1)
        b.spCamFps.setSelection(1)
        b.spCamRes.onItemSelectedListener = listener { if (server != null) bindCamera() }
        b.spCamFps.onItemSelectedListener = listener { pos -> gap = frameGaps[pos.coerceIn(0, frameGaps.size - 1)] }
        b.spCamDetect.onItemSelectedListener = listener { pos ->
            processor.detectEvery = if (pos == 0) 3 else 1
            processor.segEvery = if (pos == 0) 2 else 1
        }
        b.spCamBgColor.onItemSelectedListener = listener { pos -> processor.bgColor = bgColors[pos.coerceIn(0, bgColors.size - 1)] }
        b.spCamMask.onItemSelectedListener = listener { pos -> processor.mask = pos }
        b.swCamMirror.setOnCheckedChangeListener { _, on -> processor.mirror = on }
        b.swCamAvatarOnly.setOnCheckedChangeListener { _, on -> processor.avatarOnly = on }
        b.btnCamPicture.setOnClickListener { picturePicker.launch(arrayOf("image/*")) }
        b.btnCamStop.setOnClickListener { finish() }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) startAll()
        else camPerm.launch(Manifest.permission.CAMERA)
    }

    private fun listener(onPick: (Int) -> Unit) = object : AdapterView.OnItemSelectedListener {
        override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) { onPick(pos) }
        override fun onNothingSelected(p: AdapterView<*>?) {}
    }

    private fun localIp(): String? = runCatching {
        NetworkInterface.getNetworkInterfaces().toList()
            .flatMap { it.inetAddresses.toList() }
            .firstOrNull { !it.isLoopbackAddress && it is Inet4Address && it.isSiteLocalAddress }
            ?.hostAddress
    }.getOrNull()

    private fun startAll() {
        if (server != null || starting) return
        starting = true
        val pin = (SecureRandom().nextInt(900000) + 100000).toString()
        b.tvCamPin.text = pin
        val ip = localIp()
        b.tvCamAddr.text = ip ?: "No Wi-Fi found. Connect to Wi-Fi, or turn on this phone's hotspot and connect the main phone to it."
        b.tvCamStatus.text = "Starting..."
        // Making the encryption key takes a moment, so it is done away from the screen thread.
        Thread {
            val s = CamServer(pin) { st -> runOnUiThread { b.tvCamStatus.text = st } }
            runOnUiThread {
                starting = false
                if (isFinishing) return@runOnUiThread
                server = s
                s.start()
                bindCamera()
            }
        }.start()
    }

    private fun bindCamera() {
        val f = ProcessCameraProvider.getInstance(this)
        f.addListener({
            runCatching {
                val p = f.get()
                provider = p
                val analysis = ImageAnalysis.Builder()
                    .setTargetResolution(resSizes[b.spCamRes.selectedItemPosition.coerceIn(0, resSizes.size - 1)])
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                    .build()
                analysis.setAnalyzer(exec) { proxy -> analyze(proxy) }
                p.unbindAll()
                p.bindToLifecycle(this, CameraSelector.Builder().requireLensFacing(lens).build(), analysis)
            }.onFailure { toast("Camera could not start: ${it.message}") }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun analyze(proxy: ImageProxy) {
        try {
            val now = System.currentTimeMillis()
            if (now - last < gap) return          // fewer pictures a second keeps both phones cool
            last = now
            var bmp = proxy.toBitmap()
            val rot = proxy.imageInfo.rotationDegrees
            if (rot != 0) {
                val m = Matrix()
                m.postRotate(rot.toFloat())
                bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
            }
            val out = processor.process(bmp)
            runOnUiThread { b.ivCamPreview.setImageBitmap(out) }
            val s = server
            if (s != null && s.hasClient) s.send(encode(out))
        } catch (e: Exception) {
            // skip this picture
        } finally {
            proxy.close()
        }
    }

    private fun encode(bmp: Bitmap): ByteArray {
        val os = ByteArrayOutputStream()
        if (processor.bgMode == 2 && Build.VERSION.SDK_INT >= 30) bmp.compress(Bitmap.CompressFormat.WEBP_LOSSY, 80, os)
        else bmp.compress(Bitmap.CompressFormat.JPEG, 80, os)
        return os.toByteArray()
    }

    override fun onDestroy() {
        server?.stop()
        runCatching { provider?.unbindAll() }
        exec.shutdown()
        super.onDestroy()
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()
}
