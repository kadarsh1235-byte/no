package com.proeditz.livestudio

import android.content.Context
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.launch

/**
 * One shared live-chat reader. The floating comment box, the voice reader and the vertical stage all listen here,
 * so YouTube is asked for new comments only once (this saves your daily API quota).
 */
object ChatFeed {
    val messages = MutableSharedFlow<YouTubeApi.ChatMsg>(extraBufferCapacity = 64)

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var users = 0
    private var job: Job? = null

    @Synchronized
    fun acquire(ctx: Context) {
        users++
        if (job?.isActive != true) {
            val app = ctx.applicationContext
            job = scope.launch { loop(app) }
        }
    }

    @Synchronized
    fun release() {
        users = (users - 1).coerceAtLeast(0)
        if (users == 0) {
            job?.cancel()
            job = null
        }
    }

    private suspend fun loop(ctx: Context) {
        var token: String? = null
        var first = true
        while (true) {
            val chat = Live.chatId
            if (chat == null) {
                token = null
                first = true
                delay(5_000L)
                continue
            }
            try {
                val page = YouTubeApi.chat(ctx, chat, token)
                token = page.next
                if (!first) page.messages.forEach { messages.tryEmit(it) }
                first = false
                delay(maxOf(10_000L, page.waitMs))
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                delay(15_000L)
            }
        }
    }
}
