package com.proeditz.livestudio

import android.content.Intent

/** Everything the service needs to start one live stream. */
data class Config(
    val title: String,
    val description: String,
    val tags: String,
    val privacy: String,
    val thumbUri: String?,
    val height: Int,
    val bitrateKbps: Int,
    val portrait: Boolean,
    val mic: Boolean,
    val music: List<String>,
    val musicVolume: Int,
    val shuffle: Boolean,
    val category: String = "20", // Gaming
    val latency: String = "low",
) {
    fun writeTo(i: Intent): Intent = i.apply {
        putExtra("title", title)
        putExtra("description", description)
        putExtra("tags", tags)
        putExtra("privacy", privacy)
        putExtra("thumbUri", thumbUri)
        putExtra("height", height)
        putExtra("bitrateKbps", bitrateKbps)
        putExtra("portrait", portrait)
        putExtra("mic", mic)
        putStringArrayListExtra("music", ArrayList(music))
        putExtra("musicVolume", musicVolume)
        putExtra("shuffle", shuffle)
        putExtra("category", category)
        putExtra("latency", latency)
    }

    companion object {
        fun from(i: Intent) = Config(
            title = i.getStringExtra("title") ?: "Live",
            description = i.getStringExtra("description") ?: "",
            tags = i.getStringExtra("tags") ?: "",
            privacy = i.getStringExtra("privacy") ?: "public",
            thumbUri = i.getStringExtra("thumbUri"),
            height = i.getIntExtra("height", 720),
            bitrateKbps = i.getIntExtra("bitrateKbps", 4000),
            portrait = i.getBooleanExtra("portrait", false),
            mic = i.getBooleanExtra("mic", false),
            music = i.getStringArrayListExtra("music") ?: arrayListOf(),
            musicVolume = i.getIntExtra("musicVolume", 25),
            shuffle = i.getBooleanExtra("shuffle", false),
            category = i.getStringExtra("category") ?: "20",
            latency = i.getStringExtra("latency") ?: "low",
        )
    }
}
