package com.proeditz.livestudio

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.Face
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import com.google.mlkit.vision.segmentation.Segmentation
import com.google.mlkit.vision.segmentation.selfie.SelfieSegmenterOptions

/**
 * Face cam effects, all on the camera phone (so the main phone does not slow down):
 * remove the background (transparent cutout), blur it, or replace it with a colour, your picture or a neon studio,
 * and hide your face with a mask. Uses Google ML Kit on the device. Nothing is uploaded anywhere.
 */
class FaceCamProcessor {
    @Volatile var bgMode = 0          // 0 none, 1 blur, 2 cutout, 3 solid colour, 4 my picture, 5 neon studio
    @Volatile var bgColor = 0xFF00B140.toInt()
    @Volatile var bgPicture: Bitmap? = null
    @Volatile var mask = 0            // 0 none, 1 cool, 2 robot, 3 cat, 4 pixelate, 5 neon circle, 6-8 cartoon avatars
    @Volatile var avatarOnly = false  // avatar replaces the whole camera picture (hides your body too)
    @Volatile var mirror = false
    @Volatile var segEvery = 2        // background mask is refreshed every N pictures (higher = faster)
    @Volatile var detectEvery = 3     // face finding runs every N pictures (higher = faster)
    private var frameNo = 0
    private var cachedConf: FloatArray? = null
    private var cachedMw = 0
    private var cachedMh = 0
    private var cachedW = 0
    private var cachedH = 0
    private var cachedFaces: List<Face> = emptyList()

    private val segmenter = Segmentation.getClient(
        SelfieSegmenterOptions.Builder().setDetectorMode(SelfieSegmenterOptions.STREAM_MODE).build()
    )
    private val detector = FaceDetection.getClient(
        FaceDetectorOptions.Builder()
            .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
            .setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_ALL)
            .build()
    )
    private var cachedBg: Bitmap? = null
    private var cachedKey = ""

    fun process(src: Bitmap): Bitmap {
        frameNo++
        val frame = if (mirror) flip(src) else src
        if (mask in 6..8 && avatarOnly) return avatarScene(frame)
        var out = frame
        if (bgMode != 0) out = background(frame)
        if (mask != 0) out = faceMask(out, frame)
        return out
    }

    private fun flip(src: Bitmap): Bitmap {
        val m = Matrix()
        m.postScale(-1f, 1f)
        return Bitmap.createBitmap(src, 0, 0, src.width, src.height, m, true)
    }

    private fun pixelsOf(b: Bitmap): IntArray {
        val px = IntArray(b.width * b.height)
        b.getPixels(px, 0, b.width, 0, 0, b.width, b.height)
        return px
    }

    private fun mix(fg: Int, bg: Int, a: Float): Int {
        val r = (Color.red(fg) * a + Color.red(bg) * (1 - a)).toInt()
        val g = (Color.green(fg) * a + Color.green(bg) * (1 - a)).toInt()
        val b = (Color.blue(fg) * a + Color.blue(bg) * (1 - a)).toInt()
        return Color.argb(255, r, g, b)
    }

    private fun background(frame: Bitmap): Bitmap {
        val w = frame.width
        val h = frame.height
        return try {
            var cc = cachedConf
            if (cc == null || frameNo % maxOf(1, segEvery) == 0 || cachedW != w || cachedH != h) {
                val m = Tasks.await(segmenter.process(InputImage.fromBitmap(frame, 0)))
                val buf = m.buffer
                buf.rewind()
                val fresh = FloatArray(m.width * m.height)
                for (i in fresh.indices) fresh[i] = buf.getFloat()
                cachedConf = fresh
                cachedMw = m.width
                cachedMh = m.height
                cachedW = w
                cachedH = h
                cc = fresh
            }
            val conf: FloatArray = cc
            val mw = cachedMw
            val mh = cachedMh

            val px = pixelsOf(frame)
            val bg: IntArray? = when (bgMode) {
                1 -> pixelsOf(blurred(frame))
                4 -> bgPicture?.let { pixelsOf(fit(it, w, h)) }
                5 -> pixelsOf(studio(w, h))
                else -> null
            }
            val solid = bgColor
            val out = IntArray(w * h)
            for (y in 0 until h) {
                val my = y * mh / h
                for (x in 0 until w) {
                    val i = y * w + x
                    val c = conf[my * mw + x * mw / w]
                    val t = ((c - 0.3f) / 0.4f).coerceIn(0f, 1f)
                    val a = t * t * (3 - 2 * t)
                    val p = px[i]
                    out[i] = if (bgMode == 2) {
                        (p and 0x00FFFFFF) or ((a * 255).toInt() shl 24)   // transparent cutout
                    } else {
                        mix(p, bg?.get(i) ?: solid, a)
                    }
                }
            }
            val res = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            res.setPixels(out, 0, w, 0, 0, w, h)
            res
        } catch (e: Exception) {
            frame
        }
    }

    private fun blurred(frame: Bitmap): Bitmap {
        val small = Bitmap.createScaledBitmap(frame, maxOf(1, frame.width / 12), maxOf(1, frame.height / 12), true)
        return Bitmap.createScaledBitmap(small, frame.width, frame.height, true)
    }

    private fun fit(src: Bitmap, w: Int, h: Int): Bitmap {
        val key = "pic-$w-$h-${System.identityHashCode(src)}"
        val c = cachedBg
        if (key == cachedKey && c != null) return c
        val s = maxOf(w / src.width.toFloat(), h / src.height.toFloat())
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        Canvas(out).drawBitmap(
            src, null,
            RectF((w - src.width * s) / 2, (h - src.height * s) / 2, (w + src.width * s) / 2, (h + src.height * s) / 2),
            Paint(Paint.FILTER_BITMAP_FLAG),
        )
        cachedBg = out
        cachedKey = key
        return out
    }

    /** A built-in neon studio room: gradient wall, glowing floor grid and light strips. */
    private fun studio(w: Int, h: Int): Bitmap {
        val key = "studio-$w-$h"
        val c = cachedBg
        if (key == cachedKey && c != null) return c
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val cv = Canvas(out)
        val p = Paint()
        p.shader = LinearGradient(
            0f, 0f, w.toFloat(), h.toFloat(),
            intArrayOf(0xFF1B0B3A.toInt(), 0xFF0A2A5E.toInt(), 0xFF3A0B3A.toInt()), null, Shader.TileMode.CLAMP,
        )
        cv.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p)
        val line = Paint(Paint.ANTI_ALIAS_FLAG)
        line.style = Paint.Style.STROKE
        line.strokeWidth = 2f
        line.color = 0x8800F0FF.toInt()
        val horizon = h * 0.58f
        for (i in -10..10) cv.drawLine(w / 2f, horizon, w / 2f + i * w * 0.18f, h.toFloat(), line)
        var y = horizon
        var step = h * 0.012f
        while (y < h) {
            cv.drawLine(0f, y, w.toFloat(), y, line)
            y += step
            step *= 1.35f
        }
        line.color = 0xCCFF2BD6.toInt()
        line.strokeWidth = 6f
        cv.drawLine(w * 0.08f, h * 0.12f, w * 0.08f, horizon, line)
        cv.drawLine(w * 0.92f, h * 0.12f, w * 0.92f, horizon, line)
        cachedBg = out
        cachedKey = key
        return out
    }

    /** Finds faces, but only every few pictures when 'Smooth' is chosen; in between it reuses the last result. */
    private fun detectFaces(frame: Bitmap): List<Face> {
        if (frameNo % maxOf(1, detectEvery) != 0 && cachedFaces.isNotEmpty()) return cachedFaces
        val f = runCatching { Tasks.await(detector.process(InputImage.fromBitmap(frame, 0))) }.getOrNull() ?: return cachedFaces
        cachedFaces = f
        return f
    }

    private fun faceMask(out: Bitmap, frame: Bitmap): Bitmap {
        val faces = detectFaces(frame)
        if (faces.isEmpty()) return out
        val res = out.copy(Bitmap.Config.ARGB_8888, true) ?: return out
        val c = Canvas(res)
        track(faces.maxByOrNull { it.boundingBox.width() })
        for (f in faces) {
            val r = f.boundingBox
            when (mask) {
                1, 2, 3 -> {
                    val e = when (mask) {
                        1 -> "😎"
                        2 -> "🤖"
                        else -> "🐱"
                    }
                    val p = Paint(Paint.ANTI_ALIAS_FLAG)
                    p.textAlign = Paint.Align.CENTER
                    p.textSize = r.width() * 1.35f
                    val fm = p.fontMetrics
                    c.drawText(e, r.exactCenterX(), r.exactCenterY() - (fm.ascent + fm.descent) / 2f, p)
                }
                4 -> pixelate(res, r)
                6, 7, 8 -> drawAvatar(c, mask - 6, r)
                5 -> {
                    val rad = maxOf(r.width(), r.height()) * 0.62f
                    val fill = Paint(Paint.ANTI_ALIAS_FLAG)
                    fill.color = 0xFF12142A.toInt()
                    c.drawCircle(r.exactCenterX(), r.exactCenterY(), rad, fill)
                    val st = Paint(Paint.ANTI_ALIAS_FLAG)
                    st.style = Paint.Style.STROKE
                    st.strokeWidth = rad * 0.12f
                    st.color = 0xFF00F0FF.toInt()
                    c.drawCircle(r.exactCenterX(), r.exactCenterY(), rad, st)
                }
            }
        }
        return res
    }

    private fun pixelate(bmp: Bitmap, r: Rect) {
        val x = r.left.coerceIn(0, bmp.width - 1)
        val y = r.top.coerceIn(0, bmp.height - 1)
        val w = r.width().coerceAtMost(bmp.width - x)
        val h = r.height().coerceAtMost(bmp.height - y)
        if (w < 8 || h < 8) return
        val region = Bitmap.createBitmap(bmp, x, y, w, h)
        val block = maxOf(8, w / 8)
        val small = Bitmap.createScaledBitmap(region, maxOf(1, w / block), maxOf(1, h / block), false)
        val big = Bitmap.createScaledBitmap(small, w, h, false)
        Canvas(bmp).drawBitmap(big, x.toFloat(), y.toFloat(), null)
    }

    // ---------------------------------------------------------------- cartoon avatars (original designs)

    private val pt = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private var smile = 0f
    private var leOpen = 1f
    private var reOpen = 1f
    private var tilt = 0f
    private var lastRect: Rect? = null

    /** Follows your face: smile, open or closed eyes and head tilt, smoothed so the avatar does not jitter. */
    private fun track(f: Face?) {
        if (f == null) return
        smile += ((f.smilingProbability ?: smile) - smile) * 0.5f
        leOpen += ((f.leftEyeOpenProbability ?: leOpen) - leOpen) * 0.6f
        reOpen += ((f.rightEyeOpenProbability ?: reOpen) - reOpen) * 0.6f
        tilt += (f.headEulerAngleZ - tilt) * 0.5f
        lastRect = Rect(f.boundingBox)
    }

    /** Only the avatar is shown (no camera picture at all): on transparent, colour, picture or studio. */
    private fun avatarScene(frame: Bitmap): Bitmap {
        val w = frame.width
        val h = frame.height
        val blank = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val base: Bitmap = when (bgMode) {
            3 -> {
                val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                b.eraseColor(bgColor)
                b
            }
            4 -> bgPicture?.let { fit(it, w, h).copy(Bitmap.Config.ARGB_8888, true) } ?: blank
            5 -> studio(w, h).copy(Bitmap.Config.ARGB_8888, true) ?: blank
            else -> blank
        }
        val faces = detectFaces(frame)
        track(faces.maxByOrNull { it.boundingBox.width() })
        val r = lastRect ?: Rect(w / 4, h / 4, w * 3 / 4, h * 3 / 4)
        drawAvatar(Canvas(base), mask - 6, r)
        return base
    }

    /** Three original cartoon styles: 0 Neon Spark (spiky hair), 1 Bubble Bob (bob haircut), 2 Cat Hoodie (cat ears). */
    private fun drawAvatar(c: Canvas, style: Int, r: Rect) {
        val cx = r.exactCenterX()
        val cy = r.exactCenterY()
        val s = maxOf(r.width(), r.height()) * 1.2f
        val hair = when (style) {
            0 -> 0xFFFF2BD6.toInt()
            1 -> 0xFF1B2A6B.toInt()
            else -> 0xFFFF9A3C.toInt()
        }
        val iris = when (style) {
            0 -> 0xFF00C8E0.toInt()
            1 -> 0xFF3A56D4.toInt()
            else -> 0xFF2FBF71.toInt()
        }
        c.save()
        c.rotate(-tilt, cx, cy)

        // hair behind the head, or cat ears
        pt.style = Paint.Style.FILL
        pt.color = hair
        when (style) {
            0 -> for (i in -3..3) {
                path.reset()
                val bx = cx + i * s * 0.14f
                path.moveTo(bx - s * 0.09f, cy - s * 0.30f)
                path.lineTo(bx + i * s * 0.03f, cy - s * 0.62f - (3 - kotlin.math.abs(i)) * s * 0.03f)
                path.lineTo(bx + s * 0.09f, cy - s * 0.30f)
                path.close()
                c.drawPath(path, pt)
            }
            1 -> c.drawOval(RectF(cx - s * 0.58f, cy - s * 0.58f, cx + s * 0.58f, cy + s * 0.55f), pt)
            else -> for (side in intArrayOf(-1, 1)) {
                path.reset()
                path.moveTo(cx + side * s * 0.12f, cy - s * 0.42f)
                path.lineTo(cx + side * s * 0.46f, cy - s * 0.78f)
                path.lineTo(cx + side * s * 0.50f, cy - s * 0.22f)
                path.close()
                c.drawPath(path, pt)
            }
        }

        // face
        pt.color = 0xFFFFDCC4.toInt()
        c.drawOval(RectF(cx - s * 0.46f, cy - s * 0.5f, cx + s * 0.46f, cy + s * 0.5f), pt)

        // fringe
        if (style != 2) {
            pt.color = hair
            c.drawArc(RectF(cx - s * 0.48f, cy - s * 0.52f, cx + s * 0.48f, cy + s * 0.06f), 180f, 180f, true, pt)
        }

        // eyes (they close when you blink), brows and blush
        for (side in intArrayOf(-1, 1)) {
            val ex = cx + side * s * 0.22f
            val ey = cy - s * 0.02f
            val open = (if (side < 0) leOpen else reOpen).coerceIn(0f, 1f)
            val hh = s * 0.13f * (0.12f + 0.88f * open)
            pt.style = Paint.Style.FILL
            pt.color = Color.WHITE
            c.drawOval(RectF(ex - s * 0.11f, ey - hh, ex + s * 0.11f, ey + hh), pt)
            if (open > 0.3f) {
                pt.color = iris
                c.drawCircle(ex, ey, s * 0.075f, pt)
                pt.color = 0xFF14142A.toInt()
                c.drawCircle(ex, ey, s * 0.04f, pt)
                pt.color = Color.WHITE
                c.drawCircle(ex - s * 0.025f, ey - s * 0.03f, s * 0.018f, pt)
            }
            pt.style = Paint.Style.STROKE
            pt.strokeWidth = s * 0.02f
            pt.color = 0xFF3A2A40.toInt()
            c.drawLine(ex - s * 0.1f, ey - hh - s * 0.05f, ex + s * 0.1f, ey - hh - s * 0.065f, pt)
            pt.style = Paint.Style.FILL
            pt.color = 0x66FF6FA8
            c.drawCircle(ex, cy + s * 0.13f, s * 0.07f, pt)
        }

        // nose and mouth (the mouth follows your smile)
        pt.style = Paint.Style.FILL
        pt.color = 0x55A05A4A
        c.drawCircle(cx, cy + s * 0.1f, s * 0.012f, pt)
        val sm = smile.coerceIn(0f, 1f)
        val my = cy + s * 0.27f
        val mw = s * 0.16f
        path.reset()
        path.moveTo(cx - mw, my - sm * s * 0.02f)
        path.quadTo(cx, my + (0.02f + 0.12f * sm) * s, cx + mw, my - sm * s * 0.02f)
        if (sm > 0.55f) {
            pt.style = Paint.Style.FILL
            pt.color = 0xFFFF6F8F.toInt()
            c.drawPath(path, pt)
        }
        pt.style = Paint.Style.STROKE
        pt.strokeWidth = s * 0.022f
        pt.color = 0xFF8A2B3A.toInt()
        c.drawPath(path, pt)

        // cat whiskers
        if (style == 2) {
            pt.strokeWidth = s * 0.012f
            pt.color = 0xFF5A4A50.toInt()
            for (side in intArrayOf(-1, 1)) {
                for (k in -1..1) {
                    c.drawLine(cx + side * s * 0.28f, cy + s * 0.16f + k * s * 0.04f, cx + side * s * 0.52f, cy + s * 0.14f + k * s * 0.08f, pt)
                }
            }
        }
        c.restore()
    }
}
