package com.proeditz.livestudio

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import com.google.mlkit.vision.segmentation.Segmentation
import com.google.mlkit.vision.segmentation.selfie.SelfieSegmenterOptions

/**
 * Face cam effects, all on the camera phone (so the main phone does not slow down):
 * remove the background (transparent cutout), blur it, or replace it with a colour, your picture or a neon studio,
 * and hide your face with a mask. Uses Google ML Kit on the device. Nothing is uploaded anywhere.
 */
class FaceCamProcessor {
    @Volatile var bgMode = 0          // 0 none, 1 blur, 2 cutout, 3 solid colour, 4 my picture, 5 neon studio
    @Volatile var bgColor = 0xFF00B140.toInt()
    @Volatile var bgPicture: Bitmap? = null
    @Volatile var mask = 0            // 0 none, 1 cool, 2 robot, 3 cat, 4 pixelate, 5 neon circle
    @Volatile var mirror = false

    private val segmenter = Segmentation.getClient(
        SelfieSegmenterOptions.Builder().setDetectorMode(SelfieSegmenterOptions.STREAM_MODE).build()
    )
    private val detector = FaceDetection.getClient(
        FaceDetectorOptions.Builder().setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST).build()
    )
    private var cachedBg: Bitmap? = null
    private var cachedKey = ""

    fun process(src: Bitmap): Bitmap {
        val frame = if (mirror) flip(src) else src
        var out = frame
        if (bgMode != 0) out = background(frame)
        if (mask != 0) out = faceMask(out, frame)
        return out
    }

    private fun flip(src: Bitmap): Bitmap {
        val m = Matrix()
        m.postScale(-1f, 1f)
        return Bitmap.createBitmap(src, 0, 0, src.width, src.height, m, true)
    }

    private fun pixelsOf(b: Bitmap): IntArray {
        val px = IntArray(b.width * b.height)
        b.getPixels(px, 0, b.width, 0, 0, b.width, b.height)
        return px
    }

    private fun mix(fg: Int, bg: Int, a: Float): Int {
        val r = (Color.red(fg) * a + Color.red(bg) * (1 - a)).toInt()
        val g = (Color.green(fg) * a + Color.green(bg) * (1 - a)).toInt()
        val b = (Color.blue(fg) * a + Color.blue(bg) * (1 - a)).toInt()
        return Color.argb(255, r, g, b)
    }

    private fun background(frame: Bitmap): Bitmap {
        val w = frame.width
        val h = frame.height
        return try {
            val m = Tasks.await(segmenter.process(InputImage.fromBitmap(frame, 0)))
            val mw = m.width
            val mh = m.height
            val buf = m.buffer
            buf.rewind()
            val conf = FloatArray(mw * mh)
            for (i in conf.indices) conf[i] = buf.getFloat()

            val px = pixelsOf(frame)
            val bg: IntArray? = when (bgMode) {
                1 -> pixelsOf(blurred(frame))
                4 -> bgPicture?.let { pixelsOf(fit(it, w, h)) }
                5 -> pixelsOf(studio(w, h))
                else -> null
            }
            val solid = bgColor
            val out = IntArray(w * h)
            for (y in 0 until h) {
                val my = y * mh / h
                for (x in 0 until w) {
                    val i = y * w + x
                    val c = conf[my * mw + x * mw / w]
                    val t = ((c - 0.3f) / 0.4f).coerceIn(0f, 1f)
                    val a = t * t * (3 - 2 * t)
                    val p = px[i]
                    out[i] = if (bgMode == 2) {
                        (p and 0x00FFFFFF) or ((a * 255).toInt() shl 24)   // transparent cutout
                    } else {
                        mix(p, bg?.get(i) ?: solid, a)
                    }
                }
            }
            val res = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            res.setPixels(out, 0, w, 0, 0, w, h)
            res
        } catch (e: Exception) {
            frame
        }
    }

    private fun blurred(frame: Bitmap): Bitmap {
        val small = Bitmap.createScaledBitmap(frame, maxOf(1, frame.width / 12), maxOf(1, frame.height / 12), true)
        return Bitmap.createScaledBitmap(small, frame.width, frame.height, true)
    }

    private fun fit(src: Bitmap, w: Int, h: Int): Bitmap {
        val key = "pic-$w-$h-${System.identityHashCode(src)}"
        val c = cachedBg
        if (key == cachedKey && c != null) return c
        val s = maxOf(w / src.width.toFloat(), h / src.height.toFloat())
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        Canvas(out).drawBitmap(
            src, null,
            RectF((w - src.width * s) / 2, (h - src.height * s) / 2, (w + src.width * s) / 2, (h + src.height * s) / 2),
            Paint(Paint.FILTER_BITMAP_FLAG),
        )
        cachedBg = out
        cachedKey = key
        return out
    }

    /** A built-in neon studio room: gradient wall, glowing floor grid and light strips. */
    private fun studio(w: Int, h: Int): Bitmap {
        val key = "studio-$w-$h"
        val c = cachedBg
        if (key == cachedKey && c != null) return c
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val cv = Canvas(out)
        val p = Paint()
        p.shader = LinearGradient(
            0f, 0f, w.toFloat(), h.toFloat(),
            intArrayOf(0xFF1B0B3A.toInt(), 0xFF0A2A5E.toInt(), 0xFF3A0B3A.toInt()), null, Shader.TileMode.CLAMP,
        )
        cv.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p)
        val line = Paint(Paint.ANTI_ALIAS_FLAG)
        line.style = Paint.Style.STROKE
        line.strokeWidth = 2f
        line.color = 0x8800F0FF.toInt()
        val horizon = h * 0.58f
        for (i in -10..10) cv.drawLine(w / 2f, horizon, w / 2f + i * w * 0.18f, h.toFloat(), line)
        var y = horizon
        var step = h * 0.012f
        while (y < h) {
            cv.drawLine(0f, y, w.toFloat(), y, line)
            y += step
            step *= 1.35f
        }
        line.color = 0xCCFF2BD6.toInt()
        line.strokeWidth = 6f
        cv.drawLine(w * 0.08f, h * 0.12f, w * 0.08f, horizon, line)
        cv.drawLine(w * 0.92f, h * 0.12f, w * 0.92f, horizon, line)
        cachedBg = out
        cachedKey = key
        return out
    }

    private fun faceMask(out: Bitmap, frame: Bitmap): Bitmap {
        val faces = runCatching { Tasks.await(detector.process(InputImage.fromBitmap(frame, 0))) }.getOrNull()
        if (faces.isNullOrEmpty()) return out
        val res = out.copy(Bitmap.Config.ARGB_8888, true) ?: return out
        val c = Canvas(res)
        for (f in faces) {
            val r = f.boundingBox
            when (mask) {
                1, 2, 3 -> {
                    val e = when (mask) {
                        1 -> "😎"
                        2 -> "🤖"
                        else -> "🐱"
                    }
                    val p = Paint(Paint.ANTI_ALIAS_FLAG)
                    p.textAlign = Paint.Align.CENTER
                    p.textSize = r.width() * 1.35f
                    val fm = p.fontMetrics
                    c.drawText(e, r.exactCenterX(), r.exactCenterY() - (fm.ascent + fm.descent) / 2f, p)
                }
                4 -> pixelate(res, r)
                5 -> {
                    val rad = maxOf(r.width(), r.height()) * 0.62f
                    val fill = Paint(Paint.ANTI_ALIAS_FLAG)
                    fill.color = 0xFF12142A.toInt()
                    c.drawCircle(r.exactCenterX(), r.exactCenterY(), rad, fill)
                    val st = Paint(Paint.ANTI_ALIAS_FLAG)
                    st.style = Paint.Style.STROKE
                    st.strokeWidth = rad * 0.12f
                    st.color = 0xFF00F0FF.toInt()
                    c.drawCircle(r.exactCenterX(), r.exactCenterY(), rad, st)
                }
            }
        }
        return res
    }

    private fun pixelate(bmp: Bitmap, r: Rect) {
        val x = r.left.coerceIn(0, bmp.width - 1)
        val y = r.top.coerceIn(0, bmp.height - 1)
        val w = r.width().coerceAtMost(bmp.width - x)
        val h = r.height().coerceAtMost(bmp.height - y)
        if (w < 8 || h < 8) return
        val region = Bitmap.createBitmap(bmp, x, y, w, h)
        val block = maxOf(8, w / 8)
        val small = Bitmap.createScaledBitmap(region, maxOf(1, w / block), maxOf(1, h / block), false)
        val big = Bitmap.createScaledBitmap(small, w, h, false)
        Canvas(bmp).drawBitmap(big, x.toFloat(), y.toFloat(), null)
    }
}
