package com.proeditz.livestudio

import kotlinx.coroutines.flow.MutableStateFlow

/** Shared live state: the service writes it, the screen reads it. */
object Live {
    data class State(
        val phase: String = "idle", // idle, creating, starting, waiting, live, ending, error
        val text: String = "Sign in, set your title, then go live.",
        val url: String = "",
        val since: Long = 0L,
    )

    val state = MutableStateFlow(State())

    fun set(phase: String, text: String, url: String? = null) {
        val cur = state.value
        val since = when {
            phase != "live" -> 0L
            cur.phase == "live" && cur.since > 0 -> cur.since
            else -> System.currentTimeMillis()
        }
        state.value = State(phase, text, url ?: cur.url, since)
    }

    fun reset(phase: String, text: String) {
        state.value = State(phase, text, "", 0L)
    }
}
