package com.proeditz.livestudio

import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow

/** Shared live state: the service writes it, the screen reads it. */
object Live {
    data class State(
        val phase: String = "idle", // idle, creating, starting, waiting, live, ending, error
        val text: String = "Sign in, set your title, then go live.",
        val url: String = "",
        val since: Long = 0L,
    )

    val state = MutableStateFlow(State())

    /** Set by the streaming service so the floating tools can read stats and comments. */
    /** Live controls: changes made anywhere (app or floating bar) apply instantly. */
    val musicVolume = MutableStateFlow(25)
    val micOn = MutableStateFlow(false)
    /** Voice studio (change voice, remove noise). Everything here can change while you stream. */
    val voiceStudio = MutableStateFlow(false)
    val voiceMode = MutableStateFlow(0)
    val voiceGate = MutableStateFlow(0)
    val voiceDenoise = MutableStateFlow(true)
    val voiceNames = listOf("Normal", "Deep man", "Demon", "Woman", "Child", "Robot", "Alien", "Echo", "Megaphone")

    val commands = MutableSharedFlow<String>(extraBufferCapacity = 16) // music_next, music_prev, music_toggle

    @Volatile var broadcastId: String? = null
    @Volatile var chatId: String? = null

    fun set(phase: String, text: String, url: String? = null) {
        val cur = state.value
        val since = when {
            phase != "live" -> 0L
            cur.phase == "live" && cur.since > 0 -> cur.since
            else -> System.currentTimeMillis()
        }
        state.value = State(phase, text, url ?: cur.url, since)
    }

    fun reset(phase: String, text: String) {
        state.value = State(phase, text, "", 0L)
    }
}

/** State of the floating tools (bubble, bar, tiles). */
object OverlayState {
    val running = MutableStateFlow(false)
    val tiles = MutableStateFlow(0)
}
