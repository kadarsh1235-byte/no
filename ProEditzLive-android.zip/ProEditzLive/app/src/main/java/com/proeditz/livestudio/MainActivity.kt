package com.proeditz.livestudio

import android.Manifest
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.SeekBar
import android.widget.Toast
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.google.android.gms.auth.api.identity.Identity
import com.proeditz.livestudio.databinding.ActivityMainBinding
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding
    private lateinit var prefs: SharedPreferences

    private val music = mutableListOf<String>()
    private var thumb: String? = null
    private var channel: String? = null

    private val privacyValues = listOf("public", "unlisted", "private")
    private val qualities = listOf(480 to 2000, 720 to 4000, 1080 to 6000) // height to kbps

    // ---------- activity result launchers ----------
    private val authLauncher = registerForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { res ->
        try {
            Identity.getAuthorizationClient(this).getAuthorizationResultFromIntent(res.data)
            loadChannel()
        } catch (e: Exception) {
            toast("Sign-in was cancelled.")
        }
    }

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        if (hasMic()) askScreenCapture()
        else toast("Allow the microphone permission. It is needed to capture game sound.")
    }

    private val projectionLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        val data = res.data
        if (res.resultCode == RESULT_OK && data != null) {
            Live.set("creating", "Creating your YouTube broadcast...")
            StreamService.start(this, buildConfig(), res.resultCode, data)
        } else {
            toast("Screen sharing was not allowed.")
        }
    }

    private val musicPicker = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        uris.forEach {
            runCatching { contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            music.add(it.toString())
        }
        refresh(); save()
    }

    private val thumbPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            runCatching { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            thumb = uri.toString()
            refresh(); save()
        }
    }

    // ---------- lifecycle ----------
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)
        prefs = getSharedPreferences("ui", MODE_PRIVATE)
        restore()

        b.btnSignIn.setOnClickListener { if (channel == null) signIn() else signOut() }
        b.btnLive.setOnClickListener { onLiveClicked() }
        b.btnOpen.setOnClickListener {
            val url = Live.state.value.url
            if (url.isNotEmpty()) startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        }
        b.btnMusic.setOnClickListener { musicPicker.launch(arrayOf("audio/*")) }
        b.btnClearMusic.setOnClickListener { music.clear(); refresh(); save() }
        b.btnThumb.setOnClickListener { thumbPicker.launch(arrayOf("image/*")) }
        b.sbVolume.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { refresh() }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) { save() }
        })

        refresh()
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch { Live.state.collect { render(it) } }
                launch {
                    while (true) {
                        val s = Live.state.value
                        if (s.phase == "live" && s.since > 0) b.tvTimer.text = hms((System.currentTimeMillis() - s.since) / 1000)
                        delay(500)
                    }
                }
            }
        }
    }

    override fun onPause() { super.onPause(); save() }

    // ---------- account ----------
    private fun signIn() {
        lifecycleScope.launch {
            try {
                val r = Auth.authorize(this@MainActivity)
                if (r.hasResolution()) {
                    authLauncher.launch(IntentSenderRequest.Builder(r.pendingIntent!!.intentSender).build())
                } else {
                    loadChannel()
                }
            } catch (e: Exception) {
                toast("Sign-in failed: ${e.message}")
            }
        }
    }

    private fun loadChannel() {
        lifecycleScope.launch {
            try {
                val name = YouTubeApi.myChannel(this@MainActivity)
                if (name == null) toast("This Google account has no YouTube channel yet.")
                setChannel(name)
            } catch (e: Exception) {
                toast(e.message ?: "Could not reach YouTube.")
                setChannel(null)
            }
        }
    }

    private fun signOut() {
        lifecycleScope.launch {
            Auth.signOut(this@MainActivity)
            setChannel(null)
        }
    }

    private fun setChannel(name: String?) {
        channel = name
        prefs.edit().putString("channel", name).apply()
        b.tvAccount.text = name?.let { "Signed in as $it" } ?: "Not signed in"
        b.btnSignIn.text = if (name == null) "Sign in with Google" else "Sign out"
    }

    // ---------- go live ----------
    private fun onLiveClicked() {
        when (Live.state.value.phase) {
            "idle", "error" -> startFlow()
            else -> StreamService.stop(this)
        }
    }

    private fun startFlow() {
        if (channel == null) return toast("Sign in with Google first.")
        if (b.etTitle.text.isNullOrBlank()) return toast("Add a stream title.")
        save()
        val need = mutableListOf<String>()
        if (!hasMic()) need += Manifest.permission.RECORD_AUDIO
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) need += Manifest.permission.POST_NOTIFICATIONS
        if (need.isEmpty()) askScreenCapture() else permLauncher.launch(need.toTypedArray())
    }

    private fun hasMic() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun askScreenCapture() {
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projectionLauncher.launch(mpm.createScreenCaptureIntent())
    }

    private fun buildConfig(): Config {
        val (height, kbps) = qualities[b.spQuality.selectedItemPosition.coerceIn(0, 2)]
        return Config(
            title = b.etTitle.text.toString().trim(),
            description = b.etDescription.text.toString(),
            tags = b.etTags.text.toString(),
            privacy = privacyValues[b.spPrivacy.selectedItemPosition.coerceIn(0, 2)],
            thumbUri = thumb,
            height = height,
            bitrateKbps = kbps,
            portrait = b.swPortrait.isChecked,
            mic = b.swMic.isChecked,
            music = music.toList(),
            musicVolume = b.sbVolume.progress,
            shuffle = b.swShuffle.isChecked,
        )
    }

    // ---------- UI ----------
    private val phaseLabel = mapOf(
        "idle" to "Off air", "creating" to "Getting ready", "starting" to "Getting ready",
        "waiting" to "Connecting", "live" to "On air", "ending" to "Ending", "error" to "Problem",
    )

    private fun render(s: Live.State) {
        b.tvPhase.text = phaseLabel[s.phase] ?: s.phase
        b.tvPhase.setTextColor(ContextCompat.getColor(this, if (s.phase == "live") R.color.air else R.color.muted))
        b.tvStatus.text = s.text
        val running = s.phase in listOf("creating", "starting", "waiting", "live", "ending")
        b.btnLive.text = when {
            s.phase == "ending" -> "Ending..."
            running -> "End stream"
            else -> "Go live"
        }
        b.btnLive.isEnabled = s.phase !in listOf("creating", "starting", "ending")
        b.btnOpen.visibility = if (running && s.url.isNotEmpty()) View.VISIBLE else View.GONE
        if (!running) b.tvTimer.text = "00:00:00"
    }

    private fun refresh() {
        b.tvVolume.text = "Music volume ${b.sbVolume.progress}%"
        b.tvMusic.text = if (music.isEmpty()) "No music added. Songs you add play in a loop."
        else "${music.size} song${if (music.size == 1) "" else "s"} will loop: " +
            music.take(3).joinToString(", ") { Uri.parse(it).lastPathSegment?.substringAfterLast('/') ?: "track" } +
            if (music.size > 3) "..." else ""
        b.btnClearMusic.visibility = if (music.isEmpty()) View.GONE else View.VISIBLE
        b.tvThumb.text = thumb?.let { Uri.parse(it).lastPathSegment?.substringAfterLast('/') ?: "Thumbnail chosen" } ?: "No thumbnail"
    }

    // ---------- saved settings ----------
    private fun save() {
        prefs.edit()
            .putString("title", b.etTitle.text.toString())
            .putString("description", b.etDescription.text.toString())
            .putString("tags", b.etTags.text.toString())
            .putInt("privacy", b.spPrivacy.selectedItemPosition)
            .putInt("quality", b.spQuality.selectedItemPosition)
            .putBoolean("portrait", b.swPortrait.isChecked)
            .putBoolean("mic", b.swMic.isChecked)
            .putBoolean("shuffle", b.swShuffle.isChecked)
            .putInt("volume", b.sbVolume.progress)
            .putString("thumb", thumb)
            .putString("music", music.joinToString("\n"))
            .apply()
    }

    private fun restore() {
        b.etTitle.setText(prefs.getString("title", "Pro Editz NEW | Live"))
        b.etDescription.setText(prefs.getString("description", "Live on Pro Editz NEW. Like, subscribe and turn on notifications!"))
        b.etTags.setText(prefs.getString("tags", "Pro Editz NEW, live, gaming"))
        b.spPrivacy.setSelection(prefs.getInt("privacy", 0))
        b.spQuality.setSelection(prefs.getInt("quality", 1))
        b.swPortrait.isChecked = prefs.getBoolean("portrait", false)
        b.swMic.isChecked = prefs.getBoolean("mic", false)
        b.swShuffle.isChecked = prefs.getBoolean("shuffle", false)
        b.sbVolume.progress = prefs.getInt("volume", 25)
        thumb = prefs.getString("thumb", null)
        music.clear()
        prefs.getString("music", "")?.split("\n")?.filter { it.isNotBlank() }?.let { music.addAll(it) }
        setChannel(prefs.getString("channel", null))
    }

    private fun hms(sec: Long) = "%02d:%02d:%02d".format(sec / 3600, (sec / 60) % 60, sec % 60)
    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()
}
