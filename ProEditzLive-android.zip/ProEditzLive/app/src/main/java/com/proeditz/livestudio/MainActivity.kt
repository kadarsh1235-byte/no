package com.proeditz.livestudio

import android.Manifest
import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.animation.ValueAnimator
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.text.TextWatcher
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.CompoundButton
import android.widget.EditText
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.google.android.gms.auth.api.identity.Identity
import com.proeditz.livestudio.databinding.ActivityMainBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding
    private lateinit var prefs: SharedPreferences   // stream settings
    private lateinit var ov: SharedPreferences      // floating tools and app settings (shared with OverlayService)

    private val music = mutableListOf<String>()
    private val videos = mutableListOf<String>()
    private var thumb: String? = null
    private var channel: String? = null
    private var thumbBg: Bitmap? = null
    private var thumbJob: Job? = null
    private var pulse: ObjectAnimator? = null

    private var seoPack: SeoEngine.Pack? = null
    private var aiWords: List<String> = emptyList()
    private var titleIndex = 0
    private var lastPin = ""
    private var tileGeoms: List<TileGeom> = emptyList()

    private val privacyValues = listOf("public", "unlisted", "private")
    private val qualities = listOf(480 to 1200, 720 to 2500, 1080 to 4500) // height to kbps (lighter = smoother)
    private val tileSizes = listOf("small", "medium", "large", "half")
    private val thumbColors = listOf(0xFF00F0FF.toInt(), 0xFFFF2BD6.toInt(), 0xFFFFE600.toInt(), 0xFF39FF88.toInt())

    private class ThumbSpec(val text: String, val neon: Int, val bg: Bitmap?)

    // ---------- activity result launchers ----------
    private val authLauncher = registerForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { res ->
        try {
            Identity.getAuthorizationClient(this).getAuthorizationResultFromIntent(res.data)
            loadChannel()
        } catch (e: Exception) {
            toast("Sign-in was cancelled.")
        }
    }

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        if (hasMic()) askScreenCapture()
        else toast("Allow the microphone permission. It is needed to capture game sound.")
    }

    private val projectionLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        val data = res.data
        if (res.resultCode == RESULT_OK && data != null) {
            Live.set("creating", "Creating your YouTube broadcast...")
            StreamService.start(this, buildConfig(), res.resultCode, data)
            if (b.swVideo.isChecked) {
                // Floating tools (comment box, texts, effects, bar) are part of the video stream, so start them too.
                if (Settings.canDrawOverlays(this) && !OverlayState.running.value) OverlayService.start(this)
                startActivity(
                    Intent(this, PlayerActivity::class.java)
                        .putStringArrayListExtra("videos", ArrayList(videos))
                        .putExtra("portrait", b.swPortrait.isChecked || stageOn())
                        .putExtra("dim", b.swDim.isChecked)
                        .putExtra("layout", b.spStageLayout.selectedItemPosition)
                        .putExtra("videoPos", b.spStageVideoPos.selectedItemPosition)
                        .putExtra("slotA", b.spSlotA.selectedItemPosition)
                        .putExtra("slotB", b.spSlotB.selectedItemPosition)
                        .putExtra("stageBg", b.spStageBg.selectedItemPosition)
                        .putExtra("camIp", b.etCamIp.text.toString().trim())
                        .putExtra("camPin", b.etCamPin.text.toString().trim().ifEmpty { lastPin })
                        .putExtra("channelName", channel ?: "")
                )
            }
        } else {
            toast("Screen sharing was not allowed.")
        }
    }

    private val musicPicker = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        uris.forEach {
            runCatching { contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            music.add(it.toString())
        }
        refresh(); save()
    }

    private val videoPicker = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        uris.forEach {
            runCatching { contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            videos.add(it.toString())
        }
        refresh(); save()
    }

    private val thumbPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            runCatching { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            thumb = uri.toString()
            refresh(); save()
        }
    }

    private val thumbBgPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) loadThumbBg(uri)
    }

    private val aiPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) runAi(uri)
    }

    private val tileVideoPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            runCatching { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            overlay(OverlayService.A_TILE) {
                putExtra("type", "video")
                putExtra("uri", uri.toString())
                putExtra("size", tileSizeKey())
                putExtra("loop", b.swNewTileLoop.isChecked)
            }
        }
    }

    private val tileImagePicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            runCatching { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            overlay(OverlayService.A_TILE) {
                putExtra("type", "image")
                putExtra("uri", uri.toString())
                putExtra("size", tileSizeKey())
            }
        }
    }

    private val subSoundPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            runCatching { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            ov.edit().putString("sub_sound", uri.toString()).apply()
            refreshSubFiles()
            pushCfg()
        }
    }

    private val subMemePicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            runCatching { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            ov.edit().putString("sub_meme", uri.toString()).apply()
            refreshSubFiles()
            pushCfg()
        }
    }

    private val overlayPermLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        OverlayService.start(this)
    }

    private val camPermLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) toast("Camera allowed. Tap Stop floating tools, then Start floating tools, then add the face cam box.")
        else toast("The camera permission is needed for the face cam box.")
    }

    // ---------- lifecycle ----------
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)
        ViewCompat.setOnApplyWindowInsetsListener(b.root) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(0, bars.top, 0, bars.bottom)
            insets
        }
        prefs = getSharedPreferences("ui", MODE_PRIVATE)
        ov = getSharedPreferences("overlay", MODE_PRIVATE)
        restore()
        setupNav()

        if (Live.state.value.phase == "idle") {
            Live.musicVolume.value = b.sbVolume.progress
            Live.micOn.value = b.swMic.isChecked
        } else {
            b.sbVolume.progress = Live.musicVolume.value
            b.swMic.isChecked = Live.micOn.value
        }

        b.btnSignIn.setOnClickListener { if (channel == null) signIn() else signOut() }
        b.btnLive.setOnClickListener { onLiveClicked() }
        b.btnOpen.setOnClickListener {
            val url = Live.state.value.url
            if (url.isNotEmpty()) startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        }
        b.btnMusic.setOnClickListener { musicPicker.launch(arrayOf("audio/*")) }
        b.btnClearMusic.setOnClickListener { music.clear(); refresh(); save() }
        b.btnVideos.setOnClickListener { videoPicker.launch(arrayOf("video/*")) }
        b.btnClearVideos.setOnClickListener { videos.clear(); refresh(); save() }
        b.swVideo.setOnCheckedChangeListener { _, _ -> save() }
        b.swDim.setOnCheckedChangeListener { _, _ -> save() }
        b.btnBattery.setOnClickListener {
            runCatching {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
            }.onFailure {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
        }
        b.btnThumb.setOnClickListener { thumbPicker.launch(arrayOf("image/*")) }

        // Live controls: these apply instantly, also while streaming.
        b.sbVolume.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                Live.musicVolume.value = p
                refresh()
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) { save() }
        })
        b.swMic.setOnCheckedChangeListener { btn, on ->
            Live.micOn.value = on
            if (btn.isPressed) save()
        }

        setupStudio()
        setupTools()
        setupSettings()

        refresh()
        renderOverlay()
        renderThumbPreview()
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch { Live.state.collect { render(it) } }
                launch { OverlayState.running.collect { renderOverlay() } }
                launch { OverlayState.tiles.collect { renderOverlay() } }
                launch { OverlayState.texts.collect { b.tvTextCount.text = "Texts on screen: $it" } }
                launch { OverlayState.tileList.collect { refreshTileEditor(it) } }
                launch { Live.musicVolume.collect { if (b.sbVolume.progress != it) b.sbVolume.progress = it } }
                launch { Live.micOn.collect { if (b.swMic.isChecked != it) b.swMic.isChecked = it } }
                launch { Live.voiceMode.collect { if (b.spVoiceMode.selectedItemPosition != it) b.spVoiceMode.setSelection(it) } }
                launch {
                    while (true) {
                        val s = Live.state.value
                        if (s.phase == "live" && s.since > 0) b.tvTimer.text = hms((System.currentTimeMillis() - s.since) / 1000)
                        delay(500)
                    }
                }
            }
        }
    }

    override fun onPause() { super.onPause(); save() }

    private fun setupNav() {
        val pages = mapOf(
            R.id.nav_live to b.pageLive, R.id.nav_studio to b.pageStudio, R.id.nav_tools to b.pageTools,
            R.id.nav_settings to b.pageSettings, R.id.nav_about to b.pageAbout,
        )
        b.nav.setOnItemSelectedListener { item ->
            pages.forEach { (id, v) -> v.visibility = if (id == item.itemId) View.VISIBLE else View.GONE }
            true
        }
        b.nav.selectedItemId = R.id.nav_live
    }

    // ---------- account ----------
    private fun signIn() {
        lifecycleScope.launch {
            try {
                val r = Auth.authorize(this@MainActivity)
                if (r.hasResolution()) {
                    authLauncher.launch(IntentSenderRequest.Builder(r.pendingIntent!!.intentSender).build())
                } else {
                    loadChannel()
                }
            } catch (e: Exception) {
                toast("Sign-in failed: ${e.message}")
            }
        }
    }

    private fun loadChannel() {
        lifecycleScope.launch {
            try {
                val name = YouTubeApi.myChannel(this@MainActivity)
                if (name == null) toast("This Google account has no YouTube channel yet.")
                setChannel(name)
            } catch (e: Exception) {
                toast(e.message ?: "Could not reach YouTube.")
                setChannel(null)
            }
        }
    }

    private fun signOut() {
        lifecycleScope.launch {
            Auth.signOut(this@MainActivity)
            setChannel(null)
        }
    }

    private fun setChannel(name: String?) {
        channel = name
        prefs.edit().putString("channel", name).apply()
        b.tvAccount.text = name?.let { "Signed in as $it" } ?: "Not signed in"
        b.btnSignIn.text = if (name == null) "Sign in with Google" else "Sign out"
    }

    // ---------- go live ----------
    private fun onLiveClicked() {
        when (Live.state.value.phase) {
            "idle", "error" -> startFlow()
            else -> StreamService.stop(this)
        }
    }

    private fun startFlow() {
        if (channel == null) return toast("Sign in with Google first.")
        if (b.etTitle.text.isNullOrBlank()) return toast("Add a stream title.")
        if (b.swVideo.isChecked && videos.isEmpty()) return toast("Choose at least one video first.")
        save()
        val need = mutableListOf<String>()
        if (!hasMic()) need += Manifest.permission.RECORD_AUDIO
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) need += Manifest.permission.POST_NOTIFICATIONS
        if (need.isEmpty()) askScreenCapture() else permLauncher.launch(need.toTypedArray())
    }

    private fun hasMic() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun hasCamera() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED

    private fun askScreenCapture() {
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projectionLauncher.launch(mpm.createScreenCaptureIntent())
    }

    private fun buildConfig(): Config {
        val (height, presetKbps) = qualities[b.spQuality.selectedItemPosition.coerceIn(0, 2)]
        val kbps = if (ov.getBoolean("custom_br", false)) ov.getInt("br_kbps", 2500) else presetKbps
        return Config(
            title = b.etTitle.text.toString().trim(),
            description = b.etDescription.text.toString(),
            tags = b.etTags.text.toString(),
            privacy = privacyValues[b.spPrivacy.selectedItemPosition.coerceIn(0, 2)],
            thumbUri = thumb,
            height = height,
            bitrateKbps = kbps,
            portrait = b.swPortrait.isChecked || stageOn(),
            mic = b.swMic.isChecked,
            music = music.toList(),
            musicVolume = b.sbVolume.progress,
            shuffle = b.swShuffle.isChecked,
        )
    }

    // ---------- settings helpers ----------
    private fun pushCfg() {
        OverlayService.send(this, OverlayService.A_CFG)
    }

    private fun bindSwitch(sw: CompoundButton, key: String, def: Boolean, after: ((Boolean) -> Unit)? = null) {
        sw.isChecked = ov.getBoolean(key, def)
        after?.invoke(sw.isChecked)
        sw.setOnCheckedChangeListener { _, on ->
            ov.edit().putBoolean(key, on).apply()
            after?.invoke(on)
            pushCfg()
        }
    }

    private fun bindSpin(sp: Spinner, key: String, def: Int) {
        sp.setSelection(ov.getInt(key, def))
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                if (ov.getInt(key, def) != pos) {
                    ov.edit().putInt(key, pos).apply()
                    pushCfg()
                }
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
    }

    /** The saved value is progress + offset. [after] runs when you move the slider (instead of the default refresh). */
    private fun bindSeek(
        sb: SeekBar,
        label: TextView,
        key: String,
        def: Int,
        offset: Int,
        after: (() -> Unit)? = null,
        fmt: (Int) -> String,
    ) {
        sb.progress = (ov.getInt(key, def) - offset).coerceIn(0, sb.max)
        label.text = fmt(sb.progress + offset)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                label.text = fmt(p + offset)
                if (fromUser) {
                    ov.edit().putInt(key, p + offset).apply()
                    if (after != null) after() else pushCfg()
                }
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
    }

    private fun bindText(et: EditText, key: String, def: String) {
        et.setText(ov.getString(key, def))
        et.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b4: Int, c: Int) {
                ov.edit().putString(key, s?.toString() ?: "").apply()
            }
            override fun afterTextChanged(s: Editable?) {}
        })
    }

    // ---------- studio (floating tools) ----------
    private fun setupStudio() {
        b.btnOverlay.setOnClickListener { toggleOverlay() }
        b.btnAddCam.setOnClickListener { addCameraTile() }
        b.btnAddVideoTile.setOnClickListener { if (overlayOn()) tileVideoPicker.launch(arrayOf("video/*")) }
        b.btnAddImageTile.setOnClickListener { if (overlayOn()) tileImagePicker.launch(arrayOf("image/*")) }
        b.btnClearTiles.setOnClickListener { overlay(OverlayService.A_CLEAR) }
        b.btnCamPhone.setOnClickListener { startActivity(Intent(this, CameraPhoneActivity::class.java)) }
        b.btnConnectCam.setOnClickListener { connectCameraPhone() }
        bindText(b.etCamIp, "cam_ip", "")
        bindSwitch(b.swNewTileLoop, "new_tile_loop", true)

        // Tile editor: exact size and place, loop, mute, see-through
        b.spTileList.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) { showTile(pos) }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        fun tileSeek(sb: SeekBar, label: TextView, offset: Int, fmt: (Int) -> String) {
            sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    label.text = fmt(p + offset)
                    if (fromUser) sendTileEdit()
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        tileSeek(b.sbTileW, b.tvTileW, 1) { "Width $it%" }
        tileSeek(b.sbTileH, b.tvTileH, 1) { "Height $it%" }
        tileSeek(b.sbTileX, b.tvTileX, 0) { "Place left to right $it%" }
        tileSeek(b.sbTileY, b.tvTileY, 0) { "Place top to bottom $it%" }
        tileSeek(b.sbTileAlpha, b.tvTileAlpha, 20) { "See-through level $it%" }
        b.swTileLoop.setOnCheckedChangeListener { btn, _ -> if (btn.isPressed) sendTileEdit() }
        b.swTileMute.setOnCheckedChangeListener { btn, _ -> if (btn.isPressed) sendTileEdit() }

        // Text on screen
        bindSpin(b.spTextFont, "t_font", 0)
        bindSpin(b.spTextColor, "t_color", 1)
        bindSpin(b.spTextStyle, "t_style", 0)
        bindSpin(b.spTextAnim, "t_anim", 0)
        bindSpin(b.spTextPos, "t_pos", 0)
        bindSeek(b.sbTextSize, b.tvTextSize, "t_size", 36, 14) { "Text size $it" }
        bindText(b.etOverlayText, "t_text", "")
        b.btnShowText.setOnClickListener {
            val t = b.etOverlayText.text.toString().trim()
            if (t.isEmpty()) return@setOnClickListener toast("Type your text first.")
            overlay(OverlayService.A_TEXT) {
                putExtra("text", t)
                putExtra("size", b.sbTextSize.progress + 14)
                putExtra("font", b.spTextFont.selectedItemPosition)
                putExtra("color", b.spTextColor.selectedItemPosition)
                putExtra("style", b.spTextStyle.selectedItemPosition)
                putExtra("anim", b.spTextAnim.selectedItemPosition)
                putExtra("pos", b.spTextPos.selectedItemPosition)
            }
        }
        b.btnClearText.setOnClickListener { overlay(OverlayService.A_TEXTCLEAR) }

        // Comment box
        bindSwitch(b.swCmtBox, "cmt_box", false)
        bindSpin(b.spCmtFont, "cmt_font", 0)
        bindSpin(b.spCmtColor, "cmt_color", 0)
        bindSpin(b.spCmtLines, "cmt_lines", 2)
        bindSeek(b.sbCmtSize, b.tvCmtSize, "cmt_size", 16, 10) { "Text size $it" }
        bindSeek(b.sbCmtTextAlpha, b.tvCmtTextAlpha, "cmt_alpha", 100, 0) { "Text transparency $it%" }
        bindSeek(b.sbCmtBgAlpha, b.tvCmtBgAlpha, "cmt_bg", 45, 0) { "Box background $it%" }
        bindSeek(b.sbCmtRadius, b.tvCmtRadius, "cmt_radius", 24, 0) { "Corner roundness $it" }
        bindSwitch(b.swCmtGlass, "cmt_glass", true)
        bindSwitch(b.swCmtNeon, "cmt_neon", false)
        bindSwitch(b.swCmtBlur, "cmt_blur", false)
        bindSwitch(b.swCmtAuthor, "cmt_author", true)
        bindSeek(b.sbCmtW, b.tvCmtW, "cmt_w", 45, 30, after = { sendCmtBox() }) { "Width $it%" }
        bindSeek(b.sbCmtH, b.tvCmtH, "cmt_h", 22, 10, after = { sendCmtBox() }) { "Height $it%" }
        bindSeek(b.sbCmtX, b.tvCmtX, "cmt_x", 5, 0, after = { sendCmtBox() }) { "Place left to right $it%" }
        bindSeek(b.sbCmtY, b.tvCmtY, "cmt_y", 50, 0, after = { sendCmtBox() }) { "Place top to bottom $it%" }
        b.btnCmtTL.setOnClickListener { overlay(OverlayService.A_CMTPOS) { putExtra("pos", "tl") } }
        b.btnCmtTR.setOnClickListener { overlay(OverlayService.A_CMTPOS) { putExtra("pos", "tr") } }
        b.btnCmtBL.setOnClickListener { overlay(OverlayService.A_CMTPOS) { putExtra("pos", "bl") } }
        b.btnCmtBR.setOnClickListener { overlay(OverlayService.A_CMTPOS) { putExtra("pos", "br") } }
        b.btnCmtSide.setOnClickListener { overlay(OverlayService.A_CMTPOS) { putExtra("pos", "side") } }

        // Effects and pause
        b.btnFxConfetti.setOnClickListener { overlay(OverlayService.A_FX) { putExtra("fx", "confetti") } }
        b.btnFxFlash.setOnClickListener { overlay(OverlayService.A_FX) { putExtra("fx", "flash") } }
        b.btnFxCoins.setOnClickListener { overlay(OverlayService.A_FX) { putExtra("fx", "coins3d") } }
        b.btnFxHearts3d.setOnClickListener { overlay(OverlayService.A_FX) { putExtra("fx", "hearts3d") } }
        b.btnFxFire.setOnClickListener { overlay(OverlayService.A_FX) { putExtra("fx", "fireworks") } }
        b.btnFxRing.setOnClickListener { overlay(OverlayService.A_FX) { putExtra("fx", "ring") } }
        b.btnFxSub.setOnClickListener { overlay(OverlayService.A_FX) { putExtra("fx", "sub") } }
        b.btnPopupNow.setOnClickListener {
            val t = b.etOverlayText.text.toString().trim()
            overlay(OverlayService.A_FX) {
                putExtra("fx", "popup_custom")
                putExtra("title", t)
            }
        }
        b.btnBrb.setOnClickListener { overlay(OverlayService.A_BRB) }
        bindSwitch(b.swPauseMute, "pause_mute", true)
        bindText(b.etPauseText, "pause_text", "BE RIGHT BACK")

        // Face cam / tiles size defaults for the stage
        bindSpin(b.spStageLayout, "stage_layout", 0)
        bindSpin(b.spStageVideoPos, "stage_pos", 1)
        bindSpin(b.spSlotA, "stage_a", 1)
        bindSpin(b.spSlotB, "stage_b", 2)
        bindSpin(b.spStageBg, "stage_bg", 0)
    }

    private fun sendCmtBox() {
        OverlayService.send(this, OverlayService.A_CMTBOX) {
            putExtra("w", b.sbCmtW.progress + 30)
            putExtra("h", b.sbCmtH.progress + 10)
            putExtra("x", b.sbCmtX.progress)
            putExtra("y", b.sbCmtY.progress)
        }
    }

    private fun refreshTileEditor(list: List<TileGeom>) {
        tileGeoms = list
        val prev = b.spTileList.selectedItemPosition
        val names = if (list.isEmpty()) listOf("No tiles yet") else list.map { it.name }
        b.spTileList.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, names)
        b.spTileList.setSelection(prev.coerceIn(0, names.size - 1))
        showTile(b.spTileList.selectedItemPosition)
    }

    private fun showTile(i: Int) {
        val t = tileGeoms.getOrNull(i) ?: return
        b.sbTileW.progress = (t.w - 1).coerceIn(0, b.sbTileW.max)
        b.sbTileH.progress = (t.h - 1).coerceIn(0, b.sbTileH.max)
        b.sbTileX.progress = t.x.coerceIn(0, 100)
        b.sbTileY.progress = t.y.coerceIn(0, 100)
        b.sbTileAlpha.progress = (t.alpha - 20).coerceIn(0, b.sbTileAlpha.max)
        b.swTileLoop.isChecked = t.loop
        b.swTileMute.isChecked = t.mute
        val isVideo = t.type == "video"
        b.swTileLoop.isEnabled = isVideo
        b.swTileMute.isEnabled = isVideo
    }

    private fun sendTileEdit() {
        if (tileGeoms.isEmpty()) return
        val i = b.spTileList.selectedItemPosition
        OverlayService.send(this, OverlayService.A_TILEEDIT) {
            putExtra("i", i)
            putExtra("w", b.sbTileW.progress + 1)
            putExtra("h", b.sbTileH.progress + 1)
            putExtra("x", b.sbTileX.progress)
            putExtra("y", b.sbTileY.progress)
            putExtra("alpha", b.sbTileAlpha.progress + 20)
            putExtra("loop", if (b.swTileLoop.isChecked) 1 else 0)
            putExtra("mute", if (b.swTileMute.isChecked) 1 else 0)
        }
    }

    private fun refreshSubFiles() {
        fun nameOf(key: String): String? =
            ov.getString(key, null)?.let { Uri.parse(it).lastPathSegment?.substringAfterLast('/') ?: "chosen" }
        val s = nameOf("sub_sound")
        val m = nameOf("sub_meme")
        b.tvSubFiles.text = if (s == null && m == null) "No sound or meme chosen."
        else "Sound: ${s ?: "none"}\nMeme: ${m ?: "none"}"
    }

    private fun overlayOn(): Boolean {
        if (!OverlayState.running.value) {
            toast("Start floating tools first.")
            return false
        }
        return true
    }

    private fun overlay(action: String, extra: Intent.() -> Unit = {}) {
        if (!overlayOn()) return
        OverlayService.send(this, action, extra)
    }

    /** Vertical stage is on when you stream videos and picked the Vertical stage layout. */
    private fun stageOn() = b.swVideo.isChecked && b.spStageLayout.selectedItemPosition == 1

    private fun tileSizeKey() = tileSizes[b.spTileSize.selectedItemPosition.coerceIn(0, tileSizes.size - 1)]

    private fun toggleOverlay() {
        if (OverlayState.running.value) {
            OverlayService.send(this, OverlayService.A_STOP)
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            toast("Turn on Display over other apps for Pro Editz Live, come back, and tap again.")
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        val need = mutableListOf<String>()
        if (!hasCamera()) need += Manifest.permission.CAMERA
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) need += Manifest.permission.POST_NOTIFICATIONS
        if (need.isEmpty()) OverlayService.start(this) else overlayPermLauncher.launch(need.toTypedArray())
    }

    private fun addCameraTile() {
        if (!overlayOn()) return
        if (!hasCamera()) {
            camPermLauncher.launch(Manifest.permission.CAMERA)
            return
        }
        overlay(OverlayService.A_TILE) {
            putExtra("type", "camera")
            putExtra("size", tileSizeKey())
            putExtra("circle", b.swCamCircle.isChecked)
        }
    }

    private fun connectCameraPhone() {
        if (!overlayOn()) return
        val ip = b.etCamIp.text.toString().trim()
        val pin = b.etCamPin.text.toString().trim()
        if (!Regex("^\\d{1,3}(\\.\\d{1,3}){3}$").matches(ip)) return toast("Type the address shown on the camera phone, like 192.168.1.23")
        if (pin.length != 6) return toast("Type the 6-digit PIN shown on the camera phone.")
        overlay(OverlayService.A_TILE) {
            putExtra("type", "remote")
            putExtra("ip", ip)
            putExtra("pin", pin)
            putExtra("size", tileSizeKey())
        }
        lastPin = pin
        b.etCamPin.setText("")
    }

    private fun renderOverlay() {
        val on = OverlayState.running.value
        b.btnOverlay.text = if (on) "Stop floating tools" else "Start floating tools"
        b.tvOverlayState.text = if (on) "Floating tools are ON. Tap the neon bubble on your screen."
        else "Floating tools are OFF."
        b.tvTileCount.text = "Tiles on screen: ${OverlayState.tiles.value} / 10"
    }

    // ---------- AI and voice ----------
    private fun setupTools() {
        b.btnThumbBg.setOnClickListener { thumbBgPicker.launch(arrayOf("image/*")) }
        b.btnMakeThumb.setOnClickListener { makeAndUseThumbnail() }
        b.etThumbText.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b4: Int, c: Int) { renderThumbPreview() }
            override fun afterTextChanged(s: Editable?) {}
        })
        b.spThumbStyle.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) { renderThumbPreview() }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        b.btnSeo.setOnClickListener { makeSeo() }
        b.btnSeoApply.setOnClickListener { applySeoAll() }
        b.btnApplyIdea.setOnClickListener { applyNextTitle() }
        b.btnAiVideo.setOnClickListener { aiPicker.launch(arrayOf("video/*", "image/*")) }
        setupVoice()
    }

    /** Voice studio: every change applies instantly, also while you are live. */
    private fun setupVoice() {
        Live.voiceStudio.value = ov.getBoolean("v_studio", false)
        Live.voiceMode.value = ov.getInt("v_mode", 0)
        Live.voiceDenoise.value = ov.getBoolean("v_denoise", true)
        Live.voiceGate.value = ov.getInt("v_gate", 0)
        Live.voicePitch.value = ov.getInt("v_pitch", 100)
        Live.voiceGain.value = ov.getInt("v_gain", 100)

        b.swVoiceStudio.isChecked = Live.voiceStudio.value
        b.swVoiceStudio.setOnCheckedChangeListener { _, on ->
            Live.voiceStudio.value = on
            ov.edit().putBoolean("v_studio", on).apply()
        }
        b.swVoiceDenoise.isChecked = Live.voiceDenoise.value
        b.swVoiceDenoise.setOnCheckedChangeListener { _, on ->
            Live.voiceDenoise.value = on
            ov.edit().putBoolean("v_denoise", on).apply()
        }
        b.spVoiceMode.setSelection(Live.voiceMode.value.coerceIn(0, Live.voiceNames.size - 1))
        b.spVoiceMode.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                Live.voiceMode.value = pos
                ov.edit().putInt("v_mode", pos).apply()
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        fun voiceSeek(sb: SeekBar, label: TextView, key: String, offset: Int, value: Int, flow: (Int) -> Unit, fmt: (Int) -> String) {
            sb.progress = (value - offset).coerceIn(0, sb.max)
            label.text = fmt(sb.progress + offset)
            sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    label.text = fmt(p + offset)
                    flow(p + offset)
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {
                    ov.edit().putInt(key, s?.progress?.plus(offset) ?: value).apply()
                }
            })
        }
        voiceSeek(b.sbVoiceGate, b.tvVoiceGate, "v_gate", 0, Live.voiceGate.value, { Live.voiceGate.value = it }) {
            "Cut background voices and hiss: " + (if (it == 0) "off" else "$it%")
        }
        voiceSeek(b.sbVoicePitch, b.tvVoicePitch, "v_pitch", 50, Live.voicePitch.value, { Live.voicePitch.value = it }) {
            "Custom pitch $it% (use the Custom pitch effect)"
        }
        voiceSeek(b.sbVoiceGain, b.tvVoiceGain, "v_gain", 0, Live.voiceGain.value, { Live.voiceGain.value = it }) {
            "Microphone loudness $it%"
        }
    }

    private fun scaleDown(src: Bitmap, maxW: Int): Bitmap =
        if (src.width <= maxW) src else Bitmap.createScaledBitmap(src, maxW, maxOf(1, src.height * maxW / src.width), true)

    /** The AI looks at a video or screenshot, then fills the SEO pack and the thumbnail background. */
    private fun runAi(uri: Uri) {
        runCatching { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
        b.btnAiVideo.isEnabled = false
        b.tvAiStatus.text = "AI is starting..."
        lifecycleScope.launch {
            try {
                val r = VideoAi.analyze(applicationContext, uri) { st -> runOnUiThread { b.tvAiStatus.text = st } }
                aiWords = (r.labels + r.words).distinct()
                if (b.etTopic.text.isNullOrBlank() && r.labels.isNotEmpty()) {
                    b.etTopic.setText(r.labels.first().replaceFirstChar { c -> c.uppercase() })
                }
                r.bestFrame?.let { thumbBg = withContext(Dispatchers.Default) { scaleDown(it, 1600) } }
                b.tvAiStatus.text = "AI saw: " + (r.labels.joinToString(", ").ifEmpty { "nothing clear" }) +
                    (if (r.words.isNotEmpty()) "\nText on screen: " + r.words.joinToString(", ") else "") +
                    (if (r.bestFrame != null) "\nBest frame chosen for your thumbnail." else "")
                makeSeo()
                renderThumbPreview()
            } catch (e: Exception) {
                b.tvAiStatus.text = "The AI could not read that file: ${e.message}"
            } finally {
                b.btnAiVideo.isEnabled = true
            }
        }
    }

    private fun makeSeo() {
        val topic = b.etTopic.text.toString().trim()
        val about = b.etAbout.text.toString().trim()
        if (topic.isEmpty() && about.isEmpty() && aiWords.isEmpty()) return toast("Type your game or video name first.")
        val pack = SeoEngine.build(topic, about, b.spSeoLang.selectedItemPosition, b.spSeoKind.selectedItemPosition, aiWords)
        seoPack = pack
        titleIndex = 0
        val sb = StringBuilder("Best titles (SEO score):\n")
        pack.titles.forEachIndexed { i, t -> sb.append("${i + 1}. ${t.first}  (${t.second})\n") }
        sb.append("\nTags (${pack.tags.length} of 500 characters):\n${pack.tags}\n")
        sb.append("\nKeywords:\n${pack.keywords.joinToString(", ")}\n")
        sb.append("\nThumbnail text ideas:\n${pack.thumbTexts.joinToString("\n") { "- " + it.replace("\n", " / ") }}")
        b.tvIdeas.text = sb.toString()
    }

    /** One tap: best title, description, tags and a finished thumbnail, all applied to your next stream. */
    private fun applySeoAll() {
        if (seoPack == null) makeSeo()
        val p = seoPack ?: return
        b.etTitle.setText(p.titles.first().first)
        b.etDescription.setText(p.description)
        b.etTags.setText(p.tags)
        b.etThumbText.setText(p.thumbTexts.first())
        makeAndUseThumbnail()
        save()
        toast("Applied title, description, tags and thumbnail. Check the Live tab.")
    }

    private fun applyNextTitle() {
        val p = seoPack ?: return toast("Tap Generate SEO pack first.")
        b.etTitle.setText(p.titles[titleIndex % p.titles.size].first)
        titleIndex++
        save()
        toast("Title applied. Check the Live tab.")
    }

    // ---------- thumbnail maker (drawn away from the screen thread, so typing never lags) ----------
    private fun loadThumbBg(uri: Uri) {
        lifecycleScope.launch {
            val bmp = withContext(Dispatchers.IO) {
                runCatching {
                    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                    contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
                    val opts = BitmapFactory.Options().apply { inSampleSize = maxOf(1, bounds.outWidth / 1600) }
                    contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                }.getOrNull()
            }
            if (bmp == null) toast("Could not open that picture.") else {
                thumbBg = bmp
                renderThumbPreview()
            }
        }
    }

    private fun thumbSpec() = ThumbSpec(
        b.etThumbText.text.toString().ifBlank { "LIVE NOW" }.uppercase(),
        thumbColors[b.spThumbStyle.selectedItemPosition.coerceIn(0, thumbColors.size - 1)],
        thumbBg,
    )

    private fun makeThumbnail(spec: ThumbSpec, w: Int, h: Int): Bitmap {
        val k = w / 1280f
        val neon = spec.neon
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)

        val bg = spec.bg
        if (bg != null) {
            val s = maxOf(w / bg.width.toFloat(), h / bg.height.toFloat())
            val dw = bg.width * s
            val dh = bg.height * s
            c.drawBitmap(bg, null, RectF((w - dw) / 2, (h - dh) / 2, (w + dw) / 2, (h + dh) / 2), Paint(Paint.FILTER_BITMAP_FLAG))
            c.drawColor(0x66000000)
        } else {
            val p = Paint()
            p.shader = LinearGradient(
                0f, 0f, w.toFloat(), h.toFloat(),
                intArrayOf(0xFF1B0B3A.toInt(), 0xFF0A2A5E.toInt(), 0xFF3A0B3A.toInt()), null, Shader.TileMode.CLAMP,
            )
            c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p)
        }

        val text = spec.text
        val tp = TextPaint(Paint.ANTI_ALIAS_FLAG)
        tp.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        tp.color = Color.WHITE
        tp.setShadowLayer(40f * k, 0f, 0f, neon)
        var size = 150f * k
        val width = maxOf(10, (w - 200f * k).toInt())
        fun build(): StaticLayout {
            tp.textSize = size
            return StaticLayout.Builder.obtain(text, 0, text.length, tp, width)
                .setAlignment(Layout.Alignment.ALIGN_CENTER).build()
        }
        var layout = build()
        while (layout.height > h - 260f * k && size > 50f * k) {
            size -= 8f * k
            layout = build()
        }
        c.save()
        c.translate(100f * k, (h - layout.height) / 2f - 30f * k)
        layout.draw(c)
        c.restore()

        val border = Paint(Paint.ANTI_ALIAS_FLAG)
        border.style = Paint.Style.STROKE
        border.strokeWidth = 14f * k
        border.color = neon
        border.setShadowLayer(30f * k, 0f, 0f, neon)
        c.drawRoundRect(RectF(24f * k, 24f * k, w - 24f * k, h - 24f * k), 40f * k, 40f * k, border)

        val np = TextPaint(Paint.ANTI_ALIAS_FLAG)
        np.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        np.textSize = 48f * k
        np.color = Color.WHITE
        np.textAlign = Paint.Align.CENTER
        np.setShadowLayer(20f * k, 0f, 0f, neon)
        c.drawText("PRO EDITZ NEW", w / 2f, h - 60f * k, np)
        return bmp
    }

    /** Half-size preview, drawn after you stop typing for a moment, away from the screen thread. */
    private fun renderThumbPreview() {
        thumbJob?.cancel()
        thumbJob = lifecycleScope.launch {
            delay(350)
            val spec = thumbSpec()
            val bmp = withContext(Dispatchers.Default) { makeThumbnail(spec, 640, 360) }
            b.ivThumbPreview.setImageBitmap(bmp)
        }
    }

    private fun makeAndUseThumbnail() {
        val spec = thumbSpec()
        lifecycleScope.launch {
            try {
                val f = withContext(Dispatchers.Default) {
                    val bmp = makeThumbnail(spec, 1280, 720)
                    val file = File(filesDir, "made_thumbnail.jpg")
                    FileOutputStream(file).use { bmp.compress(Bitmap.CompressFormat.JPEG, 92, it) }
                    file
                }
                thumb = Uri.fromFile(f).toString()
                refresh(); save()
                toast("Thumbnail ready. It is used for your next stream.")
            } catch (e: Exception) {
                toast("Could not save the thumbnail: ${e.message}")
            }
        }
    }

    // ---------- settings page ----------
    private fun setupSettings() {
        // Performance
        bindSwitch(b.swLite, "lite", false) { Live.lite.value = it }
        bindSeek(b.sbFxDensity, b.tvFxDensity, "fx_density", 100, 20) { "Amount of effects $it%" }
        bindSwitch(b.swAutoReconnect, "auto_reconnect", true) { Live.autoReconnect.value = it }
        bindSwitch(b.swCustomBitrate, "custom_br", false)
        bindSeek(b.sbBitrate, b.tvBitrate, "br_kbps", 2500, 500) { "Video bitrate $it kbps" }

        // Bubble and bar
        bindSeek(b.sbBubbleSize, b.tvBubbleSize, "bubble_size", 64, 40) { "Bubble size $it" }
        bindSeek(b.sbBubbleAlpha, b.tvBubbleAlpha, "bubble_alpha", 100, 30) { "Bubble visibility $it%" }
        bindSpin(b.spBarPos, "bar_pos", 0)
        bindSeek(b.sbBarAlpha, b.tvBarAlpha, "bar_alpha", 90, 40) { "Top bar background $it%" }
        bindSpin(b.spBarHide, "bar_hide", 0)

        // Pop-ups
        bindSpin(b.spPopupStyle, "popup_style", 0)
        bindSeek(b.sbPopupTime, b.tvPopupTime, "popup_time", 5, 2) { "Time on screen $it seconds" }
        bindSeek(b.sbPopupScale, b.tvPopupScale, "popup_scale", 100, 80) { "Size $it%" }
        b.btnPopupPreview.setOnClickListener { overlay(OverlayService.A_FX) { putExtra("fx", "popup_test") } }

        // Subscriber alerts
        bindSwitch(b.swSubAlert, "sub_alert", true)
        bindSwitch(b.swSubTts, "sub_tts", true)
        b.btnSubSound.setOnClickListener { subSoundPicker.launch(arrayOf("audio/*")) }
        b.btnSubMeme.setOnClickListener { subMemePicker.launch(arrayOf("image/*")) }
        b.btnTestAlert.setOnClickListener { overlay(OverlayService.A_FX) { putExtra("fx", "alert_test") } }
        refreshSubFiles()

        // Voice reader
        b.swReadChat.setOnCheckedChangeListener { btn, on ->
            if (btn.isPressed) overlay(OverlayService.A_READ) { putExtra("on", on) }
        }
        bindSpin(b.spVoiceLang, "tts_lang", 0)
        bindSeek(b.sbVoiceRate, b.tvVoiceRate, "tts_rate", 100, 50) { "Voice speed $it%" }

        b.btnResetSettings.setOnClickListener {
            AlertDialog.Builder(this)
                .setMessage("Reset every setting to normal? Your Google sign-in is kept.")
                .setPositiveButton("Reset") { _, _ ->
                    val ch = channel
                    ov.edit().clear().apply()
                    prefs.edit().clear().putString("channel", ch).apply()
                    Live.lite.value = false
                    Live.autoReconnect.value = true
                    recreate()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
    }

    // ---------- UI ----------
    private val phaseLabel = mapOf(
        "idle" to "Off air", "creating" to "Getting ready", "starting" to "Getting ready",
        "waiting" to "Connecting", "live" to "ON AIR", "ending" to "Ending", "error" to "Problem",
    )

    private fun setPulse(on: Boolean) {
        if (on && pulse == null && !Live.lite.value) {
            val a = ObjectAnimator.ofPropertyValuesHolder(
                b.btnLive,
                PropertyValuesHolder.ofFloat("scaleX", 1f, 1.04f),
                PropertyValuesHolder.ofFloat("scaleY", 1f, 1.04f),
            )
            a.duration = 700L
            a.repeatCount = ValueAnimator.INFINITE
            a.repeatMode = ValueAnimator.REVERSE
            a.start()
            pulse = a
        } else if (!on) {
            pulse?.cancel()
            pulse = null
            b.btnLive.scaleX = 1f
            b.btnLive.scaleY = 1f
        }
    }

    private fun render(s: Live.State) {
        b.tvPhase.text = phaseLabel[s.phase] ?: s.phase
        b.tvPhase.setTextColor(ContextCompat.getColor(this, if (s.phase == "live") R.color.air else R.color.muted))
        b.tvStatus.text = s.text
        val running = s.phase in listOf("creating", "starting", "waiting", "live", "ending")
        b.btnLive.text = when {
            s.phase == "ending" -> "Ending..."
            running -> "END STREAM"
            else -> "GO LIVE"
        }
        b.btnLive.isEnabled = s.phase !in listOf("creating", "starting", "ending")
        b.btnOpen.visibility = if (running && s.url.isNotEmpty()) View.VISIBLE else View.GONE
        if (!running) b.tvTimer.text = "00:00:00"
        setPulse(s.phase == "live")
    }

    private fun refresh() {
        b.tvVolume.text = "Music volume ${b.sbVolume.progress}%"
        b.tvMusic.text = if (music.isEmpty()) "No music added. Songs you add play one after another in a loop."
        else "${music.size} song${if (music.size == 1) "" else "s"} will loop: " +
            music.take(3).joinToString(", ") { Uri.parse(it).lastPathSegment?.substringAfterLast('/') ?: "track" } +
            if (music.size > 3) "..." else ""
        b.btnClearMusic.visibility = if (music.isEmpty()) View.GONE else View.VISIBLE
        b.tvVideos.text = if (videos.isEmpty()) "No videos chosen. Your videos play full screen in the app and loop."
        else "${videos.size} video${if (videos.size == 1) "" else "s"} will loop: " +
            videos.take(3).joinToString(", ") { Uri.parse(it).lastPathSegment?.substringAfterLast('/') ?: "video" } +
            if (videos.size > 3) "..." else ""
        b.btnClearVideos.visibility = if (videos.isEmpty()) View.GONE else View.VISIBLE
        b.tvThumb.text = thumb?.let { Uri.parse(it).lastPathSegment?.substringAfterLast('/') ?: "Thumbnail chosen" } ?: "No thumbnail"
    }

    // ---------- saved settings ----------
    private fun save() {
        prefs.edit()
            .putString("title", b.etTitle.text.toString())
            .putString("description", b.etDescription.text.toString())
            .putString("tags", b.etTags.text.toString())
            .putInt("privacy", b.spPrivacy.selectedItemPosition)
            .putInt("quality", b.spQuality.selectedItemPosition)
            .putBoolean("portrait", b.swPortrait.isChecked)
            .putBoolean("mic", b.swMic.isChecked)
            .putBoolean("shuffle", b.swShuffle.isChecked)
            .putInt("volume", b.sbVolume.progress)
            .putString("thumb", thumb)
            .putString("music", music.joinToString("\n"))
            .putBoolean("videoMode", b.swVideo.isChecked)
            .putBoolean("videoDim", b.swDim.isChecked)
            .putString("videos", videos.joinToString("\n"))
            .apply()
    }

    private fun restore() {
        b.etTitle.setText(prefs.getString("title", "Pro Editz NEW | Live"))
        b.etDescription.setText(prefs.getString("description", "Live on Pro Editz NEW. Like, subscribe and turn on notifications!"))
        b.etTags.setText(prefs.getString("tags", "Pro Editz NEW, live, gaming"))
        b.spPrivacy.setSelection(prefs.getInt("privacy", 0))
        b.spQuality.setSelection(prefs.getInt("quality", 1))
        b.swPortrait.isChecked = prefs.getBoolean("portrait", false)
        b.swMic.isChecked = prefs.getBoolean("mic", false)
        b.swShuffle.isChecked = prefs.getBoolean("shuffle", false)
        b.sbVolume.progress = prefs.getInt("volume", 25)
        b.swVideo.isChecked = prefs.getBoolean("videoMode", false)
        b.swDim.isChecked = prefs.getBoolean("videoDim", true)
        videos.clear()
        prefs.getString("videos", "")?.split("\n")?.filter { it.isNotBlank() }?.let { videos.addAll(it) }
        thumb = prefs.getString("thumb", null)
        music.clear()
        prefs.getString("music", "")?.split("\n")?.filter { it.isNotBlank() }?.let { music.addAll(it) }
        setChannel(prefs.getString("channel", null))
    }

    private fun hms(sec: Long) = "%02d:%02d:%02d".format(sec / 3600, (sec / 60) % 60, sec % 60)
    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()
}
