package com.proeditz.livestudio

import android.Manifest
import android.animation.Animator
import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Outline
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.TextUtils
import android.text.style.StyleSpan
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.view.animation.BounceInterpolator
import android.view.animation.DecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import android.widget.VideoView
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.URL
import java.util.Locale
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

/**
 * Floating studio tools on top of your game or video. The app streams the whole screen, so everything shown here
 * (bubble, bar, face cam, tiles, texts, comment box, effects, pop-ups, pause screen) is part of the stream.
 * Performance: the effects layer exists only while an effect is playing, blur is optional and Lite mode cuts the rest.
 */
class OverlayService : LifecycleService() {

    companion object {
        const val A_SHOW = "com.proeditz.livestudio.OVERLAY_SHOW"
        const val A_STOP = "com.proeditz.livestudio.OVERLAY_STOP"
        const val A_TILE = "com.proeditz.livestudio.OVERLAY_TILE"
        const val A_TILEEDIT = "com.proeditz.livestudio.OVERLAY_TILEEDIT"
        const val A_CLEAR = "com.proeditz.livestudio.OVERLAY_CLEAR"
        const val A_FX = "com.proeditz.livestudio.OVERLAY_FX"
        const val A_BRB = "com.proeditz.livestudio.OVERLAY_BRB"
        const val A_READ = "com.proeditz.livestudio.OVERLAY_READ"
        const val A_CFG = "com.proeditz.livestudio.OVERLAY_CFG"
        const val A_CMTPOS = "com.proeditz.livestudio.OVERLAY_CMTPOS"
        const val A_CMTBOX = "com.proeditz.livestudio.OVERLAY_CMTBOX"
        const val A_TEXT = "com.proeditz.livestudio.OVERLAY_TEXT"
        const val A_TEXTCLEAR = "com.proeditz.livestudio.OVERLAY_TEXTCLEAR"

        private const val CHANNEL = "overlay"
        private const val NOTIF_ID = 8
        private const val MAX_TILES = 10
        private const val MAX_TEXTS = 6

        private val CYAN = 0xFF00F0FF.toInt()
        private val PINK = 0xFFFF2BD6.toInt()
        private val VIOLET = 0xFF8F5BFF.toInt()
        private val GREEN = 0xFF39FF88.toInt()
        private val RED = 0xFFFF2D55.toInt()
        private val PANEL = 0xFF12142A.toInt()

        fun start(ctx: Context) {
            ContextCompat.startForegroundService(ctx, Intent(ctx, OverlayService::class.java).setAction(A_SHOW))
        }

        fun send(ctx: Context, action: String, extra: Intent.() -> Unit = {}) {
            if (!OverlayState.running.value) return
            ctx.startService(Intent(ctx, OverlayService::class.java).setAction(action).apply(extra))
        }
    }

    private class Tile(val box: FrameLayout, val type: String, val p: WindowManager.LayoutParams, val label: String) {
        var mp: MediaPlayer? = null
        var job: Job? = null
        var loop = true
        var mute = true
    }

    private lateinit var wm: WindowManager
    private lateinit var sp: SharedPreferences
    private val ui = Handler(Looper.getMainLooper())
    private var density = 1f
    private var running = false

    private var bubble: FrameLayout? = null
    private var bubbleParams: WindowManager.LayoutParams? = null
    private var bar: LinearLayout? = null
    private var fx: FrameLayout? = null
    private var brb: View? = null
    private var fxRow: View? = null
    private var avatarView: ImageView? = null
    private var tvLikes: TextView? = null
    private var tvSubs: TextView? = null
    private var tvViewers: TextView? = null
    private var chipRead: TextView? = null
    private var chipMic: TextView? = null
    private var chipVol: TextView? = null
    private var chipVoice: TextView? = null
    private var barPosApplied = -1
    private var barAlphaApplied = -1

    private var cmtBox: FrameLayout? = null
    private var cmtList: LinearLayout? = null
    private var cmtParams: WindowManager.LayoutParams? = null

    private val tiles = mutableListOf<Tile>()
    private var camTile: Tile? = null
    private val texts = mutableListOf<FrameLayout>()
    private val textAnims = mutableMapOf<View, Animator>()

    private var statsJob: Job? = null
    private var chatJob: Job? = null
    private var subJob: Job? = null
    private var chatAcquired = false
    private var tts: TextToSpeech? = null
    private var readChat = false
    private var channelName = "Pro Editz NEW"
    private var avatarLoaded = false
    private var subsNow: Long? = null
    private var subsStart: Long? = null
    private var subsGained = 0
    private var micBeforePause = false

    private val hideBar = Runnable { bar?.visibility = View.GONE }

    private val cmtColors = intArrayOf(
        Color.WHITE, 0xFF00F0FF.toInt(), 0xFFFF2BD6.toInt(), 0xFFFFE600.toInt(),
        0xFF39FF88.toInt(), 0xFFFF9A00.toInt(), 0xFF111111.toInt(), 0xFFFF4D4D.toInt(),
    )
    private val textColors = intArrayOf(
        Color.WHITE, 0xFF00F0FF.toInt(), 0xFFFF2BD6.toInt(), 0xFFFFE600.toInt(), 0xFF39FF88.toInt(),
        0xFFFF9A00.toInt(), 0xFFFF4D4D.toInt(), 0xFF8F5BFF.toInt(), 0xFF111111.toInt(), 0xFFFFD700.toInt(),
    )

    private val circleOutline = object : ViewOutlineProvider() {
        override fun getOutline(view: View, outline: Outline) {
            outline.setOval(0, 0, view.width, view.height)
        }
    }

    private fun roundOutline(radius: Int) = object : ViewOutlineProvider() {
        override fun getOutline(view: View, outline: Outline) {
            outline.setRoundRect(0, 0, view.width, view.height, radius.toFloat())
        }
    }

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        sp = getSharedPreferences("overlay", Context.MODE_PRIVATE)
        density = resources.displayMetrics.density
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        val cmd = intent ?: return START_NOT_STICKY
        when (cmd.action) {
            A_SHOW -> show()
            A_STOP -> shutdown()
            A_TILE -> if (running) {
                addTile(
                    cmd.getStringExtra("type") ?: "",
                    cmd.getStringExtra("uri"),
                    cmd.getStringExtra("size") ?: "medium",
                    cmd.getBooleanExtra("circle", false),
                    cmd.getStringExtra("ip") ?: "",
                    cmd.getStringExtra("pin") ?: "",
                    cmd.getBooleanExtra("loop", true),
                )
            }
            A_TILEEDIT -> if (running) {
                editTile(
                    cmd.getIntExtra("i", 0), cmd.getIntExtra("w", -1), cmd.getIntExtra("h", -1),
                    cmd.getIntExtra("x", -1), cmd.getIntExtra("y", -1), cmd.getIntExtra("alpha", -1),
                    cmd.getIntExtra("loop", -1), cmd.getIntExtra("mute", -1),
                )
            }
            A_CLEAR -> clearTiles()
            A_FX -> if (running) runFx(cmd.getStringExtra("fx") ?: "", cmd.getStringExtra("title") ?: "", cmd.getStringExtra("sub") ?: "")
            A_BRB -> if (running) toggleBrb()
            A_READ -> if (running) setReadChat(cmd.getBooleanExtra("on", false))
            A_CFG -> if (running) applyCfg()
            A_CMTPOS -> if (running) setCommentPos(cmd.getStringExtra("pos") ?: "")
            A_CMTBOX -> if (running) setCommentBox(
                cmd.getIntExtra("w", -1), cmd.getIntExtra("h", -1), cmd.getIntExtra("x", -1), cmd.getIntExtra("y", -1),
            )
            A_TEXT -> if (running) addText(cmd)
            A_TEXTCLEAR -> clearTexts()
        }
        return START_NOT_STICKY
    }

    // ---------------------------------------------------------------- setup

    private fun dp(v: Int): Int = (v * density).toInt()
    private fun si(key: String, def: Int): Int = sp.getInt(key, def)

    private fun show() {
        startForegroundCompat()
        if (running) return
        if (!Settings.canDrawOverlays(this)) {
            toast("Allow Display over other apps for Pro Editz Live first.")
            stopSelf()
            return
        }
        running = true
        OverlayState.running.value = true
        buildBar()
        buildBubble()
        startStats()
        startSubAlerts()
        lifecycleScope.launch { Live.micOn.collect { updateMicChip(it) } }
        lifecycleScope.launch { Live.musicVolume.collect { chipVol?.text = "♪ $it%" } }
        lifecycleScope.launch {
            Live.voiceMode.collect {
                chipVoice?.text = "🎙 Voice: ${Live.voiceNames[it.coerceIn(0, Live.voiceNames.size - 1)]}"
            }
        }
        applyCfg()
    }

    private fun startForegroundCompat() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Floating tools", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(
            this, 3, Intent(this, OverlayService::class.java).setAction(A_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val n = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("Pro Editz floating tools")
            .setContentText("Tap the neon bubble on your screen to open the tools")
            .setOngoing(true)
            .addAction(0, "Close tools", stop)
            .build()
        val cam = ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        val type = if (cam) ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA else ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
        ServiceCompat.startForeground(this, NOTIF_ID, n, type)
    }

    private fun params(w: Int, h: Int, touchable: Boolean = true): WindowManager.LayoutParams {
        var flags = WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        if (!touchable) flags = flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        val p = WindowManager.LayoutParams(
            w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, flags, PixelFormat.TRANSLUCENT,
        )
        p.gravity = Gravity.TOP or Gravity.START
        return p
    }

    private fun neon(
        corner: Float,
        color: Int,
        fill: Int = 0xCC0A0B14.toInt(),
        stroke: Int = 2,
        oval: Boolean = false,
    ): GradientDrawable {
        val g = GradientDrawable()
        g.shape = if (oval) GradientDrawable.OVAL else GradientDrawable.RECTANGLE
        g.cornerRadius = corner
        g.setColor(fill)
        g.setStroke(dp(stroke), color)
        return g
    }

    private fun chip(label: String, color: Int = CYAN, onClick: (() -> Unit)? = null): TextView {
        val t = TextView(this)
        t.text = label
        t.setTextColor(Color.WHITE)
        t.textSize = 13f
        t.setTypeface(null, Typeface.BOLD)
        t.setShadowLayer(8f, 0f, 0f, color)
        t.setPadding(dp(12), dp(8), dp(12), dp(8))
        t.background = neon(dp(14).toFloat(), color)
        t.gravity = Gravity.CENTER
        if (onClick != null) t.setOnClickListener { onClick() }
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.setMargins(dp(4), dp(2), dp(4), dp(2))
        t.layoutParams = lp
        return t
    }

    // ---------------------------------------------------------------- bubble and bar

    private fun buildBar() {
        val pos = si("bar_pos", 0)
        val alpha = si("bar_alpha", 90)
        barPosApplied = pos
        barAlphaApplied = alpha

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Color.argb((alpha * 2.55f).toInt().coerceIn(0, 255), 10, 11, 20))
        if (pos == 1) root.setPadding(dp(6), dp(6), dp(6), dp(26)) else root.setPadding(dp(6), dp(30), dp(6), dp(6))

        val scroll1 = HorizontalScrollView(this)
        scroll1.isHorizontalScrollBarEnabled = false
        val line1 = LinearLayout(this)
        line1.orientation = LinearLayout.HORIZONTAL
        val likes = chip("👍 --", GREEN)
        val subs = chip("🔔 SUBS --", RED)
        subs.background = neon(dp(14).toFloat(), 0xFFFFFFFF.toInt(), fill = RED, stroke = 1)
        val viewers = chip("👁 --", CYAN)
        tvLikes = likes
        tvSubs = subs
        tvViewers = viewers
        line1.addView(likes)
        line1.addView(subs)
        line1.addView(viewers)
        line1.addView(chip("⏸ Pause", PINK) { toggleBrb() })
        val read = chip(if (readChat) "💬 Reading: ON" else "💬 Read comments", VIOLET) { setReadChat(!readChat) }
        chipRead = read
        line1.addView(read)
        line1.addView(chip("✨ FX", PINK) {
            val r = fxRow
            if (r != null) r.visibility = if (r.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        })
        line1.addView(chip("✖ Close tools", PINK) { shutdown() })
        scroll1.addView(line1)
        root.addView(scroll1)

        val scroll2 = HorizontalScrollView(this)
        scroll2.isHorizontalScrollBarEnabled = false
        val line2 = LinearLayout(this)
        line2.orientation = LinearLayout.HORIZONTAL
        val mic = chip("🔇 Mic OFF", PINK) { Live.micOn.value = !Live.micOn.value }
        chipMic = mic
        line2.addView(mic)
        val voiceChip = chip("🎙 Voice: ${Live.voiceNames[Live.voiceMode.value.coerceIn(0, Live.voiceNames.size - 1)]}", VIOLET) {
            Live.voiceMode.value = (Live.voiceMode.value + 1) % Live.voiceNames.size
        }
        chipVoice = voiceChip
        line2.addView(voiceChip)
        line2.addView(chip("⏮", CYAN) { Live.commands.tryEmit("music_prev") })
        line2.addView(chip("⏯", CYAN) { Live.commands.tryEmit("music_toggle") })
        line2.addView(chip("⏭", CYAN) { Live.commands.tryEmit("music_next") })
        line2.addView(chip("🔉", GREEN) { Live.musicVolume.value = (Live.musicVolume.value - 5).coerceAtLeast(0) })
        val vol = chip("♪ ${Live.musicVolume.value}%", GREEN)
        chipVol = vol
        line2.addView(vol)
        line2.addView(chip("🔊", GREEN) { Live.musicVolume.value = (Live.musicVolume.value + 5).coerceAtMost(100) })
        scroll2.addView(line2)
        root.addView(scroll2)

        val scroll3 = HorizontalScrollView(this)
        scroll3.isHorizontalScrollBarEnabled = false
        val line3 = LinearLayout(this)
        line3.orientation = LinearLayout.HORIZONTAL
        line3.addView(chip("🎉 Confetti", PINK) { runFx("confetti") })
        line3.addView(chip("🪙 3D Coins", VIOLET) { runFx("coins3d") })
        line3.addView(chip("💖 3D Hearts", PINK) { runFx("hearts3d") })
        line3.addView(chip("🎆 Fireworks", CYAN) { runFx("fireworks") })
        line3.addView(chip("🔵 Shockwave", CYAN) { runFx("ring") })
        line3.addView(chip("🔔 Subscribe", RED) { runFx("sub") })
        line3.addView(chip("👍 Like", GREEN) { runFx("like") })
        line3.addView(chip("⚡ Flash", VIOLET) { runFx("flash") })
        scroll3.addView(line3)
        scroll3.visibility = View.GONE
        fxRow = scroll3
        root.addView(scroll3)

        root.visibility = View.GONE
        bar = root
        val p = params(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        p.gravity = if (pos == 1) Gravity.BOTTOM or Gravity.START else Gravity.TOP or Gravity.START
        wm.addView(root, p)
    }

    private fun rebuildBar() {
        val old = bar
        val vis = old?.visibility ?: View.GONE
        old?.let { v -> runCatching { wm.removeView(v) } }
        bar = null
        buildBar()
        bar?.visibility = vis
        updateMicChip(Live.micOn.value)
    }

    private fun updateMicChip(on: Boolean) {
        val c = chipMic ?: return
        c.text = if (on) "🎙 Mic ON" else "🔇 Mic OFF"
        c.background = neon(dp(14).toFloat(), if (on) GREEN else PINK)
    }

    private fun toggleBar() {
        val b = bar ?: return
        ui.removeCallbacks(hideBar)
        if (b.visibility == View.VISIBLE) {
            b.visibility = View.GONE
            return
        }
        b.visibility = View.VISIBLE
        val secs = intArrayOf(0, 3, 5, 10)[si("bar_hide", 0).coerceIn(0, 3)]
        if (secs > 0) ui.postDelayed(hideBar, secs * 1000L)
    }

    private fun buildBubble() {
        val ring = FrameLayout(this)
        ring.setPadding(dp(3), dp(3), dp(3), dp(3))
        ring.background = neon(0f, PINK, fill = PANEL, stroke = 3, oval = true)

        val inner = FrameLayout(this)
        inner.clipToOutline = true
        inner.outlineProvider = circleOutline

        val label = TextView(this)
        label.text = "PE"
        label.setTextColor(Color.WHITE)
        label.gravity = Gravity.CENTER
        label.textSize = 18f
        label.setTypeface(null, Typeface.BOLD)

        val img = ImageView(this)
        img.scaleType = ImageView.ScaleType.CENTER_CROP
        avatarView = img

        inner.addView(label, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        inner.addView(img, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        ring.addView(inner, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        val size = dp(si("bubble_size", 64))
        val p = params(size, size)
        p.x = dp(12)
        p.y = dp(200)
        bubble = ring
        bubbleParams = p
        ring.alpha = si("bubble_alpha", 100) / 100f
        attachDrag(ring, p, dp(36), dp(240), onTap = { toggleBar() })
        wm.addView(ring, p)
    }

    /** Drag with one finger, pinch to resize, tap and long-press. [scaleHook] replaces the window resize (used by texts). */
    @SuppressLint("ClickableViewAccessibility")
    private fun attachDrag(
        v: View,
        p: WindowManager.LayoutParams,
        minSize: Int,
        maxSize: Int,
        onTap: (() -> Unit)? = null,
        onLong: (() -> Unit)? = null,
        onEnd: (() -> Unit)? = null,
        scaleHook: ((Float) -> Unit)? = null,
    ) {
        val sd = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                if (scaleHook != null) {
                    scaleHook(detector.scaleFactor)
                    return true
                }
                val nw = (p.width * detector.scaleFactor).toInt().coerceIn(minSize, maxSize)
                val real = nw.toFloat() / p.width
                p.width = nw
                p.height = (p.height * real).toInt().coerceAtLeast(minSize / 2)
                runCatching { wm.updateViewLayout(v, p) }
                return true
            }
        })
        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var moved = false
        var pinching = false
        var downTime = 0L
        v.setOnTouchListener { _, e ->
            sd.onTouchEvent(e)
            if (sd.isInProgress) {
                pinching = true
                return@setOnTouchListener true
            }
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX
                    downY = e.rawY
                    startX = p.x
                    startY = p.y
                    moved = false
                    pinching = false
                    downTime = System.currentTimeMillis()
                }
                MotionEvent.ACTION_MOVE -> if (!pinching && e.pointerCount == 1) {
                    val dx = (e.rawX - downX).toInt()
                    val dy = (e.rawY - downY).toInt()
                    if (abs(dx) > 12 || abs(dy) > 12) moved = true
                    if (moved) {
                        p.x = startX + dx
                        p.y = startY + dy
                        runCatching { wm.updateViewLayout(v, p) }
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved && !pinching) {
                        if (System.currentTimeMillis() - downTime > 600) onLong?.invoke() else onTap?.invoke()
                    }
                    onEnd?.invoke()
                }
                MotionEvent.ACTION_CANCEL -> onEnd?.invoke()
            }
            true
        }
    }

    // ---------------------------------------------------------------- settings from the app

    /** Reads the saved settings and applies them right now (no restart needed). */
    private fun applyCfg() {
        if (!running) return
        if (si("bar_pos", 0) != barPosApplied || si("bar_alpha", 90) != barAlphaApplied) rebuildBar()
        bubble?.alpha = si("bubble_alpha", 100) / 100f
        bubbleParams?.let { p ->
            val size = dp(si("bubble_size", 64))
            if (p.width != size) {
                p.width = size
                p.height = size
                bubble?.let { v -> runCatching { wm.updateViewLayout(v, p) } }
            }
        }
        if (sp.getBoolean("cmt_box", false)) {
            buildCommentBox()
            styleCommentBox()
        } else {
            removeCommentBox()
        }
        applyTtsLang()
        updateChatJob()
    }

    // ---------------------------------------------------------------- comment box

    private fun cmtFont(i: Int): Typeface = when (i) {
        1 -> Typeface.SERIF
        2 -> Typeface.MONOSPACE
        3 -> Typeface.create("casual", Typeface.NORMAL)
        4 -> Typeface.create("cursive", Typeface.NORMAL)
        else -> Typeface.SANS_SERIF
    }

    private fun buildCommentBox() {
        if (cmtBox != null) return
        val box = FrameLayout(this)
        box.setPadding(dp(10), dp(8), dp(10), dp(8))
        val list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        list.gravity = Gravity.BOTTOM
        box.addView(list, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        cmtBox = box
        cmtList = list
        val dm = resources.displayMetrics
        val w = dm.widthPixels * si("cmt_w", 45) / 100
        val h = dm.heightPixels * si("cmt_h", 22) / 100
        val p = params(w.coerceAtLeast(dp(120)), h.coerceAtLeast(dp(60)))
        p.x = (dm.widthPixels - p.width) * si("cmt_x", 5) / 100
        p.y = (dm.heightPixels - p.height) * si("cmt_y", 50) / 100
        cmtParams = p
        attachDrag(box, p, dp(100), dm.widthPixels)
        wm.addView(box, p)
    }

    private fun removeCommentBox() {
        cmtBox?.let { v -> runCatching { wm.removeView(v) } }
        cmtBox = null
        cmtList = null
        cmtParams = null
    }

    /** Exact size and place of the comment box, in percent of the screen (the sliders in the Studio tab). */
    private fun setCommentBox(wPct: Int, hPct: Int, xPct: Int, yPct: Int) {
        val box = cmtBox
        val p = cmtParams
        if (box == null || p == null) return
        val dm = resources.displayMetrics
        if (wPct > 0) p.width = (dm.widthPixels * wPct / 100).coerceAtLeast(dp(100))
        if (hPct > 0) p.height = (dm.heightPixels * hPct / 100).coerceAtLeast(dp(50))
        if (xPct >= 0) p.x = (dm.widthPixels - p.width) * xPct / 100
        if (yPct >= 0) p.y = (dm.heightPixels - p.height) * yPct / 100
        runCatching { wm.updateViewLayout(box, p) }
    }

    /** Quick places for the comment box. */
    private fun setCommentPos(pos: String) {
        val box = cmtBox
        val p = cmtParams
        if (box == null || p == null) {
            toast("Turn on Show live comments on the stream first.")
            return
        }
        val dm = resources.displayMetrics
        val sw = dm.widthPixels
        val sh = dm.heightPixels
        when (pos) {
            "tl" -> { p.x = dp(8); p.y = dp(40) }
            "tr" -> { p.x = sw - p.width - dp(8); p.y = dp(40) }
            "bl" -> { p.x = dp(8); p.y = sh - p.height - dp(60) }
            "br" -> { p.x = sw - p.width - dp(8); p.y = sh - p.height - dp(60) }
            "side" -> { p.x = sw - p.width - dp(8); p.y = (sh - p.height) / 2 }
        }
        runCatching { wm.updateViewLayout(box, p) }
    }

    private fun styleLine(t: TextView) {
        val a = (si("cmt_alpha", 100) * 2.55f).toInt().coerceIn(40, 255)
        val c = cmtColors[si("cmt_color", 0).coerceIn(0, cmtColors.size - 1)]
        t.setTextColor(Color.argb(a, Color.red(c), Color.green(c), Color.blue(c)))
        t.textSize = si("cmt_size", 16).toFloat()
        t.typeface = cmtFont(si("cmt_font", 0))
    }

    private fun trimComments() {
        val list = cmtList ?: return
        val max = si("cmt_lines", 2) + 2
        while (list.childCount > max) list.removeViewAt(0)
    }

    private fun styleCommentBox() {
        val box = cmtBox ?: return
        val list = cmtList ?: return
        val p = cmtParams ?: return
        val bgA = si("cmt_bg", 45)
        val glass = sp.getBoolean("cmt_glass", true)
        val neonEdge = sp.getBoolean("cmt_neon", false)
        val g = GradientDrawable()
        g.cornerRadius = dp(si("cmt_radius", 24)).toFloat()
        if (glass) {
            val a1 = (bgA * 2.2f).toInt().coerceIn(0, 255)
            val a2 = (bgA * 0.6f).toInt().coerceIn(0, 255)
            g.orientation = GradientDrawable.Orientation.TL_BR
            g.colors = intArrayOf(Color.argb(a1, 255, 255, 255), Color.argb(a2, 180, 210, 255))
            g.setStroke(dp(1), Color.argb((bgA * 2.5f).toInt().coerceIn(60, 255), 255, 255, 255))
        } else {
            g.setColor(Color.argb((bgA * 2.55f).toInt().coerceIn(0, 255), 10, 11, 20))
            g.setStroke(dp(1), Color.argb(90, 255, 255, 255))
        }
        if (neonEdge) g.setStroke(dp(3), CYAN)
        box.background = g
        // Real blur is heavy for the phone, so it is off unless you switch it on (and never in Lite mode).
        if (Build.VERSION.SDK_INT >= 31) {
            val blur = glass && sp.getBoolean("cmt_blur", false) && !Live.lite.value
            if (blur) {
                p.flags = p.flags or WindowManager.LayoutParams.FLAG_BLUR_BEHIND
                p.blurBehindRadius = dp(24)
            } else {
                p.flags = p.flags and WindowManager.LayoutParams.FLAG_BLUR_BEHIND.inv()
                p.blurBehindRadius = 0
            }
            runCatching { wm.updateViewLayout(box, p) }
        }
        for (i in 0 until list.childCount) {
            val child = list.getChildAt(i)
            if (child is TextView) styleLine(child)
        }
        trimComments()
    }

    private fun addCommentLine(author: String, text: String) {
        val list = cmtList ?: return
        val t = TextView(this)
        val sb = SpannableStringBuilder()
        if (sp.getBoolean("cmt_author", true)) {
            sb.append(author)
            sb.setSpan(StyleSpan(Typeface.BOLD), 0, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            sb.append("  ")
        }
        sb.append(text)
        t.text = sb
        t.maxLines = 2
        t.ellipsize = TextUtils.TruncateAt.END
        t.setPadding(0, dp(2), 0, dp(2))
        styleLine(t)
        list.addView(t, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        trimComments()
        if (!Live.lite.value) {
            t.alpha = 0f
            t.translationY = dp(20).toFloat()
            t.animate().alpha(1f).translationY(0f).setDuration(250L).start()
        }
    }

    // ---------------------------------------------------------------- tiles (face cam, video, picture)

    private fun addTile(type: String, uri: String?, sizeKey: String, circle: Boolean, ip: String = "", pin: String = "", loop: Boolean = true) {
        if (tiles.size >= MAX_TILES) {
            toast("Maximum is 10 tiles.")
            return
        }
        if (type == "camera") {
            if (camTile != null) {
                toast("The face cam box is already on screen.")
                return
            }
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                toast("Allow the camera permission, then stop and start floating tools again.")
                return
            }
        }
        val dm = resources.displayMetrics
        val sw = dm.widthPixels
        val sh = dm.heightPixels
        val square = type == "camera" && circle
        var w = when (sizeKey) {
            "small" -> (sw * 0.25f).toInt()
            "large" -> (sw * 0.60f).toInt()
            "half" -> sw / 2
            else -> (sw * 0.40f).toInt()
        }
        w = w.coerceIn(dp(90), sw)
        val h = when {
            sizeKey == "half" && !square -> sh
            type == "camera" -> w
            type == "remote" -> w * 4 / 3
            else -> w * 9 / 16
        }

        var tileRef: Tile? = null
        var remoteJob: Job? = null
        val content: View = when (type) {
            "remote" -> {
                val pair = makeRemote(ip, pin)
                remoteJob = pair.second
                pair.first
            }
            "camera" -> makeCamera()
            "video" -> makeVideo(uri ?: return) { mp ->
                val t = tileRef
                if (t != null) {
                    t.mp = mp
                    mp.isLooping = t.loop
                    val vol = if (t.mute) 0f else 1f
                    mp.setVolume(vol, vol)
                }
            }
            "image" -> makeImage(uri ?: return)
            else -> return
        }
        if (type != "remote") {
            content.clipToOutline = true
            content.outlineProvider = if (square) circleOutline else roundOutline(dp(14))
        }

        val color = when (type) {
            "camera" -> CYAN
            "video" -> VIOLET
            else -> GREEN
        }
        val box = FrameLayout(this)
        box.setPadding(dp(3), dp(3), dp(3), dp(3))
        box.background = neon(if (square) 0f else dp(17).toFloat(), color, fill = PANEL, stroke = 3, oval = square)
        box.addView(content, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        if (type == "remote") {
            // No frame or fill, so a see-through (background removed) face cam shows your game behind it.
            box.background = null
            box.setPadding(0, 0, 0, 0)
        }

        val p = params(w, if (square) w else h)
        val n = tiles.size
        p.x = dp(30) + n * dp(26)
        p.y = dp(120) + n * dp(26)
        val label = "${n + 1}. " + when (type) {
            "camera" -> "Face cam box"
            "remote" -> "Camera phone"
            "video" -> "Video"
            else -> "Picture"
        }
        val tile = Tile(box, type, p, label)
        tile.loop = loop
        tile.job = remoteJob
        tileRef = tile
        attachDrag(box, p, dp(40), sw, onLong = { removeTile(tile) }, onEnd = { publishTiles() })
        wm.addView(box, p)
        tiles.add(tile)
        if (type == "camera") camTile = tile
        publishTiles()
    }

    private fun makeCamera(): View {
        val pv = PreviewView(this)
        pv.implementationMode = PreviewView.ImplementationMode.COMPATIBLE
        pv.scaleType = PreviewView.ScaleType.FILL_CENTER
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            runCatching {
                val provider = future.get()
                val preview = Preview.Builder().build()
                preview.setSurfaceProvider(pv.surfaceProvider)
                provider.unbindAll()
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_FRONT_CAMERA, preview)
            }.onFailure { toast("Camera could not start: ${it.message}") }
        }, ContextCompat.getMainExecutor(this))
        return pv
    }

    private fun makeVideo(uri: String, onPlayer: (MediaPlayer) -> Unit): View {
        val v = VideoView(this)
        v.setVideoURI(Uri.parse(uri))
        v.setOnPreparedListener { mp ->
            onPlayer(mp)
            v.start()
        }
        return v
    }

    private fun makeImage(uri: String): View {
        val i = ImageView(this)
        i.scaleType = ImageView.ScaleType.CENTER_CROP
        i.setImageURI(Uri.parse(uri))
        return i
    }

    /** Face cam coming from the second phone. */
    private fun makeRemote(ip: String, pin: String): Pair<View, Job> {
        val img = ImageView(this)
        img.scaleType = ImageView.ScaleType.FIT_CENTER
        var warned = false
        val job = lifecycleScope.launch(Dispatchers.IO) {
            RemoteCam.runClient(
                ip, pin,
                onFrame = { bmp -> img.post { img.setImageBitmap(bmp) } },
                onState = { st ->
                    if (st == "connected") {
                        ui.post { toast("Camera phone connected.") }
                    } else if (st == "failed" && !warned) {
                        warned = true
                        ui.post { toast("Cannot reach the camera phone. Check the address and PIN, and that both phones are on the same Wi-Fi.") }
                    }
                },
                alive = { isActive },
            )
        }
        return Pair(img, job)
    }

    private fun removeTile(t: Tile) {
        t.job?.cancel()
        runCatching { wm.removeView(t.box) }
        tiles.remove(t)
        if (t === camTile) {
            camTile = null
            val f = ProcessCameraProvider.getInstance(this)
            f.addListener({ runCatching { f.get().unbindAll() } }, ContextCompat.getMainExecutor(this))
        }
        publishTiles()
    }

    private fun clearTiles() {
        tiles.toList().forEach { removeTile(it) }
    }

    /** Tells the app each tile's exact size and place, so the sliders always show the real numbers. */
    private fun publishTiles() {
        val dm = resources.displayMetrics
        val sw = dm.widthPixels.toFloat()
        val sh = dm.heightPixels.toFloat()
        OverlayState.tileList.value = tiles.mapIndexed { i, t ->
            val w = t.p.width
            val h = t.p.height
            val xr = if (sw - w > 1f) (t.p.x * 100f / (sw - w)).toInt().coerceIn(0, 100) else 0
            val yr = if (sh - h > 1f) (t.p.y * 100f / (sh - h)).toInt().coerceIn(0, 100) else 0
            TileGeom(
                "${i + 1}. ${t.label.substringAfter(". ")}",
                (w * 100f / sw).toInt().coerceIn(1, 100), (h * 100f / sh).toInt().coerceIn(1, 100),
                xr, yr, t.loop, t.mute, (t.box.alpha * 100).toInt().coerceIn(20, 100), t.type,
            )
        }
        OverlayState.tiles.value = tiles.size
    }

    /** Manual edit of one tile: size and place in percent, see-through level, loop and mute. -1 means leave as it is. */
    private fun editTile(i: Int, w: Int, h: Int, x: Int, y: Int, alpha: Int, loop: Int, mute: Int) {
        val t = tiles.getOrNull(i) ?: return
        val dm = resources.displayMetrics
        val sw = dm.widthPixels
        val sh = dm.heightPixels
        if (w > 0) t.p.width = (sw * w / 100).coerceAtLeast(dp(40))
        if (h > 0) t.p.height = (sh * h / 100).coerceAtLeast(dp(40))
        if (x >= 0) t.p.x = (sw - t.p.width) * x / 100
        if (y >= 0) t.p.y = (sh - t.p.height) * y / 100
        if (alpha > 0) t.box.alpha = alpha / 100f
        if (loop >= 0) {
            t.loop = loop == 1
            runCatching { t.mp?.isLooping = t.loop }
        }
        if (mute >= 0) {
            t.mute = mute == 1
            val v = if (t.mute) 0f else 1f
            runCatching { t.mp?.setVolume(v, v) }
        }
        runCatching { wm.updateViewLayout(t.box, t.p) }
        publishTiles()
    }

    // ---------------------------------------------------------------- text on screen

    private fun fontOf(i: Int): Typeface = when (i) {
        1 -> Typeface.create(Typeface.SERIF, Typeface.BOLD)
        2 -> Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        3 -> Typeface.create("casual", Typeface.BOLD)
        4 -> Typeface.create("cursive", Typeface.NORMAL)
        5 -> Typeface.create("sans-serif-condensed", Typeface.BOLD)
        6 -> Typeface.create("sans-serif-black", Typeface.NORMAL)
        7 -> Typeface.create("sans-serif-light", Typeface.NORMAL)
        8 -> Typeface.create("sans-serif-medium", Typeface.NORMAL)
        else -> Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
    }

    /** Your own text on the stream: font, size, colour, style, animation and place. Drag it, pinch to resize, long-press to remove. */
    private fun addText(cmd: Intent) {
        if (texts.size >= MAX_TEXTS) {
            toast("Maximum is 6 texts. Remove one first.")
            return
        }
        val str = cmd.getStringExtra("text").orEmpty().ifBlank { return }
        val size = cmd.getIntExtra("size", 36)
        val font = cmd.getIntExtra("font", 0)
        val color = textColors[cmd.getIntExtra("color", 1).coerceIn(0, textColors.size - 1)]
        val style = cmd.getIntExtra("style", 0)
        val anim = cmd.getIntExtra("anim", 0)
        val pos = cmd.getIntExtra("pos", 0)
        val dm = resources.displayMetrics
        val sw = dm.widthPixels
        val sh = dm.heightPixels

        val tv = TextView(this)
        tv.text = str
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, size.toFloat())
        tv.typeface = fontOf(font)
        tv.gravity = Gravity.CENTER
        val box = FrameLayout(this)
        when (style) {
            0 -> {
                tv.setTextColor(Color.WHITE)
                tv.setShadowLayer(22f, 0f, 0f, color)
                box.setPadding(dp(10), dp(6), dp(10), dp(6))
            }
            1 -> {
                tv.setTextColor(color)
                tv.setShadowLayer(4f, 2f, 2f, 0xAA000000.toInt())
                box.setPadding(dp(10), dp(6), dp(10), dp(6))
            }
            2 -> {
                tv.setTextColor(color)
                val g = GradientDrawable()
                g.cornerRadius = dp(20).toFloat()
                g.orientation = GradientDrawable.Orientation.TL_BR
                g.colors = intArrayOf(0x66FFFFFF, 0x22B4D2FF)
                g.setStroke(dp(1), 0x99FFFFFF.toInt())
                box.background = g
                box.setPadding(dp(16), dp(10), dp(16), dp(10))
            }
            else -> {
                tv.setTextColor(color)
                box.background = neon(dp(16).toFloat(), color, fill = 0xCC0A0B14.toInt(), stroke = 3)
                box.setPadding(dp(16), dp(10), dp(16), dp(10))
            }
        }

        val scroll = anim == 1
        var tw = 0
        if (scroll) {
            tv.setSingleLine(true)
            tv.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED)
            tw = tv.measuredWidth.coerceAtLeast(dp(60))
            box.addView(tv, FrameLayout.LayoutParams(tw, ViewGroup.LayoutParams.WRAP_CONTENT))
        } else {
            box.addView(tv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        box.measure(
            View.MeasureSpec.makeMeasureSpec(sw, View.MeasureSpec.AT_MOST),
            View.MeasureSpec.makeMeasureSpec(sh, View.MeasureSpec.AT_MOST),
        )
        val winW = if (scroll) (sw * 0.92f).toInt() else ViewGroup.LayoutParams.WRAP_CONTENT
        val p = params(winW, ViewGroup.LayoutParams.WRAP_CONTENT)
        val shownW = if (scroll) winW else box.measuredWidth
        p.x = ((sw - shownW) / 2).coerceAtLeast(0)
        p.y = when (pos) {
            0 -> dp(70)
            2 -> (sh - box.measuredHeight - dp(120)).coerceAtLeast(0)
            else -> ((sh - box.measuredHeight) / 2).coerceAtLeast(0)
        }
        attachDrag(
            box, p, dp(20), sw,
            onLong = { removeText(box) },
            scaleHook = { f ->
                val px = (tv.textSize * f).coerceIn(dp(10).toFloat(), dp(200).toFloat())
                tv.setTextSize(TypedValue.COMPLEX_UNIT_PX, px)
            },
        )
        wm.addView(box, p)
        texts.add(box)
        OverlayState.texts.value = texts.size

        val a: Animator? = when (anim) {
            1 -> {
                val dist = winW + tw
                val va = ValueAnimator.ofFloat(winW.toFloat(), -tw.toFloat())
                va.duration = (dist * 1000L / dp(90)).coerceAtLeast(2000L)
                va.interpolator = LinearInterpolator()
                va.repeatCount = ValueAnimator.INFINITE
                va.addUpdateListener { tv.translationX = it.animatedValue as Float }
                va
            }
            2 -> ObjectAnimator.ofPropertyValuesHolder(
                tv, PropertyValuesHolder.ofFloat("scaleX", 1f, 1.15f), PropertyValuesHolder.ofFloat("scaleY", 1f, 1.15f),
            ).apply {
                duration = 700L
                repeatCount = ValueAnimator.INFINITE
                repeatMode = ValueAnimator.REVERSE
            }
            3 -> {
                tv.cameraDistance = 9000f * density
                ObjectAnimator.ofFloat(tv, "rotationY", 0f, 360f).apply {
                    duration = 2600L
                    repeatCount = ValueAnimator.INFINITE
                    interpolator = LinearInterpolator()
                }
            }
            4 -> ObjectAnimator.ofFloat(tv, "translationY", 0f, -dp(16).toFloat()).apply {
                duration = 450L
                repeatCount = ValueAnimator.INFINITE
                repeatMode = ValueAnimator.REVERSE
                interpolator = DecelerateInterpolator()
            }
            else -> null
        }
        if (a != null) {
            textAnims[box] = a
            a.start()
        }
    }

    private fun removeText(box: FrameLayout) {
        textAnims.remove(box)?.cancel()
        runCatching { wm.removeView(box) }
        texts.remove(box)
        OverlayState.texts.value = texts.size
    }

    private fun clearTexts() {
        texts.toList().forEach { removeText(it) }
    }

    // ---------------------------------------------------------------- effects and 3D pop-ups

    /** The effects layer is added only while something is playing, so an idle stream has no extra full-screen window. */
    private fun ensureFx(): FrameLayout? {
        val cur = fx
        if (cur != null) return cur
        if (!running) return null
        val layer = FrameLayout(this)
        fx = layer
        wm.addView(layer, params(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT, touchable = false))
        return layer
    }

    private fun dropFx(layer: FrameLayout, v: View) {
        runCatching { layer.removeView(v) }
        if (layer.childCount == 0) {
            ui.postDelayed({
                if (fx === layer && layer.childCount == 0) {
                    runCatching { wm.removeView(layer) }
                    fx = null
                }
            }, 400L)
        }
    }

    private fun fxScale(): Float {
        val d = si("fx_density", 100) / 100f
        return if (Live.lite.value) d * 0.5f else d
    }

    private fun cnt(n: Int): Int = maxOf(3, (n * fxScale()).toInt())

    private fun runFx(name: String, title: String = "", sub: String = "") {
        when (name) {
            "confetti" -> burst(listOf("🎉", "🎊", "✨", "⭐"), cnt(30), true)
            "coins3d" -> spin3d(listOf("🪙", "💰"), cnt(16), true)
            "hearts3d" -> spin3d(listOf("💖", "💜", "💙"), cnt(14), false)
            "fireworks" -> fireworks()
            "ring" -> ring()
            "sub" -> popup("🔔", "Subscribe to $channelName!", "Tap the red button and the bell")
            "like" -> popup("👍", "Smash the like button!", "It helps the stream grow")
            "flash" -> flash()
            "popup_custom" -> popup("✨", title.ifBlank { channelName }, sub)
            "popup_test" -> popup("🎉", "Test pop-up", "This is how your pop-ups look")
            "alert_test" -> onNewSubscriber("Test User")
        }
    }

    private fun burst(symbols: List<String>, count: Int, fall: Boolean) {
        val layer = ensureFx() ?: return
        if (layer.childCount > 120) return
        val w = resources.displayMetrics.widthPixels
        val h = resources.displayMetrics.heightPixels
        repeat(count) {
            val t = TextView(this)
            t.text = symbols.random()
            t.textSize = (22..44).random().toFloat()
            layer.addView(t, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            t.translationX = (0 until maxOf(1, w - dp(60))).random().toFloat()
            t.translationY = if (fall) -dp(60).toFloat() else h.toFloat()
            t.animate()
                .translationY(if (fall) h.toFloat() else -dp(80).toFloat())
                .alpha(0.1f)
                .rotation((-40..40).random().toFloat())
                .setStartDelay((0..700).random().toLong())
                .setDuration((2200..4200).random().toLong())
                .withEndAction { dropFx(layer, t) }
                .start()
        }
    }

    /** 3D look: pieces flip and tumble in space (rotateX / rotateY with camera depth) while they fall or rise. */
    private fun spin3d(symbols: List<String>, count: Int, fall: Boolean) {
        val layer = ensureFx() ?: return
        if (layer.childCount > 120) return
        val w = resources.displayMetrics.widthPixels
        val h = resources.displayMetrics.heightPixels
        repeat(count) {
            val t = TextView(this)
            t.text = symbols.random()
            t.textSize = (30..56).random().toFloat()
            t.cameraDistance = 9000f * density
            t.setShadowLayer(18f, 0f, 0f, CYAN)
            layer.addView(t, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            val x0 = (0 until maxOf(1, w - dp(70))).random().toFloat()
            t.translationX = x0
            t.translationY = if (fall) -dp(80).toFloat() else h.toFloat()
            t.scaleX = 0.6f
            t.scaleY = 0.6f
            t.animate()
                .translationY(if (fall) h.toFloat() else -dp(100).toFloat())
                .translationX(x0 + (-dp(70)..dp(70)).random())
                .rotationY((720..1440).random().toFloat())
                .rotationX((180..540).random().toFloat())
                .scaleX(1.3f)
                .scaleY(1.3f)
                .alpha(0.15f)
                .setStartDelay((0..900).random().toLong())
                .setDuration((2600..4600).random().toLong())
                .withEndAction { dropFx(layer, t) }
                .start()
        }
    }

    private fun fireworks() {
        val layer = ensureFx() ?: return
        if (layer.childCount > 100) return
        val w = resources.displayMetrics.widthPixels
        val h = resources.displayMetrics.heightPixels
        val colors = listOf(CYAN, PINK, GREEN, 0xFFFFE600.toInt(), VIOLET)
        val bursts = if (Live.lite.value) 2 else 3
        val dots = maxOf(8, (18 * fxScale()).toInt())
        repeat(bursts) { n ->
            val cx = w * 0.2f + w * 0.6f * Random.nextFloat()
            val cy = h * 0.15f + h * 0.35f * Random.nextFloat()
            val col = colors.random()
            repeat(dots) { k ->
                val dot = View(this)
                val g = GradientDrawable()
                g.shape = GradientDrawable.OVAL
                g.setColor(col)
                dot.background = g
                dot.alpha = 0f
                layer.addView(dot, FrameLayout.LayoutParams(dp(8), dp(8)))
                dot.translationX = cx
                dot.translationY = cy
                val ang = Math.toRadians(k * (360.0 / dots) + n * 7)
                val dist = (dp(110) + (0..dp(70)).random()).toDouble()
                dot.postDelayed({
                    dot.alpha = 1f
                    dot.animate()
                        .translationX(cx + (cos(ang) * dist).toFloat())
                        .translationY(cy + (sin(ang) * dist).toFloat())
                        .alpha(0f)
                        .scaleX(0.3f)
                        .scaleY(0.3f)
                        .setDuration(1100L)
                        .withEndAction { dropFx(layer, dot) }
                        .start()
                }, n * 350L)
            }
        }
    }

    private fun ring() {
        val layer = ensureFx() ?: return
        val v = View(this)
        val g = GradientDrawable()
        g.shape = GradientDrawable.OVAL
        g.setStroke(dp(6), CYAN)
        g.setColor(Color.TRANSPARENT)
        v.background = g
        layer.addView(v, FrameLayout.LayoutParams(dp(120), dp(120), Gravity.CENTER))
        v.scaleX = 0.2f
        v.scaleY = 0.2f
        v.animate().scaleX(7f).scaleY(7f).alpha(0f).setDuration(1200L).withEndAction { dropFx(layer, v) }.start()
    }

    private fun flash() {
        val layer = ensureFx() ?: return
        val v = View(this)
        v.setBackgroundColor(Color.WHITE)
        v.alpha = 0f
        layer.addView(v, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        v.animate().alpha(0.85f).setDuration(120L).withEndAction {
            v.animate().alpha(0f).setDuration(380L).withEndAction { dropFx(layer, v) }.start()
        }.start()
    }

    /** 3D pop-up card. The style (flip, coin, cube, zoom, hologram), the time on screen and the size come from Settings. */
    private fun popup(emoji: String, title: String, sub: String) {
        val layer = ensureFx() ?: return
        if (layer.childCount > 120) return
        val style = si("popup_style", 0)
        val scale = si("popup_scale", 100) / 100f
        val hold = si("popup_time", 5).coerceIn(2, 12) * 1000L

        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.gravity = Gravity.CENTER
        card.setPadding(dp(26), dp(18), dp(26), dp(18))
        card.background = neon(dp(28).toFloat(), PINK, fill = 0xEE12142A.toInt(), stroke = 3)
        card.cameraDistance = 12000f * density

        val e = TextView(this)
        e.text = emoji
        e.textSize = 54f * scale
        e.gravity = Gravity.CENTER
        val t = TextView(this)
        t.text = title
        t.textSize = 24f * scale
        t.setTypeface(null, Typeface.BOLD)
        t.setTextColor(Color.WHITE)
        t.setShadowLayer(16f, 0f, 0f, PINK)
        t.gravity = Gravity.CENTER
        card.addView(e)
        card.addView(t)
        if (sub.isNotBlank()) {
            val s = TextView(this)
            s.text = sub
            s.textSize = 14f * scale
            s.setTextColor(0xFFB8C4FF.toInt())
            s.gravity = Gravity.CENTER
            card.addView(s)
        }
        val lp = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
            Gravity.CENTER_HORIZONTAL or Gravity.TOP,
        )
        lp.topMargin = dp(150)
        layer.addView(card, lp)

        val finish = { dropFx(layer, card) }
        val leave = {
            card.tag = "leaving"
            when (style) {
                0 -> card.animate().rotationY(-90f).alpha(0f).setDuration(450L).withEndAction { finish() }.start()
                1 -> card.animate().scaleX(1.7f).scaleY(1.7f).alpha(0f).setDuration(450L).withEndAction { finish() }.start()
                2 -> card.animate().rotationX(90f).translationY(dp(120).toFloat()).alpha(0f).setDuration(450L).withEndAction { finish() }.start()
                3 -> card.animate().scaleX(0.2f).scaleY(0.2f).alpha(0f).setDuration(350L).withEndAction { finish() }.start()
                else -> card.animate().alpha(0f).translationY(-dp(40).toFloat()).setDuration(450L).withEndAction { finish() }.start()
            }
        }
        val wait = { card.postDelayed({ leave() }, hold) }

        when (style) {
            0 -> {
                card.rotationY = 90f
                card.alpha = 0f
                card.animate().rotationY(0f).alpha(1f).setDuration(600L)
                    .setInterpolator(OvershootInterpolator(1.2f)).withEndAction { wait() }.start()
            }
            1 -> {
                card.scaleX = 0f
                card.scaleY = 0f
                card.animate().scaleX(1f).scaleY(1f).rotationY(720f).setDuration(850L)
                    .withEndAction {
                        card.rotationY = 0f
                        wait()
                    }.start()
            }
            2 -> {
                card.rotationX = -90f
                card.translationY = -dp(220).toFloat()
                card.alpha = 0f
                card.animate().rotationX(0f).translationY(0f).alpha(1f).setDuration(700L)
                    .setInterpolator(BounceInterpolator()).withEndAction { wait() }.start()
            }
            3 -> {
                card.scaleX = 3f
                card.scaleY = 3f
                card.alpha = 0f
                ring()
                card.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(420L)
                    .setInterpolator(DecelerateInterpolator()).withEndAction { wait() }.start()
            }
            else -> {
                card.alpha = 0f
                card.translationY = dp(30).toFloat()
                card.animate().alpha(1f).translationY(0f).setDuration(400L).withEndAction {
                    val flick = object : Runnable {
                        override fun run() {
                            if (card.parent == null || card.tag == "leaving") return
                            card.alpha = 0.78f + Random.nextFloat() * 0.22f
                            card.postDelayed(this, 110L)
                        }
                    }
                    card.post(flick)
                    wait()
                }.start()
            }
        }
    }

    // ---------------------------------------------------------------- pause screen

    private fun toggleBrb() {
        val muteOnPause = sp.getBoolean("pause_mute", true)
        val cur = brb
        if (cur != null) {
            runCatching { wm.removeView(cur) }
            brb = null
            if (muteOnPause) Live.micOn.value = micBeforePause
            return
        }
        if (muteOnPause) {
            micBeforePause = Live.micOn.value
            Live.micOn.value = false
        }
        val root = FrameLayout(this)
        root.setBackgroundColor(0xF2070815.toInt())

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER

        val big = TextView(this)
        big.text = sp.getString("pause_text", "BE RIGHT BACK")?.ifBlank { "BE RIGHT BACK" } ?: "BE RIGHT BACK"
        big.textSize = 40f
        big.setTypeface(null, Typeface.BOLD)
        big.setTextColor(Color.WHITE)
        big.setShadowLayer(30f, 0f, 0f, CYAN)
        big.gravity = Gravity.CENTER

        val small = TextView(this)
        small.text = "$channelName will be back in a moment"
        small.textSize = 16f
        small.setTextColor(0xFFB8C4FF.toInt())
        small.gravity = Gravity.CENTER
        small.setPadding(0, dp(10), 0, 0)

        val hint = TextView(this)
        hint.text = "(tap anywhere to resume)"
        hint.textSize = 12f
        hint.setTextColor(0xFF6E78A8.toInt())
        hint.gravity = Gravity.CENTER
        hint.setPadding(0, dp(24), 0, 0)

        col.addView(big)
        col.addView(small)
        col.addView(hint)
        root.addView(col, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        if (!Live.lite.value) {
            val anim = ObjectAnimator.ofFloat(big, "alpha", 0.45f, 1f)
            anim.duration = 900L
            anim.repeatCount = ValueAnimator.INFINITE
            anim.repeatMode = ValueAnimator.REVERSE
            anim.start()
        }

        root.setOnClickListener { toggleBrb() }
        brb = root
        wm.addView(root, params(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
    }

    // ---------------------------------------------------------------- stats, subscribers, comments

    private suspend fun loadBitmap(url: String): Bitmap? = withContext(Dispatchers.IO) {
        runCatching { URL(url).openStream().use { BitmapFactory.decodeStream(it) } }.getOrNull()
    }

    private fun compact(n: Long): String = when {
        n >= 1_000_000 -> String.format(Locale.US, "%.1fM", n / 1_000_000.0).replace(".0M", "M")
        n >= 1_000 -> String.format(Locale.US, "%.1fK", n / 1_000.0).replace(".0K", "K")
        else -> n.toString()
    }

    private fun updateSubsChip() {
        val total = subsNow
        val s0 = subsStart
        val delta = if (total != null && s0 != null) (total - s0).toInt().coerceAtLeast(0) else 0
        val gained = maxOf(subsGained, delta)
        val base = if (total != null) compact(total) else "--"
        tvSubs?.text = if (Live.broadcastId != null) "🔔 SUBS $base (+$gained this stream)" else "🔔 SUBS $base"
    }

    private fun startStats() {
        statsJob = lifecycleScope.launch {
            var tick = 0
            while (true) {
                if (tick % 2 == 0) {
                    val info = runCatching { YouTubeApi.channelInfo(this@OverlayService) }.getOrNull()
                    if (info != null) {
                        if (info.title.isNotEmpty()) channelName = info.title
                        subsNow = info.subs?.toLongOrNull()
                        val av = info.avatar
                        if (!avatarLoaded && av != null) {
                            val bmp = loadBitmap(av)
                            if (bmp != null) {
                                avatarView?.setImageBitmap(bmp)
                                avatarLoaded = true
                            }
                        }
                    }
                }
                tick++
                val id = Live.broadcastId
                if (id == null) {
                    subsStart = null
                    subsGained = 0
                } else {
                    if (subsStart == null) subsStart = subsNow
                    val stats = runCatching { YouTubeApi.videoStats(this@OverlayService, id) }.getOrNull()
                    if (stats != null) {
                        tvLikes?.text = "👍 ${stats.first}"
                        tvViewers?.text = "👁 ${stats.second}"
                    }
                }
                updateSubsChip()
                delay(30_000L)
            }
        }
    }

    private fun startSubAlerts() {
        subJob?.cancel()
        subJob = lifecycleScope.launch {
            var seen: MutableSet<String>? = null
            while (true) {
                if (Live.broadcastId == null) {
                    seen = null
                } else if (sp.getBoolean("sub_alert", true)) {
                    try {
                        val list = YouTubeApi.recentSubscribers(this@OverlayService)
                        val known = seen
                        if (known == null) {
                            seen = list.map { it.id }.toMutableSet()   // first look: remember, do not alert
                        } else {
                            for (s in list) if (known.add(s.id)) onNewSubscriber(s.name.ifBlank { "Someone" })
                        }
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        // try again next round
                    }
                }
                delay(45_000L)
            }
        }
    }

    private fun onNewSubscriber(name: String) {
        subsGained++
        updateSubsChip()
        popup("🔔", "$name subscribed!", "Thank you so much")
        burst(listOf("🎉", "🔔", "✨", "❤️"), cnt(36), true)
        fireworks()
        playAlertSound()
        showMeme()
        if (sp.getBoolean("sub_tts", true)) {
            ensureTts()
            val msg = when (si("tts_lang", 0)) {
                0 -> "$name ने सब्सक्राइब किया। बहुत बहुत शुक्रिया!"
                else -> "$name just subscribed. Thank you so much!"
            }
            tts?.speak(msg, TextToSpeech.QUEUE_ADD, null, null)
        }
    }

    /** The alert sound is normal media audio, so your viewers hear it in the stream too. */
    private fun playAlertSound() {
        val u = sp.getString("sub_sound", null) ?: return
        runCatching {
            val mp = MediaPlayer()
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            mp.setDataSource(this, Uri.parse(u))
            mp.setOnPreparedListener { it.start() }
            mp.setOnCompletionListener { it.release() }
            mp.setOnErrorListener { m, _, _ ->
                m.release()
                true
            }
            mp.prepareAsync()
        }
    }

    private fun showMeme() {
        val layer = ensureFx() ?: return
        val u = sp.getString("sub_meme", null) ?: return
        val img = ImageView(this)
        img.scaleType = ImageView.ScaleType.FIT_CENTER
        runCatching { img.setImageURI(Uri.parse(u)) }
        layer.addView(img, FrameLayout.LayoutParams(dp(240), dp(240), Gravity.CENTER))
        img.scaleX = 0.1f
        img.scaleY = 0.1f
        img.alpha = 0f
        img.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(450L).withEndAction {
            img.postDelayed({
                img.animate().alpha(0f).scaleX(1.4f).scaleY(1.4f).setDuration(500L).withEndAction { dropFx(layer, img) }.start()
            }, 4000L)
        }.start()
    }

    // ---- voice (Hindi, English India, or device default) ----

    private fun ensureTts() {
        if (tts != null) {
            applyTtsLang()
            return
        }
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                // Not captured by the stream: only the streamer hears the reader.
                tts?.setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANCE_ACCESSIBILITY)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                applyTtsLang()
            }
        }
    }

    private fun applyTtsLang() {
        val t = tts ?: return
        val loc = when (si("tts_lang", 0)) {
            0 -> Locale("hi", "IN")
            1 -> Locale("en", "IN")
            else -> Locale.getDefault()
        }
        val r = t.setLanguage(loc)
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            toast("This voice is not installed. Open Google Text-to-speech settings and download it.")
        }
        t.setSpeechRate(si("tts_rate", 100) / 100f)
    }

    private fun setReadChat(on: Boolean) {
        readChat = on
        chipRead?.text = if (on) "💬 Reading: ON" else "💬 Read comments"
        if (on) ensureTts() else tts?.stop()
        updateChatJob()
    }

    private fun onComment(author: String, text: String) {
        if (sp.getBoolean("cmt_box", false)) addCommentLine(author, text)
        if (readChat) tts?.speak("$author, $text", TextToSpeech.QUEUE_ADD, null, null)
    }

    /** The shared ChatFeed asks YouTube once; this service listens while the comment box or voice reader is on. */
    private fun updateChatJob() {
        val want = readChat || sp.getBoolean("cmt_box", false)
        if (!want) {
            chatJob?.cancel()
            chatJob = null
            if (chatAcquired) {
                ChatFeed.release()
                chatAcquired = false
            }
            return
        }
        if (chatJob?.isActive == true) return
        ChatFeed.acquire(this)
        chatAcquired = true
        chatJob = lifecycleScope.launch { ChatFeed.messages.collect { onComment(it.author, it.text) } }
    }

    // ---------------------------------------------------------------- shutdown

    private fun cleanup() {
        ui.removeCallbacks(hideBar)
        statsJob?.cancel()
        chatJob?.cancel()
        subJob?.cancel()
        if (chatAcquired) {
            ChatFeed.release()
            chatAcquired = false
        }
        tts?.stop()
        tts?.shutdown()
        tts = null
        clearTiles()
        clearTexts()
        removeCommentBox()
        brb?.let { v -> runCatching { wm.removeView(v) } }
        brb = null
        bubble?.let { v -> runCatching { wm.removeView(v) } }
        bar?.let { v -> runCatching { wm.removeView(v) } }
        fx?.let { v -> runCatching { wm.removeView(v) } }
        bubble = null
        bar = null
        fx = null
        running = false
        OverlayState.running.value = false
        OverlayState.tiles.value = 0
        OverlayState.texts.value = 0
        OverlayState.tileList.value = emptyList()
    }

    private fun shutdown() {
        cleanup()
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        cleanup()
        super.onDestroy()
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()
}
