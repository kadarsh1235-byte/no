package com.proeditz.livestudio

import android.Manifest
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Outline
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.TextUtils
import android.text.style.StyleSpan
import android.view.Gravity
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import android.widget.VideoView
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.URL
import java.util.Locale
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

/**
 * Floating studio tools that sit on top of your game. Because the app streams the whole screen,
 * everything shown here (bubble, bar, face cam, tiles, comment box, effects, pause screen) is part of the stream.
 */
class OverlayService : LifecycleService() {

    companion object {
        const val A_SHOW = "com.proeditz.livestudio.OVERLAY_SHOW"
        const val A_STOP = "com.proeditz.livestudio.OVERLAY_STOP"
        const val A_TILE = "com.proeditz.livestudio.OVERLAY_TILE"
        const val A_CLEAR = "com.proeditz.livestudio.OVERLAY_CLEAR"
        const val A_FX = "com.proeditz.livestudio.OVERLAY_FX"
        const val A_BRB = "com.proeditz.livestudio.OVERLAY_BRB"
        const val A_READ = "com.proeditz.livestudio.OVERLAY_READ"
        const val A_CFG = "com.proeditz.livestudio.OVERLAY_CFG"

        private const val CHANNEL = "overlay"
        private const val NOTIF_ID = 8
        private const val MAX_TILES = 10

        private val CYAN = 0xFF00F0FF.toInt()
        private val PINK = 0xFFFF2BD6.toInt()
        private val VIOLET = 0xFF8F5BFF.toInt()
        private val GREEN = 0xFF39FF88.toInt()
        private val RED = 0xFFFF2D55.toInt()
        private val PANEL = 0xFF12142A.toInt()

        fun start(ctx: Context) {
            ContextCompat.startForegroundService(ctx, Intent(ctx, OverlayService::class.java).setAction(A_SHOW))
        }

        fun send(ctx: Context, action: String, extra: Intent.() -> Unit = {}) {
            if (!OverlayState.running.value) return
            ctx.startService(Intent(ctx, OverlayService::class.java).setAction(action).apply(extra))
        }
    }

    private lateinit var wm: WindowManager
    private lateinit var sp: SharedPreferences
    private val ui = Handler(Looper.getMainLooper())
    private var density = 1f
    private var running = false

    private var bubble: FrameLayout? = null
    private var bar: LinearLayout? = null
    private var fx: FrameLayout? = null
    private var brb: View? = null
    private var fxRow: View? = null
    private var avatarView: ImageView? = null
    private var tvLikes: TextView? = null
    private var tvSubs: TextView? = null
    private var tvViewers: TextView? = null
    private var chipRead: TextView? = null
    private var chipMic: TextView? = null
    private var chipVol: TextView? = null

    private var cmtBox: FrameLayout? = null
    private var cmtList: LinearLayout? = null
    private var cmtParams: WindowManager.LayoutParams? = null

    private val tiles = mutableListOf<FrameLayout>()
    private var camTile: FrameLayout? = null

    private var statsJob: Job? = null
    private var chatJob: Job? = null
    private var subJob: Job? = null
    private var tts: TextToSpeech? = null
    private var readChat = false
    private var channelName = "Pro Editz NEW"
    private var avatarLoaded = false
    private var subsNow: Long? = null
    private var subsStart: Long? = null
    private var subsGained = 0
    private var micBeforePause = false

    private val hideBar = Runnable { bar?.visibility = View.GONE }

    private val cmtColors = intArrayOf(
        Color.WHITE, 0xFF00F0FF.toInt(), 0xFFFF2BD6.toInt(), 0xFFFFE600.toInt(),
        0xFF39FF88.toInt(), 0xFFFF9A00.toInt(), 0xFF111111.toInt(), 0xFFFF4D4D.toInt(),
    )

    private val circleOutline = object : ViewOutlineProvider() {
        override fun getOutline(view: View, outline: Outline) {
            outline.setOval(0, 0, view.width, view.height)
        }
    }

    private fun roundOutline(radius: Int) = object : ViewOutlineProvider() {
        override fun getOutline(view: View, outline: Outline) {
            outline.setRoundRect(0, 0, view.width, view.height, radius.toFloat())
        }
    }

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        sp = getSharedPreferences("overlay", Context.MODE_PRIVATE)
        density = resources.displayMetrics.density
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        val cmd = intent ?: return START_NOT_STICKY
        when (cmd.action) {
            A_SHOW -> show()
            A_STOP -> shutdown()
            A_TILE -> if (running) {
                addTile(
                    cmd.getStringExtra("type") ?: "",
                    cmd.getStringExtra("uri"),
                    cmd.getStringExtra("size") ?: "medium",
                    cmd.getBooleanExtra("circle", false),
                )
            }
            A_CLEAR -> clearTiles()
            A_FX -> if (running) runFx(cmd.getStringExtra("fx") ?: "")
            A_BRB -> if (running) toggleBrb()
            A_READ -> if (running) setReadChat(cmd.getBooleanExtra("on", false))
            A_CFG -> if (running) applyCfg()
        }
        return START_NOT_STICKY
    }

    // ---------------------------------------------------------------- setup

    private fun dp(v: Int): Int = (v * density).toInt()

    private fun show() {
        startForegroundCompat()
        if (running) return
        if (!Settings.canDrawOverlays(this)) {
            toast("Allow Display over other apps for Pro Editz Live first.")
            stopSelf()
            return
        }
        running = true
        OverlayState.running.value = true
        buildFxLayer()
        buildBar()
        buildBubble()
        startStats()
        startSubAlerts()
        lifecycleScope.launch { Live.micOn.collect { updateMicChip(it) } }
        lifecycleScope.launch { Live.musicVolume.collect { chipVol?.text = "♪ $it%" } }
        applyCfg()
    }

    private fun startForegroundCompat() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Floating tools", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(
            this, 3, Intent(this, OverlayService::class.java).setAction(A_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val n = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("Pro Editz floating tools")
            .setContentText("Tap the neon bubble on your screen to open the tools")
            .setOngoing(true)
            .addAction(0, "Close tools", stop)
            .build()
        val cam = ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        val type = if (cam) ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA else ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
        ServiceCompat.startForeground(this, NOTIF_ID, n, type)
    }

    private fun params(w: Int, h: Int, touchable: Boolean = true): WindowManager.LayoutParams {
        var flags = WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        if (!touchable) flags = flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        val p = WindowManager.LayoutParams(
            w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, flags, PixelFormat.TRANSLUCENT,
        )
        p.gravity = Gravity.TOP or Gravity.START
        return p
    }

    private fun neon(
        corner: Float,
        color: Int,
        fill: Int = 0xCC0A0B14.toInt(),
        stroke: Int = 2,
        oval: Boolean = false,
    ): GradientDrawable {
        val g = GradientDrawable()
        g.shape = if (oval) GradientDrawable.OVAL else GradientDrawable.RECTANGLE
        g.cornerRadius = corner
        g.setColor(fill)
        g.setStroke(dp(stroke), color)
        return g
    }

    private fun chip(label: String, color: Int = CYAN, onClick: (() -> Unit)? = null): TextView {
        val t = TextView(this)
        t.text = label
        t.setTextColor(Color.WHITE)
        t.textSize = 13f
        t.setTypeface(null, Typeface.BOLD)
        t.setShadowLayer(8f, 0f, 0f, color)
        t.setPadding(dp(12), dp(8), dp(12), dp(8))
        t.background = neon(dp(14).toFloat(), color)
        t.gravity = Gravity.CENTER
        if (onClick != null) t.setOnClickListener { onClick() }
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.setMargins(dp(4), dp(2), dp(4), dp(2))
        t.layoutParams = lp
        return t
    }

    // ---------------------------------------------------------------- bubble and bar

    private fun buildFxLayer() {
        val layer = FrameLayout(this)
        fx = layer
        wm.addView(layer, params(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT, touchable = false))
    }

    private fun buildBar() {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(0xE60A0B14.toInt())
        root.setPadding(dp(6), dp(30), dp(6), dp(6))

        // Row 1: live numbers and main tools
        val scroll1 = HorizontalScrollView(this)
        scroll1.isHorizontalScrollBarEnabled = false
        val line1 = LinearLayout(this)
        line1.orientation = LinearLayout.HORIZONTAL

        val likes = chip("👍 --", GREEN)
        // The red SUBS badge makes it clear this number is your subscriber count.
        val subs = chip("🔔 SUBS --", RED)
        subs.background = neon(dp(14).toFloat(), 0xFFFFFFFF.toInt(), fill = RED, stroke = 1)
        val viewers = chip("👁 --", CYAN)
        tvLikes = likes
        tvSubs = subs
        tvViewers = viewers
        line1.addView(likes)
        line1.addView(subs)
        line1.addView(viewers)
        line1.addView(chip("⏸ Pause", PINK) { toggleBrb() })
        val read = chip("💬 Read comments", VIOLET) { setReadChat(!readChat) }
        chipRead = read
        line1.addView(read)
        line1.addView(chip("✨ FX", PINK) {
            val r = fxRow
            if (r != null) r.visibility = if (r.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        })
        line1.addView(chip("✖ Close tools", PINK) { shutdown() })
        scroll1.addView(line1)
        root.addView(scroll1)

        // Row 2: mic and music controls (apply instantly)
        val scroll2 = HorizontalScrollView(this)
        scroll2.isHorizontalScrollBarEnabled = false
        val line2 = LinearLayout(this)
        line2.orientation = LinearLayout.HORIZONTAL
        val mic = chip("🔇 Mic OFF", PINK) { Live.micOn.value = !Live.micOn.value }
        chipMic = mic
        line2.addView(mic)
        line2.addView(chip("⏮", CYAN) { Live.commands.tryEmit("music_prev") })
        line2.addView(chip("⏯", CYAN) { Live.commands.tryEmit("music_toggle") })
        line2.addView(chip("⏭", CYAN) { Live.commands.tryEmit("music_next") })
        line2.addView(chip("🔉", GREEN) { Live.musicVolume.value = (Live.musicVolume.value - 5).coerceAtLeast(0) })
        val vol = chip("♪ ${Live.musicVolume.value}%", GREEN)
        chipVol = vol
        line2.addView(vol)
        line2.addView(chip("🔊", GREEN) { Live.musicVolume.value = (Live.musicVolume.value + 5).coerceAtMost(100) })
        scroll2.addView(line2)
        root.addView(scroll2)

        // Row 3: effects (hidden until you tap FX)
        val scroll3 = HorizontalScrollView(this)
        scroll3.isHorizontalScrollBarEnabled = false
        val line3 = LinearLayout(this)
        line3.orientation = LinearLayout.HORIZONTAL
        line3.addView(chip("🎉 Confetti", PINK) { runFx("confetti") })
        line3.addView(chip("🪙 3D Coins", VIOLET) { runFx("coins3d") })
        line3.addView(chip("💖 3D Hearts", PINK) { runFx("hearts3d") })
        line3.addView(chip("🎆 Fireworks", CYAN) { runFx("fireworks") })
        line3.addView(chip("🔵 Shockwave", CYAN) { runFx("ring") })
        line3.addView(chip("🔔 Subscribe", RED) { runFx("sub") })
        line3.addView(chip("👍 Like", GREEN) { runFx("like") })
        line3.addView(chip("⚡ Flash", VIOLET) { runFx("flash") })
        scroll3.addView(line3)
        scroll3.visibility = View.GONE
        fxRow = scroll3
        root.addView(scroll3)

        root.visibility = View.GONE
        bar = root
        wm.addView(root, params(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
    }

    private fun updateMicChip(on: Boolean) {
        val c = chipMic ?: return
        c.text = if (on) "🎙 Mic ON" else "🔇 Mic OFF"
        c.background = neon(dp(14).toFloat(), if (on) GREEN else PINK)
    }

    private fun toggleBar() {
        val b = bar ?: return
        ui.removeCallbacks(hideBar)
        if (b.visibility == View.VISIBLE) {
            b.visibility = View.GONE
            return
        }
        b.visibility = View.VISIBLE
        val secs = intArrayOf(0, 3, 5, 10)[sp.getInt("bar_hide", 0).coerceIn(0, 3)]
        if (secs > 0) ui.postDelayed(hideBar, secs * 1000L)
    }

    private fun buildBubble() {
        val ring = FrameLayout(this)
        ring.setPadding(dp(3), dp(3), dp(3), dp(3))
        ring.background = neon(0f, PINK, fill = PANEL, stroke = 3, oval = true)

        val inner = FrameLayout(this)
        inner.clipToOutline = true
        inner.outlineProvider = circleOutline

        val label = TextView(this)
        label.text = "PE"
        label.setTextColor(Color.WHITE)
        label.gravity = Gravity.CENTER
        label.textSize = 18f
        label.setTypeface(null, Typeface.BOLD)

        val img = ImageView(this)
        img.scaleType = ImageView.ScaleType.CENTER_CROP
        avatarView = img

        inner.addView(label, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        inner.addView(img, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        ring.addView(inner, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        val p = params(dp(64), dp(64))
        p.x = dp(12)
        p.y = dp(200)
        bubble = ring
        attachDrag(ring, p, dp(40), dp(220), onTap = { toggleBar() }, onLong = null)
        wm.addView(ring, p)
    }

    /** Drag with one finger, resize with a pinch, tap and long-press callbacks. */
    @SuppressLint("ClickableViewAccessibility")
    private fun attachDrag(
        v: View,
        p: WindowManager.LayoutParams,
        minSize: Int,
        maxSize: Int,
        onTap: (() -> Unit)?,
        onLong: (() -> Unit)?,
    ) {
        val sd = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                val nw = (p.width * detector.scaleFactor).toInt().coerceIn(minSize, maxSize)
                val real = nw.toFloat() / p.width
                p.width = nw
                p.height = (p.height * real).toInt().coerceAtLeast(minSize / 2)
                runCatching { wm.updateViewLayout(v, p) }
                return true
            }
        })
        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var moved = false
        var pinching = false
        var downTime = 0L
        v.setOnTouchListener { _, e ->
            sd.onTouchEvent(e)
            if (sd.isInProgress) {
                pinching = true
                return@setOnTouchListener true
            }
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX
                    downY = e.rawY
                    startX = p.x
                    startY = p.y
                    moved = false
                    pinching = false
                    downTime = System.currentTimeMillis()
                }
                MotionEvent.ACTION_MOVE -> if (!pinching && e.pointerCount == 1) {
                    val dx = (e.rawX - downX).toInt()
                    val dy = (e.rawY - downY).toInt()
                    if (abs(dx) > 12 || abs(dy) > 12) moved = true
                    if (moved) {
                        p.x = startX + dx
                        p.y = startY + dy
                        runCatching { wm.updateViewLayout(v, p) }
                    }
                }
                MotionEvent.ACTION_UP -> if (!moved && !pinching) {
                    if (System.currentTimeMillis() - downTime > 600) onLong?.invoke() else onTap?.invoke()
                }
            }
            true
        }
    }

    // ---------------------------------------------------------------- settings from the app

    /** Reads the saved settings and applies them right now (no restart needed). */
    private fun applyCfg() {
        if (!running) return
        if (sp.getBoolean("cmt_box", false)) {
            buildCommentBox()
            styleCommentBox()
        } else {
            removeCommentBox()
        }
        applyTtsLang()
        updateChatJob()
    }

    // ---------------------------------------------------------------- comment box

    private fun cmtFont(i: Int): Typeface = when (i) {
        1 -> Typeface.SERIF
        2 -> Typeface.MONOSPACE
        3 -> Typeface.create("casual", Typeface.NORMAL)
        4 -> Typeface.create("cursive", Typeface.NORMAL)
        else -> Typeface.SANS_SERIF
    }

    private fun buildCommentBox() {
        if (cmtBox != null) return
        val box = FrameLayout(this)
        box.setPadding(dp(10), dp(8), dp(10), dp(8))
        val list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        list.gravity = Gravity.BOTTOM
        box.addView(list, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        cmtBox = box
        cmtList = list
        val dm = resources.displayMetrics
        val p = params(dp(280), dp(170))
        p.x = dp(10)
        p.y = dm.heightPixels / 2
        cmtParams = p
        attachDrag(box, p, dp(120), dm.widthPixels, onTap = null, onLong = null)
        wm.addView(box, p)
    }

    private fun removeCommentBox() {
        cmtBox?.let { v -> runCatching { wm.removeView(v) } }
        cmtBox = null
        cmtList = null
        cmtParams = null
    }

    private fun styleLine(t: TextView) {
        val a = (sp.getInt("cmt_alpha", 100) * 2.55f).toInt().coerceIn(40, 255)
        val c = cmtColors[sp.getInt("cmt_color", 0).coerceIn(0, cmtColors.size - 1)]
        t.setTextColor(Color.argb(a, Color.red(c), Color.green(c), Color.blue(c)))
        t.textSize = sp.getInt("cmt_size", 16).toFloat()
        t.typeface = cmtFont(sp.getInt("cmt_font", 0))
    }

    private fun trimComments() {
        val list = cmtList ?: return
        val max = sp.getInt("cmt_lines", 2) + 2
        while (list.childCount > max) list.removeViewAt(0)
    }

    private fun styleCommentBox() {
        val box = cmtBox ?: return
        val list = cmtList ?: return
        val p = cmtParams ?: return
        val bgA = sp.getInt("cmt_bg", 45)
        val glass = sp.getBoolean("cmt_glass", true)
        val g = GradientDrawable()
        g.cornerRadius = dp(24).toFloat()
        if (glass) {
            // Liquid glass: a frosted, light-catching gradient with a bright edge (and real blur where the phone allows it)
            val a1 = (bgA * 2.2f).toInt().coerceIn(0, 255)
            val a2 = (bgA * 0.6f).toInt().coerceIn(0, 255)
            g.orientation = GradientDrawable.Orientation.TL_BR
            g.colors = intArrayOf(Color.argb(a1, 255, 255, 255), Color.argb(a2, 180, 210, 255))
            g.setStroke(dp(1), Color.argb((bgA * 2.5f).toInt().coerceIn(60, 255), 255, 255, 255))
        } else {
            g.setColor(Color.argb((bgA * 2.55f).toInt().coerceIn(0, 255), 10, 11, 20))
            g.setStroke(dp(1), Color.argb(90, 255, 255, 255))
        }
        box.background = g
        if (Build.VERSION.SDK_INT >= 31) {
            if (glass) {
                p.flags = p.flags or WindowManager.LayoutParams.FLAG_BLUR_BEHIND
                p.blurBehindRadius = dp(24)
            } else {
                p.flags = p.flags and WindowManager.LayoutParams.FLAG_BLUR_BEHIND.inv()
                p.blurBehindRadius = 0
            }
            runCatching { wm.updateViewLayout(box, p) }
        }
        for (i in 0 until list.childCount) {
            val child = list.getChildAt(i)
            if (child is TextView) styleLine(child)
        }
        trimComments()
    }

    private fun addCommentLine(author: String, text: String) {
        val list = cmtList ?: return
        val t = TextView(this)
        val sb = SpannableStringBuilder()
        sb.append(author)
        sb.setSpan(StyleSpan(Typeface.BOLD), 0, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        sb.append("  ").append(text)
        t.text = sb
        t.maxLines = 2
        t.ellipsize = TextUtils.TruncateAt.END
        t.setPadding(0, dp(2), 0, dp(2))
        styleLine(t)
        list.addView(t, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        trimComments()
        t.alpha = 0f
        t.translationY = dp(20).toFloat()
        t.animate().alpha(1f).translationY(0f).setDuration(250L).start()
    }

    // ---------------------------------------------------------------- tiles (face cam, video, picture)

    private fun addTile(type: String, uri: String?, sizeKey: String, circle: Boolean) {
        if (tiles.size >= MAX_TILES) {
            toast("Maximum is 10 tiles.")
            return
        }
        if (type == "camera") {
            if (camTile != null) {
                toast("The face cam box is already on screen.")
                return
            }
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                toast("Allow the camera permission, then stop and start floating tools again.")
                return
            }
        }
        val dm = resources.displayMetrics
        val sw = dm.widthPixels
        val sh = dm.heightPixels
        val square = type == "camera" && circle
        var w = when (sizeKey) {
            "small" -> (sw * 0.25f).toInt()
            "large" -> (sw * 0.60f).toInt()
            "half" -> sw / 2
            else -> (sw * 0.40f).toInt()
        }
        w = w.coerceIn(dp(90), sw)
        val h = when {
            sizeKey == "half" && !square -> sh
            type == "camera" -> w
            else -> w * 9 / 16
        }

        val content: View = when (type) {
            "camera" -> makeCamera()
            "video" -> makeVideo(uri ?: return)
            "image" -> makeImage(uri ?: return)
            else -> return
        }
        content.clipToOutline = true
        content.outlineProvider = if (square) circleOutline else roundOutline(dp(14))

        val color = when (type) {
            "camera" -> CYAN
            "video" -> VIOLET
            else -> GREEN
        }
        val box = FrameLayout(this)
        box.setPadding(dp(3), dp(3), dp(3), dp(3))
        box.background = neon(if (square) 0f else dp(17).toFloat(), color, fill = PANEL, stroke = 3, oval = square)
        box.addView(content, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        val p = params(w, if (square) w else h)
        val n = tiles.size
        p.x = dp(30) + n * dp(26)
        p.y = dp(120) + n * dp(26)
        attachDrag(box, p, dp(70), sw, onTap = null, onLong = { removeTile(box) })
        wm.addView(box, p)
        tiles.add(box)
        if (type == "camera") camTile = box
        OverlayState.tiles.value = tiles.size
    }

    private fun makeCamera(): View {
        val pv = PreviewView(this)
        pv.implementationMode = PreviewView.ImplementationMode.COMPATIBLE
        pv.scaleType = PreviewView.ScaleType.FILL_CENTER
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            runCatching {
                val provider = future.get()
                val preview = Preview.Builder().build()
                preview.setSurfaceProvider(pv.surfaceProvider)
                provider.unbindAll()
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_FRONT_CAMERA, preview)
            }.onFailure { toast("Camera could not start: ${it.message}") }
        }, ContextCompat.getMainExecutor(this))
        return pv
    }

    private fun makeVideo(uri: String): View {
        val v = VideoView(this)
        v.setVideoURI(Uri.parse(uri))
        v.setOnPreparedListener { mp ->
            mp.isLooping = true
            mp.setVolume(0f, 0f)
            v.start()
        }
        return v
    }

    private fun makeImage(uri: String): View {
        val i = ImageView(this)
        i.scaleType = ImageView.ScaleType.CENTER_CROP
        i.setImageURI(Uri.parse(uri))
        return i
    }

    private fun removeTile(box: FrameLayout) {
        runCatching { wm.removeView(box) }
        tiles.remove(box)
        if (box === camTile) {
            camTile = null
            val f = ProcessCameraProvider.getInstance(this)
            f.addListener({ runCatching { f.get().unbindAll() } }, ContextCompat.getMainExecutor(this))
        }
        OverlayState.tiles.value = tiles.size
    }

    private fun clearTiles() {
        tiles.toList().forEach { removeTile(it) }
    }

    // ---------------------------------------------------------------- effects

    private fun runFx(name: String) {
        when (name) {
            "confetti" -> burst(listOf("🎉", "🎊", "✨", "⭐"), 34, true)
            "coins3d" -> spin3d(listOf("🪙", "💰"), 18, true)
            "hearts3d" -> spin3d(listOf("💖", "💜", "💙"), 16, false)
            "fireworks" -> fireworks()
            "ring" -> ring()
            "sub" -> banner("🔔 Subscribe to $channelName!", 20f)
            "like" -> banner("👍 Smash the like button!", 20f)
            "flash" -> flash()
            "alert_test" -> onNewSubscriber("Test User")
        }
    }

    private fun burst(symbols: List<String>, count: Int, fall: Boolean) {
        val layer = fx ?: return
        val w = resources.displayMetrics.widthPixels
        val h = resources.displayMetrics.heightPixels
        repeat(count) {
            val t = TextView(this)
            t.text = symbols.random()
            t.textSize = (22..44).random().toFloat()
            layer.addView(t, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            t.translationX = (0 until maxOf(1, w - dp(60))).random().toFloat()
            t.translationY = if (fall) -dp(60).toFloat() else h.toFloat()
            t.animate()
                .translationY(if (fall) h.toFloat() else -dp(80).toFloat())
                .alpha(0.1f)
                .rotation((-40..40).random().toFloat())
                .setStartDelay((0..700).random().toLong())
                .setDuration((2200..4200).random().toLong())
                .withEndAction { layer.removeView(t) }
                .start()
        }
    }

    /** 3D look: pieces flip and tumble in space (rotateX / rotateY with camera depth) while they fall or rise. */
    private fun spin3d(symbols: List<String>, count: Int, fall: Boolean) {
        val layer = fx ?: return
        val w = resources.displayMetrics.widthPixels
        val h = resources.displayMetrics.heightPixels
        repeat(count) {
            val t = TextView(this)
            t.text = symbols.random()
            t.textSize = (30..56).random().toFloat()
            t.cameraDistance = 9000f * density
            t.setShadowLayer(18f, 0f, 0f, CYAN)
            layer.addView(t, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            val x0 = (0 until maxOf(1, w - dp(70))).random().toFloat()
            t.translationX = x0
            t.translationY = if (fall) -dp(80).toFloat() else h.toFloat()
            t.scaleX = 0.6f
            t.scaleY = 0.6f
            t.animate()
                .translationY(if (fall) h.toFloat() else -dp(100).toFloat())
                .translationX(x0 + (-dp(70)..dp(70)).random())
                .rotationY((720..1440).random().toFloat())
                .rotationX((180..540).random().toFloat())
                .scaleX(1.3f)
                .scaleY(1.3f)
                .alpha(0.15f)
                .setStartDelay((0..900).random().toLong())
                .setDuration((2600..4600).random().toLong())
                .withEndAction { layer.removeView(t) }
                .start()
        }
    }

    private fun fireworks() {
        val layer = fx ?: return
        val w = resources.displayMetrics.widthPixels
        val h = resources.displayMetrics.heightPixels
        val colors = listOf(CYAN, PINK, GREEN, 0xFFFFE600.toInt(), VIOLET)
        repeat(3) { n ->
            val cx = w * 0.2f + w * 0.6f * Random.nextFloat()
            val cy = h * 0.15f + h * 0.35f * Random.nextFloat()
            val col = colors.random()
            repeat(18) { k ->
                val dot = View(this)
                val g = GradientDrawable()
                g.shape = GradientDrawable.OVAL
                g.setColor(col)
                dot.background = g
                dot.alpha = 0f
                layer.addView(dot, FrameLayout.LayoutParams(dp(8), dp(8)))
                dot.translationX = cx
                dot.translationY = cy
                val ang = Math.toRadians(k * 20.0 + n * 7)
                val dist = (dp(110) + (0..dp(70)).random()).toDouble()
                dot.postDelayed({
                    dot.alpha = 1f
                    dot.animate()
                        .translationX(cx + (cos(ang) * dist).toFloat())
                        .translationY(cy + (sin(ang) * dist).toFloat())
                        .alpha(0f)
                        .scaleX(0.3f)
                        .scaleY(0.3f)
                        .setDuration(1100L)
                        .withEndAction { layer.removeView(dot) }
                        .start()
                }, n * 350L)
            }
        }
    }

    private fun ring() {
        val layer = fx ?: return
        val v = View(this)
        val g = GradientDrawable()
        g.shape = GradientDrawable.OVAL
        g.setStroke(dp(6), CYAN)
        g.setColor(Color.TRANSPARENT)
        v.background = g
        layer.addView(v, FrameLayout.LayoutParams(dp(120), dp(120), Gravity.CENTER))
        v.scaleX = 0.2f
        v.scaleY = 0.2f
        v.animate().scaleX(7f).scaleY(7f).alpha(0f).setDuration(1200L).withEndAction { layer.removeView(v) }.start()
    }

    private fun banner(message: String, size: Float) {
        val layer = fx ?: return
        val t = TextView(this)
        t.text = message
        t.setTextColor(Color.WHITE)
        t.textSize = size
        t.setTypeface(null, Typeface.BOLD)
        t.setShadowLayer(14f, 0f, 0f, PINK)
        t.setPadding(dp(22), dp(12), dp(22), dp(12))
        t.background = neon(dp(22).toFloat(), PINK)
        val lp = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
            Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL,
        )
        lp.bottomMargin = dp(100)
        layer.addView(t, lp)
        t.alpha = 0f
        t.translationY = dp(80).toFloat()
        t.animate().alpha(1f).translationY(0f).setDuration(400L).withEndAction {
            t.postDelayed({
                t.animate().alpha(0f).setDuration(500L).withEndAction { layer.removeView(t) }.start()
            }, 4500L)
        }.start()
    }

    private fun flash() {
        val layer = fx ?: return
        val v = View(this)
        v.setBackgroundColor(Color.WHITE)
        v.alpha = 0f
        layer.addView(v, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        v.animate().alpha(0.85f).setDuration(120L).withEndAction {
            v.animate().alpha(0f).setDuration(380L).withEndAction { layer.removeView(v) }.start()
        }.start()
    }

    // ---------------------------------------------------------------- pause screen

    private fun toggleBrb() {
        val muteOnPause = sp.getBoolean("pause_mute", true)
        val cur = brb
        if (cur != null) {
            runCatching { wm.removeView(cur) }
            brb = null
            if (muteOnPause) Live.micOn.value = micBeforePause
            return
        }
        if (muteOnPause) {
            micBeforePause = Live.micOn.value
            Live.micOn.value = false
        }
        val root = FrameLayout(this)
        root.setBackgroundColor(0xF2070815.toInt())

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER

        val big = TextView(this)
        big.text = sp.getString("pause_text", "BE RIGHT BACK")?.ifBlank { "BE RIGHT BACK" } ?: "BE RIGHT BACK"
        big.textSize = 40f
        big.setTypeface(null, Typeface.BOLD)
        big.setTextColor(Color.WHITE)
        big.setShadowLayer(30f, 0f, 0f, CYAN)
        big.gravity = Gravity.CENTER

        val small = TextView(this)
        small.text = "$channelName will be back in a moment"
        small.textSize = 16f
        small.setTextColor(0xFFB8C4FF.toInt())
        small.gravity = Gravity.CENTER
        small.setPadding(0, dp(10), 0, 0)

        val hint = TextView(this)
        hint.text = "(tap anywhere to resume)"
        hint.textSize = 12f
        hint.setTextColor(0xFF6E78A8.toInt())
        hint.gravity = Gravity.CENTER
        hint.setPadding(0, dp(24), 0, 0)

        col.addView(big)
        col.addView(small)
        col.addView(hint)
        root.addView(col, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        val anim = ObjectAnimator.ofFloat(big, "alpha", 0.45f, 1f)
        anim.duration = 900L
        anim.repeatCount = ValueAnimator.INFINITE
        anim.repeatMode = ValueAnimator.REVERSE
        anim.start()

        root.setOnClickListener { toggleBrb() }
        brb = root
        wm.addView(root, params(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
    }

    // ---------------------------------------------------------------- stats, subscribers, comments

    private suspend fun loadBitmap(url: String): Bitmap? = withContext(Dispatchers.IO) {
        runCatching { URL(url).openStream().use { BitmapFactory.decodeStream(it) } }.getOrNull()
    }

    private fun compact(n: Long): String = when {
        n >= 1_000_000 -> String.format(Locale.US, "%.1fM", n / 1_000_000.0).replace(".0M", "M")
        n >= 1_000 -> String.format(Locale.US, "%.1fK", n / 1_000.0).replace(".0K", "K")
        else -> n.toString()
    }

    private fun updateSubsChip() {
        val total = subsNow
        val s0 = subsStart
        val delta = if (total != null && s0 != null) (total - s0).toInt().coerceAtLeast(0) else 0
        val gained = maxOf(subsGained, delta)
        val base = if (total != null) compact(total) else "--"
        tvSubs?.text = if (Live.broadcastId != null) "🔔 SUBS $base (+$gained this stream)" else "🔔 SUBS $base"
    }

    private fun startStats() {
        statsJob = lifecycleScope.launch {
            var tick = 0
            while (true) {
                if (tick % 2 == 0) {
                    val info = runCatching { YouTubeApi.channelInfo(this@OverlayService) }.getOrNull()
                    if (info != null) {
                        if (info.title.isNotEmpty()) channelName = info.title
                        subsNow = info.subs?.toLongOrNull()
                        val av = info.avatar
                        if (!avatarLoaded && av != null) {
                            val bmp = loadBitmap(av)
                            if (bmp != null) {
                                avatarView?.setImageBitmap(bmp)
                                avatarLoaded = true
                            }
                        }
                    }
                }
                tick++
                val id = Live.broadcastId
                if (id == null) {
                    subsStart = null
                    subsGained = 0
                } else {
                    if (subsStart == null) subsStart = subsNow
                    val stats = runCatching { YouTubeApi.videoStats(this@OverlayService, id) }.getOrNull()
                    if (stats != null) {
                        tvLikes?.text = "👍 ${stats.first}"
                        tvViewers?.text = "👁 ${stats.second}"
                    }
                }
                updateSubsChip()
                delay(30_000L)
            }
        }
    }

    private fun startSubAlerts() {
        subJob?.cancel()
        subJob = lifecycleScope.launch {
            var seen: MutableSet<String>? = null
            while (true) {
                if (Live.broadcastId == null) {
                    seen = null
                } else if (sp.getBoolean("sub_alert", true)) {
                    try {
                        val list = YouTubeApi.recentSubscribers(this@OverlayService)
                        val known = seen
                        if (known == null) {
                            seen = list.map { it.id }.toMutableSet()   // first look: remember, do not alert
                        } else {
                            for (s in list) if (known.add(s.id)) onNewSubscriber(s.name.ifBlank { "Someone" })
                        }
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        // try again next round
                    }
                }
                delay(45_000L)
            }
        }
    }

    private fun onNewSubscriber(name: String) {
        subsGained++
        updateSubsChip()
        banner("🔔 $name subscribed!", 24f)
        burst(listOf("🎉", "🔔", "✨", "❤️"), 40, true)
        fireworks()
        playAlertSound()
        showMeme()
        if (sp.getBoolean("sub_tts", true)) {
            ensureTts()
            val msg = when (sp.getInt("tts_lang", 0)) {
                0 -> "$name ने सब्सक्राइब किया। बहुत बहुत शुक्रिया!"
                else -> "$name just subscribed. Thank you so much!"
            }
            tts?.speak(msg, TextToSpeech.QUEUE_ADD, null, null)
        }
    }

    /** The alert sound is normal media audio, so your viewers hear it in the stream too. */
    private fun playAlertSound() {
        val u = sp.getString("sub_sound", null) ?: return
        runCatching {
            val mp = MediaPlayer()
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            mp.setDataSource(this, Uri.parse(u))
            mp.setOnPreparedListener { it.start() }
            mp.setOnCompletionListener { it.release() }
            mp.setOnErrorListener { m, _, _ ->
                m.release()
                true
            }
            mp.prepareAsync()
        }
    }

    private fun showMeme() {
        val layer = fx ?: return
        val u = sp.getString("sub_meme", null) ?: return
        val img = ImageView(this)
        img.scaleType = ImageView.ScaleType.FIT_CENTER
        runCatching { img.setImageURI(Uri.parse(u)) }
        layer.addView(img, FrameLayout.LayoutParams(dp(240), dp(240), Gravity.CENTER))
        img.scaleX = 0.1f
        img.scaleY = 0.1f
        img.alpha = 0f
        img.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(450L).withEndAction {
            img.postDelayed({
                img.animate().alpha(0f).scaleX(1.4f).scaleY(1.4f).setDuration(500L).withEndAction { layer.removeView(img) }.start()
            }, 4000L)
        }.start()
    }

    // ---- voice (Hindi, English India, or device default) ----

    private fun ensureTts() {
        if (tts != null) {
            applyTtsLang()
            return
        }
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                // Not captured by the stream: only the streamer hears the reader.
                tts?.setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANCE_ACCESSIBILITY)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                applyTtsLang()
            }
        }
    }

    private fun applyTtsLang() {
        val t = tts ?: return
        val loc = when (sp.getInt("tts_lang", 0)) {
            0 -> Locale("hi", "IN")
            1 -> Locale("en", "IN")
            else -> Locale.getDefault()
        }
        val r = t.setLanguage(loc)
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            toast("This voice is not installed. Open Google Text-to-speech settings and download it.")
        }
        t.setSpeechRate(sp.getInt("tts_rate", 100) / 100f)
    }

    private fun setReadChat(on: Boolean) {
        readChat = on
        chipRead?.text = if (on) "💬 Reading: ON" else "💬 Read comments"
        if (on) ensureTts() else tts?.stop()
        updateChatJob()
    }

    private fun onComment(author: String, text: String) {
        if (sp.getBoolean("cmt_box", false)) addCommentLine(author, text)
        if (readChat) tts?.speak("$author, $text", TextToSpeech.QUEUE_ADD, null, null)
    }

    /** One chat loop feeds both the on-screen comment box and the voice reader. */
    private fun updateChatJob() {
        val want = readChat || sp.getBoolean("cmt_box", false)
        if (!want) {
            chatJob?.cancel()
            chatJob = null
            return
        }
        if (chatJob?.isActive == true) return
        chatJob = lifecycleScope.launch {
            var token: String? = null
            var first = true
            while (true) {
                val chat = Live.chatId
                if (chat == null) {
                    delay(5_000L)
                    continue
                }
                try {
                    val page = YouTubeApi.chat(this@OverlayService, chat, token)
                    token = page.next
                    if (!first) {
                        for (m in page.messages) onComment(m.author, m.text)
                    }
                    first = false
                    delay(maxOf(10_000L, page.waitMs))
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    delay(15_000L)
                }
            }
        }
    }

    // ---------------------------------------------------------------- shutdown

    private fun cleanup() {
        ui.removeCallbacks(hideBar)
        statsJob?.cancel()
        chatJob?.cancel()
        subJob?.cancel()
        tts?.stop()
        tts?.shutdown()
        tts = null
        clearTiles()
        removeCommentBox()
        brb?.let { v -> runCatching { wm.removeView(v) } }
        brb = null
        bubble?.let { v -> runCatching { wm.removeView(v) } }
        bar?.let { v -> runCatching { wm.removeView(v) } }
        fx?.let { v -> runCatching { wm.removeView(v) } }
        bubble = null
        bar = null
        fx = null
        running = false
        OverlayState.running.value = false
        OverlayState.tiles.value = 0
    }

    private fun shutdown() {
        cleanup()
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        cleanup()
        super.onDestroy()
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()
}
