package com.proeditz.livestudio

import android.content.pm.ActivityInfo
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.VideoView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import kotlinx.coroutines.launch

/**
 * Full-screen player for pre-recorded video mode. The app streams your screen, so whatever plays here
 * (your videos, looping forever) is what viewers see and hear. Tap the screen to show the controls.
 */
class PlayerActivity : AppCompatActivity() {

    private lateinit var video: VideoView
    private lateinit var overlay: LinearLayout
    private lateinit var status: TextView
    private var list: List<String> = emptyList()
    private var index = 0
    private var failures = 0
    private var dimmed = false
    private lateinit var dimBtn: Button
    private val handler = Handler(Looper.getMainLooper())
    private val hideOverlay = Runnable { overlay.visibility = View.GONE }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val portrait = intent.getBooleanExtra("portrait", false)
        requestedOrientation = if (portrait) ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        else ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        list = intent.getStringArrayListExtra("videos") ?: arrayListOf()
        dimmed = intent.getBooleanExtra("dim", false)

        WindowCompat.setDecorFitsSystemWindows(window, false)
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        controller.hide(WindowInsetsCompat.Type.systemBars())
        controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE

        val root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)

        video = VideoView(this)
        root.addView(video, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.CENTER))
        video.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_UP) showOverlay(false)
            true
        }

        overlay = LinearLayout(this)
        overlay.orientation = LinearLayout.HORIZONTAL
        overlay.gravity = Gravity.CENTER_VERTICAL
        overlay.setBackgroundColor(0xCC000000.toInt())
        overlay.setPadding(24, 16, 24, 16)

        status = TextView(this)
        status.setTextColor(Color.WHITE)
        status.textSize = 14f
        overlay.addView(status, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        val endBtn = Button(this)
        endBtn.text = "End stream"
        endBtn.setOnClickListener {
            StreamService.stop(this)
            finish()
        }
        overlay.addView(endBtn)

        dimBtn = Button(this)
        dimBtn.setOnClickListener {
            dimmed = !dimmed
            applyDim()
        }
        overlay.addView(dimBtn)

        val hideBtn = Button(this)
        hideBtn.text = "Hide player"
        hideBtn.setOnClickListener { finish() }
        overlay.addView(hideBtn)

        root.addView(overlay, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP))
        setContentView(root)

        applyDim()
        showOverlay(false)
        playCurrent()

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                Live.state.collect { s ->
                    status.text = s.text
                    if (s.phase == "error") showOverlay(true)
                    if (s.phase == "idle") finish()
                }
            }
        }
    }

    /** Dim mode: the screen is almost dark (saves battery) but still on, so the stream keeps getting the video. */
    private fun applyDim() {
        val lp = window.attributes
        lp.screenBrightness = if (dimmed) 0.01f else WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
        window.attributes = lp
        dimBtn.text = if (dimmed) "Brighten" else "Dim screen"
    }

    private fun showOverlay(keep: Boolean) {
        overlay.visibility = View.VISIBLE
        handler.removeCallbacks(hideOverlay)
        if (!keep) handler.postDelayed(hideOverlay, 4000)
    }

    private fun playCurrent() {
        if (list.isEmpty()) {
            finish()
            return
        }
        video.setVideoURI(Uri.parse(list[index % list.size]))
        video.setOnPreparedListener { mp ->
            if (list.size == 1) mp.isLooping = true   // one video: loop it forever
            video.start()
        }
        video.setOnCompletionListener {                // several videos: play them one after another, forever
            index++
            playCurrent()
        }
        video.setOnErrorListener { _, _, _ ->
            index++
            failures++
            if (failures <= list.size * 2) playCurrent()
            true
        }
    }

    override fun onDestroy() {
        handler.removeCallbacks(hideOverlay)
        video.stopPlayback()
        super.onDestroy()
    }
}
