package com.proeditz.livestudio

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.content.SharedPreferences
import android.content.pm.ActivityInfo
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.TextUtils
import android.text.style.StyleSpan
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.VideoView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * Plays your pre-recorded videos (looping) while the app streams the screen.
 * Layout 0 = the video fills the screen. Layout 1 = vertical stage: the video sits at the top, middle or bottom
 * of a 9:16 picture and two other slots (face cam, live comments, channel banner) fill the rest.
 * Tap the screen to show the controls.
 */
class PlayerActivity : AppCompatActivity() {

    private lateinit var video: VideoView
    private lateinit var overlay: LinearLayout
    private lateinit var status: TextView
    private lateinit var dimBtn: Button
    private lateinit var pauseBtn: Button
    private lateinit var ov: SharedPreferences
    private var list: List<String> = emptyList()
    private var index = 0
    private var failures = 0
    private var dimmed = false
    private var frozen = false
    private var commentList: LinearLayout? = null
    private var chatAcquired = false
    private val handler = Handler(Looper.getMainLooper())
    private val hideOverlay = Runnable { overlay.visibility = View.GONE }

    private val cmtColors = intArrayOf(
        Color.WHITE, 0xFF00F0FF.toInt(), 0xFFFF2BD6.toInt(), 0xFFFFE600.toInt(),
        0xFF39FF88.toInt(), 0xFFFF9A00.toInt(), 0xFF111111.toInt(), 0xFFFF4D4D.toInt(),
    )

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val stage = intent.getIntExtra("layout", 0) == 1
        val portrait = stage || intent.getBooleanExtra("portrait", false)
        requestedOrientation = if (portrait) ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        else ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        ov = getSharedPreferences("overlay", MODE_PRIVATE)
        list = intent.getStringArrayListExtra("videos") ?: arrayListOf()
        dimmed = intent.getBooleanExtra("dim", false)

        WindowCompat.setDecorFitsSystemWindows(window, false)
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        controller.hide(WindowInsetsCompat.Type.systemBars())
        controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE

        val root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)

        video = VideoView(this)
        video.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_UP) showOverlay(false)
            true
        }
        if (stage) {
            root.addView(buildStage(), FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        } else {
            root.addView(video, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.CENTER))
        }

        // Controls (tap the screen to show them)
        overlay = LinearLayout(this)
        overlay.orientation = LinearLayout.VERTICAL
        overlay.setBackgroundColor(0xCC000000.toInt())
        overlay.setPadding(dp(10), dp(30), dp(10), dp(8))

        status = TextView(this)
        status.setTextColor(Color.WHITE)
        status.textSize = 13f
        overlay.addView(status, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val buttons = LinearLayout(this)
        buttons.orientation = LinearLayout.HORIZONTAL

        pauseBtn = smallButton("Pause video") {
            frozen = !frozen
            if (frozen) video.pause() else video.start()
            pauseBtn.text = if (frozen) "Resume video" else "Pause video"
        }
        dimBtn = smallButton("Dim screen") {
            dimmed = !dimmed
            applyDim()
        }
        val hideBtn = smallButton("Hide player") { finish() }
        val endBtn = smallButton("End stream") {
            StreamService.stop(this)
            finish()
        }
        for (b in listOf(pauseBtn, dimBtn, hideBtn, endBtn)) {
            buttons.addView(b, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        overlay.addView(buttons)
        root.addView(overlay, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP))
        setContentView(root)

        applyDim()
        showOverlay(false)
        playCurrent()

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                Live.state.collect { s ->
                    status.text = s.text
                    if (s.phase == "error") showOverlay(true)
                    if (s.phase == "idle") finish()
                }
            }
        }
    }

    private fun smallButton(label: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.textSize = 11f
        b.isAllCaps = false
        b.setOnClickListener { onClick() }
        return b
    }

    // ---------------------------------------------------------------- vertical stage

    private fun stageBackground(): GradientDrawable = when (intent.getIntExtra("stageBg", 0)) {
        1 -> GradientDrawable().apply { setColor(Color.BLACK) }
        2 -> GradientDrawable().apply { setColor(0xFF081634.toInt()) }
        else -> GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(0xFF1B0B3A.toInt(), 0xFF0A2A5E.toInt(), 0xFF3A0B3A.toInt()),
        )
    }

    private fun buildStage(): View {
        val stage = LinearLayout(this)
        stage.orientation = LinearLayout.VERTICAL
        stage.background = stageBackground()
        stage.setOnClickListener { showOverlay(false) }

        val sw = resources.displayMetrics.widthPixels
        val videoFrame = FrameLayout(this)
        videoFrame.addView(video, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.CENTER))

        val slotA = slot(intent.getIntExtra("slotA", 0))
        val slotB = slot(intent.getIntExtra("slotB", 0))
        fun videoParams() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, sw * 9 / 16)
        fun slotParams() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)

        when (intent.getIntExtra("videoPos", 1)) {
            0 -> {                                   // video on top
                stage.addView(videoFrame, videoParams())
                stage.addView(slotA, slotParams())
                stage.addView(slotB, slotParams())
            }
            2 -> {                                   // video at the bottom
                stage.addView(slotA, slotParams())
                stage.addView(slotB, slotParams())
                stage.addView(videoFrame, videoParams())
            }
            else -> {                                // video in the middle
                stage.addView(slotA, slotParams())
                stage.addView(videoFrame, videoParams())
                stage.addView(slotB, slotParams())
            }
        }
        return stage
    }

    private fun slot(kind: Int): View = when (kind) {
        1 -> faceCamSlot()
        2 -> commentsSlot()
        3 -> bannerSlot()
        else -> View(this)
    }

    private fun faceCamSlot(): View {
        val frame = FrameLayout(this)
        val ip = intent.getStringExtra("camIp").orEmpty()
        val pin = intent.getStringExtra("camPin").orEmpty()
        if (ip.isEmpty() || pin.length != 6) {
            val t = TextView(this)
            t.text = "Face cam: type the camera phone address and PIN in the Studio tab, then start again."
            t.setTextColor(0xFFB8C4FF.toInt())
            t.gravity = Gravity.CENTER
            t.setPadding(dp(16), dp(16), dp(16), dp(16))
            frame.addView(t, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            return frame
        }
        val img = ImageView(this)
        img.scaleType = ImageView.ScaleType.FIT_CENTER
        frame.addView(img, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        lifecycleScope.launch(Dispatchers.IO) {
            RemoteCam.runClient(
                ip, pin,
                onFrame = { bmp -> img.post { img.setImageBitmap(bmp) } },
                onState = { },
                alive = { isActive },
            )
        }
        return frame
    }

    private fun glass(): GradientDrawable {
        val bgA = ov.getInt("cmt_bg", 45)
        val g = GradientDrawable()
        g.cornerRadius = dp(24).toFloat()
        if (ov.getBoolean("cmt_glass", true)) {
            g.orientation = GradientDrawable.Orientation.TL_BR
            g.colors = intArrayOf(
                Color.argb((bgA * 2.2f).toInt().coerceIn(0, 255), 255, 255, 255),
                Color.argb((bgA * 0.6f).toInt().coerceIn(0, 255), 180, 210, 255),
            )
            g.setStroke(dp(1), Color.argb((bgA * 2.5f).toInt().coerceIn(60, 255), 255, 255, 255))
        } else {
            g.setColor(Color.argb((bgA * 2.55f).toInt().coerceIn(0, 255), 10, 11, 20))
            g.setStroke(dp(1), Color.argb(90, 255, 255, 255))
        }
        return g
    }

    private fun commentsSlot(): View {
        val holder = FrameLayout(this)
        holder.setPadding(dp(14), dp(10), dp(14), dp(10))
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.gravity = Gravity.BOTTOM
        box.setPadding(dp(14), dp(10), dp(14), dp(10))
        box.background = glass()
        commentList = box

        val hint = TextView(this)
        hint.text = "Live comments appear here"
        hint.setTextColor(0xFFB8C4FF.toInt())
        hint.tag = "hint"
        box.addView(hint)

        holder.addView(box, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        ChatFeed.acquire(this)
        chatAcquired = true
        lifecycleScope.launch { ChatFeed.messages.collect { addComment(it.author, it.text) } }
        return holder
    }

    private fun addComment(author: String, text: String) {
        val box = commentList ?: return
        box.findViewWithTag<View>("hint")?.let { box.removeView(it) }
        val t = TextView(this)
        val sb = SpannableStringBuilder()
        sb.append(author)
        sb.setSpan(StyleSpan(Typeface.BOLD), 0, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        sb.append("  ").append(text)
        t.text = sb
        t.maxLines = 2
        t.ellipsize = TextUtils.TruncateAt.END
        t.setPadding(0, dp(2), 0, dp(2))
        val a = (ov.getInt("cmt_alpha", 100) * 2.55f).toInt().coerceIn(40, 255)
        val c = cmtColors[ov.getInt("cmt_color", 0).coerceIn(0, cmtColors.size - 1)]
        t.setTextColor(Color.argb(a, Color.red(c), Color.green(c), Color.blue(c)))
        t.textSize = ov.getInt("cmt_size", 16).toFloat()
        t.typeface = when (ov.getInt("cmt_font", 0)) {
            1 -> Typeface.SERIF
            2 -> Typeface.MONOSPACE
            3 -> Typeface.create("casual", Typeface.NORMAL)
            4 -> Typeface.create("cursive", Typeface.NORMAL)
            else -> Typeface.SANS_SERIF
        }
        box.addView(t, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        val max = ov.getInt("cmt_lines", 2) + 2
        while (box.childCount > max) box.removeViewAt(0)
        t.alpha = 0f
        t.animate().alpha(1f).setDuration(250L).start()
    }

    private fun bannerSlot(): View {
        val t = TextView(this)
        t.text = "🔴 LIVE\n" + intent.getStringExtra("channelName").orEmpty().ifBlank { "Pro Editz NEW" } +
            "\n\n👍 Like     🔔 Subscribe     🔗 Share"
        t.gravity = Gravity.CENTER
        t.setTextColor(Color.WHITE)
        t.textSize = 22f
        t.setTypeface(null, Typeface.BOLD)
        t.setShadowLayer(24f, 0f, 0f, 0xFF00F0FF.toInt())
        val a = ObjectAnimator.ofFloat(t, "alpha", 0.65f, 1f)
        a.duration = 1100L
        a.repeatCount = ValueAnimator.INFINITE
        a.repeatMode = ValueAnimator.REVERSE
        a.start()
        return t
    }

    // ---------------------------------------------------------------- playback

    /** Dim mode: the screen is almost dark (saves battery) but still on, so the stream keeps getting the video. */
    private fun applyDim() {
        val lp = window.attributes
        lp.screenBrightness = if (dimmed) 0.01f else WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
        window.attributes = lp
        dimBtn.text = if (dimmed) "Brighten" else "Dim screen"
    }

    private fun showOverlay(keep: Boolean) {
        overlay.visibility = View.VISIBLE
        handler.removeCallbacks(hideOverlay)
        if (!keep) handler.postDelayed(hideOverlay, 4000)
    }

    private fun playCurrent() {
        if (list.isEmpty()) {
            finish()
            return
        }
        video.setVideoURI(Uri.parse(list[index % list.size]))
        video.setOnPreparedListener { mp ->
            if (list.size == 1) mp.isLooping = true   // one video: loop it forever
            if (!frozen) video.start()
        }
        video.setOnCompletionListener {                // several videos: play them one after another, forever
            index++
            playCurrent()
        }
        video.setOnErrorListener { _, _, _ ->
            index++
            failures++
            if (failures <= list.size * 2) playCurrent()
            true
        }
    }

    override fun onDestroy() {
        handler.removeCallbacks(hideOverlay)
        if (chatAcquired) {
            ChatFeed.release()
            chatAcquired = false
        }
        video.stopPlayback()
        super.onDestroy()
    }
}
