package com.proeditz.livestudio

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.InputStream
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.concurrent.ArrayBlockingQueue
import java.util.concurrent.TimeUnit
import javax.crypto.Cipher
import javax.crypto.Mac
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/**
 * Link between the camera phone and the main phone over your own Wi-Fi or hotspot.
 * Every frame is encrypted with a key made from the 6-digit PIN (AES-256-GCM). A wrong PIN gets nothing,
 * and 5 wrong tries lock the camera phone for a minute. Only one main phone can connect at a time.
 */
object RemoteCam {
    const val PORT = 8765
    private val rnd = SecureRandom()

    fun key(pin: String): ByteArray {
        val spec = PBEKeySpec(pin.toCharArray(), "ProEditzCam1".toByteArray(), 20000, 256)
        return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
    }

    fun hello(key: ByteArray): String {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(key, "HmacSHA256"))
        return mac.doFinal("hello".toByteArray()).joinToString("") { "%02x".format(it) }
    }

    fun encrypt(key: ByteArray, plain: ByteArray): ByteArray {
        val iv = ByteArray(12)
        rnd.nextBytes(iv)
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(128, iv))
        return iv + c.doFinal(plain)
    }

    fun decrypt(key: ByteArray, blob: ByteArray): ByteArray {
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.DECRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(128, blob.copyOfRange(0, 12)))
        return c.doFinal(blob, 12, blob.size - 12)
    }

    /** Main phone side. Blocking: run it on a background thread. Reconnects by itself. */
    fun runClient(
        ip: String,
        pin: String,
        onFrame: (Bitmap) -> Unit,
        onState: (String) -> Unit,
        alive: () -> Boolean,
    ) {
        val key = key(pin)
        val helloLine = "HELLO ${hello(key)}\n"
        var failures = 0
        while (alive()) {
            var gotFrame = false
            try {
                Socket().use { s ->
                    s.connect(InetSocketAddress(ip, PORT), 4000)
                    s.tcpNoDelay = true
                    s.soTimeout = 6000
                    val out = s.getOutputStream()
                    out.write(helloLine.toByteArray())
                    out.flush()
                    val inp = DataInputStream(BufferedInputStream(s.getInputStream(), 1 shl 16))
                    while (alive()) {
                        val len = inp.readInt()
                        if (len <= 12 || len > 3_000_000) break
                        val buf = ByteArray(len)
                        inp.readFully(buf)
                        val plain = decrypt(key, buf)
                        val bmp = BitmapFactory.decodeByteArray(plain, 0, plain.size)
                        if (bmp != null) {
                            if (!gotFrame) {
                                gotFrame = true
                                onState("connected")
                            }
                            onFrame(bmp)
                        }
                    }
                }
            } catch (e: Exception) {
                // connection lost or wrong PIN: try again below
            }
            if (!alive()) return
            if (gotFrame) failures = 0 else failures++
            onState(if (failures >= 3) "failed" else "reconnecting")
            try {
                Thread.sleep(2500)
            } catch (e: InterruptedException) {
                return
            }
        }
    }
}

/** Camera phone side: waits for the main phone, checks the PIN, then sends encrypted frames. */
class CamServer(pin: String, private val onStatus: (String) -> Unit) {
    private val key = RemoteCam.key(pin)
    private val expect = RemoteCam.hello(key)
    private val queue = ArrayBlockingQueue<ByteArray>(1)
    private var server: ServerSocket? = null
    private var failures = 0
    private var lockedUntil = 0L

    @Volatile private var running = false

    @Volatile var hasClient = false
        private set

    fun start() {
        running = true
        Thread {
            try {
                val ss = ServerSocket(RemoteCam.PORT)
                server = ss
                onStatus("Waiting for the main phone")
                while (running) {
                    val s = (try { ss.accept() } catch (e: Exception) { null }) ?: break
                    handle(s)
                }
            } catch (e: Exception) {
                onStatus("Could not start: ${e.message}")
            }
        }.start()
    }

    /** Encrypts and queues one frame (only the newest frame is kept, so there is no lag build-up). */
    fun send(plain: ByteArray) {
        if (!hasClient) return
        queue.clear()
        queue.offer(RemoteCam.encrypt(key, plain))
    }

    fun stop() {
        running = false
        runCatching { server?.close() }
    }

    private fun readLine(inp: InputStream): String? {
        val sb = StringBuilder()
        while (sb.length < 200) {
            val c = inp.read()
            if (c < 0) return null
            if (c == '\n'.code) return sb.toString()
            sb.append(c.toChar())
        }
        return null
    }

    private fun handle(s: Socket) {
        try {
            s.soTimeout = 5000
            val line = readLine(s.getInputStream()) ?: return
            if (System.currentTimeMillis() < lockedUntil) return
            val ok = line.startsWith("HELLO ") &&
                MessageDigest.isEqual(line.substring(6).trim().toByteArray(), expect.toByteArray())
            if (!ok) {
                failures++
                if (failures >= 5) {
                    failures = 0
                    lockedUntil = System.currentTimeMillis() + 60_000L
                    onStatus("Too many wrong PINs. Locked for 1 minute.")
                }
                return
            }
            failures = 0
            s.soTimeout = 0
            s.tcpNoDelay = true
            val out = DataOutputStream(BufferedOutputStream(s.getOutputStream(), 1 shl 16))
            queue.clear()
            hasClient = true
            onStatus("Connected to the main phone")
            while (running && !s.isClosed) {
                val f = queue.poll(500, TimeUnit.MILLISECONDS) ?: continue
                out.writeInt(f.size)
                out.write(f)
                out.flush()
            }
        } catch (e: Exception) {
            // main phone left
        } finally {
            hasClient = false
            runCatching { s.close() }
            if (running) onStatus("Waiting for the main phone")
        }
    }
}
