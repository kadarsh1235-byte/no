package com.proeditz.livestudio

import java.util.Calendar

/**
 * Built-in SEO generator (offline, free, no chatbot). It reads what you type about your game or video,
 * pulls out the important keywords, and builds ranked titles, a description, tags and thumbnail text.
 */
object SeoEngine {

    data class Pack(
        val titles: List<Pair<String, Int>>,   // title to SEO score
        val description: String,
        val tags: String,
        val keywords: List<String>,
        val thumbTexts: List<String>,
    )

    private val stop = setOf(
        "the", "a", "an", "is", "are", "was", "were", "of", "to", "in", "on", "for", "with", "and", "or", "my", "i", "we",
        "you", "it", "this", "that", "how", "what", "about", "video", "game", "gameplay", "live", "stream",
        "ka", "ki", "ke", "hai", "hain", "me", "mein", "se", "ko", "aur", "ye", "yeh", "wo", "woh", "kya", "kaise",
        "mai", "main", "hum", "tum", "ek", "par", "pe", "liye", "bhi", "nahi", "ho", "kar", "kro", "karo",
        "की", "का", "के", "है", "में", "से", "को", "और", "यह", "वो", "एक", "पर",
    )

    private fun tokens(s: String): List<String> =
        s.lowercase().split(Regex("[^\\p{L}\\p{M}\\p{N}]+")).filter { it.isNotBlank() }

    private fun titleCase(s: String): String =
        s.trim().split(" ").filter { it.isNotBlank() }.joinToString(" ") { w -> w.replaceFirstChar { c -> c.uppercase() } }

    fun build(topicIn: String, about: String, lang: Int, kind: Int): Pack {
        val aboutClean = about.trim()
        val topic = topicIn.trim()
            .ifEmpty { aboutClean.split(" ").filter { it.isNotBlank() }.take(3).joinToString(" ") }
            .ifEmpty { "Live Stream" }
        val year = Calendar.getInstance().get(Calendar.YEAR)
        val topicWords = tokens(topic).toSet()

        val freq = linkedMapOf<String, Int>()
        for (w in tokens(aboutClean)) {
            if (w !in stop && w !in topicWords && w.length > 2) freq[w] = (freq[w] ?: 0) + 1
        }
        val extra = freq.entries.sortedByDescending { it.value }.map { it.key }.take(6)
        val keywords = (listOf(topic.lowercase()) + extra).distinct()
        val t = titleCase(topic)

        // lang: 0 English, 1 Hinglish, 2 Hindi.   kind: 0 Gaming, 1 Tutorial, 2 Entertainment, 3 Music
        val generic = when (lang) {
            1 -> listOf("$t LIVE 🔴 Aao Judo Stream Se", "🔴 LIVE: $t | Pro Editz NEW", "$t Live Stream - Chat Karo, Maza Lo", "$t Live $year | Jaldi Aao")
            2 -> listOf("$t लाइव 🔴 स्ट्रीम से जुड़ें", "🔴 लाइव: $t | Pro Editz NEW", "$t लाइव स्ट्रीम - चैट करें, मज़ा लें", "$t लाइव $year | जल्दी आओ")
            else -> listOf("$t LIVE 🔴 Come Join The Fun", "🔴 LIVE: $t | Pro Editz NEW", "$t Live Stream - Chat With Me Now", "$t Live $year | Join The Stream")
        }
        val special = when (lang) {
            1 -> listOf(
                listOf("$t Ka Sabse Bada Challenge LIVE 🔥", "$t Gameplay Live - Aao Kheleinge 🎮"),
                listOf("$t Kaise Khele? Live Tutorial $year", "$t Tips & Tricks Live - Seekho Aur Jeeto"),
                listOf("$t Live 🎉 Maza, Chat Aur Surprises", "Aaj $t Ke Saath Full Masti LIVE 😂"),
                listOf("🎵 $t Live Music Session", "$t Live - Apna Gaana Batao 🎶"),
            )
            2 -> listOf(
                listOf("$t का सबसे बड़ा चैलेंज लाइव 🔥", "$t गेमप्ले लाइव - आओ खेलें 🎮"),
                listOf("$t कैसे खेलें? लाइव ट्यूटोरियल $year", "$t टिप्स और ट्रिक्स लाइव"),
                listOf("$t लाइव 🎉 मज़ा, चैट और सरप्राइज़", "आज $t के साथ फुल मस्ती लाइव 😂"),
                listOf("🎵 $t लाइव म्यूज़िक", "$t लाइव - अपना गाना बताओ 🎶"),
            )
            else -> listOf(
                listOf("Ultimate $t Live Gameplay $year 🎮", "Can I Win? $t Challenge LIVE 🔥"),
                listOf("How To Master $t (LIVE Tutorial $year)", "$t Tips, Tricks & Q&A LIVE"),
                listOf("$t LIVE 🎉 Fun, Chat & Surprises", "Playing $t With You LIVE! 😂"),
                listOf("🎵 $t LIVE Music Session", "$t Live Jam - Request Your Song 🎶"),
            )
        }
        val titles = (special[kind.coerceIn(0, 3)] + generic)
            .map { it to score(it, topic) }
            .sortedByDescending { it.second }

        val sentence = aboutClean.split(Regex("[.!?\\n]")).firstOrNull().orEmpty().trim().take(140)
        val intro = if (sentence.isNotEmpty()) sentence else when (lang) {
            1 -> "Live stream mein aaj $t ka full maza."
            2 -> "आज लाइव स्ट्रीम में $t का पूरा मज़ा।"
            else -> "Join the live stream and chat with me."
        }
        val cta = when (lang) {
            1 -> "👍 Like karo, 🔔 subscribe karo aur bell dabao taaki koi stream miss na ho.\n💬 Live chat mein apne sawal poochho."
            2 -> "👍 लाइक करें, 🔔 सब्सक्राइब करें और बेल दबाएँ ताकि कोई स्ट्रीम मिस न हो।\n💬 लाइव चैट में अपने सवाल पूछें।"
            else -> "👍 Like, 🔔 subscribe and turn on the bell so you never miss a stream.\n💬 Chat with me live and ask your questions."
        }
        val inThis = if (extra.isNotEmpty()) "🔴 ${extra.take(4).joinToString(", ")}\n\n" else ""
        val hashtag = titleCase(topic).replace(" ", "")
        val description = "$t live stream on Pro Editz NEW. $intro\n\n$inThis$cta\n\n" +
            "Keywords: ${keywords.joinToString(", ")}\n\n#$hashtag #Live #ProEditzNEW"

        val tagList = (keywords + listOf(
            "$topic live", "$topic live stream", "$topic gameplay", "live stream", "Pro Editz NEW",
            if (lang == 0) "$topic live $year" else "$topic hindi live",
        ) + extra.map { "$topic $it" }).distinct()
        var tags = ""
        for (tg in tagList) {
            val next = if (tags.isEmpty()) tg else "$tags, $tg"
            if (next.length > 480) break
            tags = next
        }

        val short = t.split(" ").take(3).joinToString(" ").uppercase()
        val thumbs = listOf("$short LIVE", "LIVE NOW", "$short\nCHALLENGE").distinct()
        return Pack(titles, description, tags, keywords, thumbs)
    }

    private fun score(title: String, topic: String): Int {
        var s = 50
        val len = title.length
        s += if (len in 45..70) 18 else if (len in 30..44 || len in 71..85) 8 else 0
        val pos = title.lowercase().indexOf(topic.lowercase())
        s += if (pos in 0..25) 12 else if (pos >= 0) 5 else 0
        if (title.contains("live", ignoreCase = true) || title.contains("लाइव")) s += 8
        if (title.any { it.code > 0x2190 }) s += 4
        if (Regex("\\d{4}").containsMatchIn(title)) s += 3
        return s.coerceIn(40, 98)
    }
}
