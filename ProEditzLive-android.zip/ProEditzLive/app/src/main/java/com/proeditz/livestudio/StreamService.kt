package com.proeditz.livestudio

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.pedro.common.ConnectChecker
import com.pedro.encoder.input.sources.audio.InternalAudioSource
import com.pedro.encoder.input.sources.audio.MixAudioSource
import com.pedro.encoder.input.sources.video.ScreenSource
import com.pedro.library.generic.GenericStream
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Runs the whole live session in the background so it keeps streaming while you play:
 * YouTube broadcast -> screen capture + game sound + looping music -> RTMP -> go live.
 */
class StreamService : Service(), ConnectChecker {

    companion object {
        const val ACTION_START = "com.proeditz.livestudio.START"
        const val ACTION_STOP = "com.proeditz.livestudio.STOP"
        private const val CHANNEL = "live"
        private const val NOTIF_ID = 7

        fun start(ctx: Context, cfg: Config, resultCode: Int, data: Intent) {
            val i = Intent(ctx, StreamService::class.java).setAction(ACTION_START)
            cfg.writeTo(i)
            i.putExtra("resultCode", resultCode)
            i.putExtra("data", data)
            ContextCompat.startForegroundService(ctx, i)
        }

        fun stop(ctx: Context) {
            ctx.startService(Intent(ctx, StreamService::class.java).setAction(ACTION_STOP))
        }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val main = Handler(Looper.getMainLooper())
    private var job: Job? = null
    private var stream: GenericStream? = null
    private var projection: MediaProjection? = null
    private var player: MediaPlayer? = null
    private var broadcastId: String? = null
    private var streamId: String? = null
    private var stopping = false
    private var wentLive = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> end(null)
            ACTION_START -> if (job == null) begin(intent)
        }
        return START_NOT_STICKY
    }

    private fun begin(intent: Intent) {
        val cfg = Config.from(intent)
        val resultCode = intent.getIntExtra("resultCode", 0)
        @Suppress("DEPRECATION")
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33) intent.getParcelableExtra("data", Intent::class.java)
        else intent.getParcelableExtra("data")

        showForeground(cfg.mic)
        stopping = false
        wentLive = false

        job = scope.launch {
            try {
                if (data == null) throw IllegalStateException("Screen sharing permission was lost. Try again.")
                Live.set("creating", "Creating your YouTube broadcast...")
                val b = YouTubeApi.createBroadcast(applicationContext, cfg)
                broadcastId = b.id
                val s = YouTubeApi.createStream(applicationContext, cfg.title)
                streamId = s.id
                YouTubeApi.bind(applicationContext, b.id, s.id)

                // Best effort extras: category, tags, thumbnail
                launch { runCatching { YouTubeApi.updateVideo(applicationContext, b.id, cfg) } }
                cfg.thumbUri?.let { u -> launch { runCatching { YouTubeApi.setThumbnail(applicationContext, b.id, Uri.parse(u)) } } }

                Live.set("starting", "Starting the screen encoder...")
                startEncoder(cfg, resultCode, data, s.url)
                startMusic(cfg)

                Live.set("waiting", "Waiting for YouTube to receive your video...", "https://www.youtube.com/watch?v=${b.id}")
                monitor()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                end(Live.State("error", friendly(e)))
            }
        }
    }

    private fun startEncoder(cfg: Config, resultCode: Int, data: Intent, url: String) {
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val mp = mpm.getMediaProjection(resultCode, data)
            ?: throw IllegalStateException("Could not start screen capture.")
        mp.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                if (!stopping) end(Live.State("error", "Screen sharing was stopped."))
            }
        }, main)
        projection = mp

        // Game sound + background music come from "internal audio". Mic is optional.
        val audio = if (cfg.mic) MixAudioSource(mp) else InternalAudioSource(mp)
        val gs = GenericStream(applicationContext, this, ScreenSource(applicationContext, mp), audio)

        val h = cfg.height
        val w = (h * 16 / 9) / 2 * 2
        val (vw, vh) = if (cfg.portrait) h to w else w to h
        val ok = gs.prepareVideo(vw, vh, cfg.bitrateKbps * 1000) && gs.prepareAudio(44100, true, 128 * 1000)
        if (!ok) throw IllegalStateException("This phone could not set up the encoder. Try 720p.")
        stream = gs
        gs.startStream(url)
    }

    private fun startMusic(cfg: Config) {
        if (cfg.music.isEmpty()) return
        val list = if (cfg.shuffle) cfg.music.shuffled() else cfg.music
        val vol = (cfg.musicVolume / 100f).coerceIn(0f, 1.5f).coerceAtMost(1f)
        var idx = 0
        var failures = 0

        fun playNext() {
            if (stopping) return
            player?.release()
            val mp = MediaPlayer()
            player = mp
            try {
                mp.setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                mp.setDataSource(applicationContext, Uri.parse(list[idx % list.size]))
                idx++
                mp.setVolume(vol, vol)
                mp.setOnPreparedListener { it.start() }
                mp.setOnCompletionListener { main.post { playNext() } }   // endless loop of the playlist
                mp.setOnErrorListener { _, _, _ ->
                    if (++failures <= list.size * 2) main.post { playNext() }
                    true
                }
                mp.prepareAsync()
            } catch (e: Exception) {
                idx++
                if (++failures <= list.size * 2) main.post { playNext() }
            }
        }
        playNext()
    }

    private suspend fun monitor() {
        val ctx = applicationContext
        var tries = 0
        while (!stopping && tries < 60) {
            delay(4000)
            tries++
            try {
                if (YouTubeApi.streamStatus(ctx, streamId!!) == "active") {
                    when (YouTubeApi.broadcastStatus(ctx, broadcastId!!)) {
                        "live" -> {
                            wentLive = true
                            Live.set("live", "You are live. Switch to your game. Pull down the notification to end.")
                            return
                        }
                        "ready", "testing" -> runCatching { YouTubeApi.transition(ctx, broadcastId!!, "live") }
                        "complete", "revoked" -> {
                            end(Live.State("error", "YouTube ended this broadcast."))
                            return
                        }
                    }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (_: Exception) {
                // keep trying
            }
        }
        if (!stopping) end(Live.State("error", "YouTube did not receive video after 4 minutes. Check your internet and try again."))
    }

    /** Stops everything. [finalState] is the state to show afterwards (null = normal end). */
    private fun end(finalState: Live.State?) {
        if (stopping) return
        stopping = true
        if (finalState == null) Live.set("ending", "Ending your stream...")
        job?.cancel()
        scope.launch {
            runCatching { player?.release() }
            player = null
            runCatching { stream?.let { if (it.isStreaming) it.stopStream(); it.release() } }
            stream = null
            runCatching { projection?.stop() }
            projection = null
            broadcastId?.let { id ->
                runCatching { YouTubeApi.transition(applicationContext, id, "complete") }
                    .onFailure { runCatching { YouTubeApi.deleteBroadcast(applicationContext, id) } }
            }
            if (finalState != null) Live.state.value = finalState
            else Live.reset("idle", "Stream ended. The replay is on your channel.")
            job = null
            ServiceCompat.stopForeground(this@StreamService, ServiceCompat.STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    private fun friendly(e: Exception): String = when {
        e is YouTubeApi.YtException && e.reason == "liveStreamingNotEnabled" ->
            "Live streaming is not enabled on this channel yet. Turn it on at youtube.com/features (phone verification, up to 24 hours)."
        e is YouTubeApi.YtException && (e.reason == "quotaExceeded" || e.reason == "rateLimitExceeded") ->
            "Your YouTube API daily quota is used up. It resets at midnight Pacific time."
        else -> e.message ?: "Something went wrong."
    }

    private fun showForeground(mic: Boolean) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Live stream", NotificationManager.IMPORTANCE_LOW))
        val stopIntent = PendingIntent.getService(
            this, 1, Intent(this, StreamService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val open = PendingIntent.getActivity(
            this, 2, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE,
        )
        val n: Notification = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("Pro Editz NEW is streaming")
            .setContentText("Tap to open, or end the stream below")
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(0, "End stream", stopIntent)
            .build()
        var type = ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
        if (mic) type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
        ServiceCompat.startForeground(this, NOTIF_ID, n, type)
    }

    override fun onDestroy() {
        scope.cancel()
        runCatching { player?.release() }
        super.onDestroy()
    }

    // ---- RootEncoder connection callbacks ----
    override fun onConnectionStarted(url: String) {}
    override fun onConnectionSuccess() {}
    override fun onConnectionFailed(reason: String) {
        main.post { if (!stopping) end(Live.State("error", "Could not connect to YouTube: $reason")) }
    }
    override fun onNewBitrate(bitrate: Long) {}
    override fun onDisconnect() {}
    override fun onAuthError() {}
    override fun onAuthSuccess() {}
}
