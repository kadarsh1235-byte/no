package com.proeditz.livestudio

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.pedro.common.ConnectChecker
import com.pedro.encoder.input.sources.audio.InternalAudioSource
import com.pedro.encoder.input.sources.audio.MixAudioSource
import com.pedro.encoder.input.sources.video.ScreenSource
import com.pedro.library.generic.GenericStream
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Runs the whole live session in the background so it keeps streaming while you play:
 * YouTube broadcast -> screen capture + game sound + looping music -> RTMPS -> go live.
 * The stream key only ever lives in memory inside this service. It is never shown, saved or logged.
 */
class StreamService : Service(), ConnectChecker {

    companion object {
        const val ACTION_START = "com.proeditz.livestudio.START"
        const val ACTION_STOP = "com.proeditz.livestudio.STOP"
        private const val CHANNEL = "live"
        private const val NOTIF_ID = 7

        fun start(ctx: Context, cfg: Config, resultCode: Int, data: Intent) {
            val i = Intent(ctx, StreamService::class.java).setAction(ACTION_START)
            cfg.writeTo(i)
            i.putExtra("resultCode", resultCode)
            i.putExtra("data", data)
            ContextCompat.startForegroundService(ctx, i)
        }

        fun stop(ctx: Context) {
            ctx.startService(Intent(ctx, StreamService::class.java).setAction(ACTION_STOP))
        }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val main = Handler(Looper.getMainLooper())
    private val controlJobs = mutableListOf<Job>()
    private var job: Job? = null
    private var stream: GenericStream? = null
    private var projection: MediaProjection? = null
    private var player: MediaPlayer? = null
    private var broadcastId: String? = null
    private var streamId: String? = null
    private var stopping = false
    private var wentLive = false

    private var plainUrl: String? = null
    private var usedSecure = false
    private var micApplied = false
    private var studioApplied = false
    private var voice: VoiceProcessor? = null
    private var wake: PowerManager.WakeLock? = null
    private var currentUrl: String? = null
    private var reconnects = 0
    private var restarting = false
    private var lastRestart = 0L

    private var musicList: List<String> = emptyList()
    private var musicIdx = 0
    private var musicFailures = 0

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> end(null)
            ACTION_START -> if (job == null) begin(intent)
        }
        return START_NOT_STICKY
    }

    private fun begin(intent: Intent) {
        val cfg = Config.from(intent)
        val resultCode = intent.getIntExtra("resultCode", 0)
        @Suppress("DEPRECATION")
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33) intent.getParcelableExtra("data", Intent::class.java)
        else intent.getParcelableExtra("data")

        showForeground()
        stopping = false
        wentLive = false
        Live.musicVolume.value = cfg.musicVolume
        Live.micOn.value = cfg.mic
        studioApplied = Live.voiceStudio.value
        micApplied = cfg.mic && !studioApplied
        reconnects = 0
        restarting = false
        acquireWake()
        startControlCollectors()

        job = scope.launch {
            try {
                if (data == null) throw IllegalStateException("Screen sharing permission was lost. Try again.")
                Live.set("creating", "Creating your YouTube broadcast...")
                val b = YouTubeApi.createBroadcast(applicationContext, cfg)
                broadcastId = b.id
                Live.broadcastId = b.id
                Live.chatId = b.chatId
                val s = YouTubeApi.createStream(applicationContext, cfg.title)
                streamId = s.id
                YouTubeApi.bind(applicationContext, b.id, s.id)

                // Best effort extras: category, tags, thumbnail
                launch { runCatching { YouTubeApi.updateVideo(applicationContext, b.id, cfg) } }
                cfg.thumbUri?.let { u -> launch { runCatching { YouTubeApi.setThumbnail(applicationContext, b.id, Uri.parse(u)) } } }

                Live.set("starting", "Starting the screen encoder...")
                plainUrl = s.url
                usedSecure = s.secureUrl != null
                startEncoder(cfg, resultCode, data, s.secureUrl ?: s.url)
                startMusic(cfg)
                refreshAudioMode()

                Live.set("waiting", "Waiting for YouTube to receive your video...", "https://www.youtube.com/watch?v=${b.id}")
                monitor()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                end(Live.State("error", friendly(e)))
            }
        }
    }

    /** Settings changed in the app or the floating bar apply instantly. */
    private fun startControlCollectors() {
        controlJobs.forEach { it.cancel() }
        controlJobs.clear()
        controlJobs += scope.launch { Live.musicVolume.collect { applyMusicVolume() } }
        controlJobs += scope.launch { Live.micOn.collect { refreshAudioMode() } }
        controlJobs += scope.launch { Live.voiceStudio.collect { refreshAudioMode() } }
        controlJobs += scope.launch {
            Live.commands.collect { c ->
                when (c) {
                    "music_next" -> { musicIdx++; playTrack() }
                    "music_prev" -> {
                        if (musicList.isNotEmpty()) musicIdx = (musicIdx - 1 + musicList.size) % musicList.size
                        playTrack()
                    }
                    "music_toggle" -> toggleMusic()
                }
            }
        }
    }

    private fun startEncoder(cfg: Config, resultCode: Int, data: Intent, url: String) {
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val mp = mpm.getMediaProjection(resultCode, data)
            ?: throw IllegalStateException("Could not start screen capture.")
        mp.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                if (!stopping) end(Live.State("error", "Screen sharing was stopped."))
            }
        }, main)
        projection = mp

        // Game sound + background music come from "internal audio". Mic is optional and can change live.
        // With the voice studio on, the mic goes through the voice processor instead, so only game sound is captured here.
        val studio = Live.voiceStudio.value
        val audio = if (cfg.mic && !studio) MixAudioSource(mp) else InternalAudioSource(mp)
        val gs = GenericStream(applicationContext, this, ScreenSource(applicationContext, mp), audio)

        val h = cfg.height
        val w = (h * 16 / 9) / 2 * 2
        val (vw, vh) = if (cfg.portrait) h to w else w to h
        val ok = gs.prepareVideo(vw, vh, cfg.bitrateKbps * 1000) && gs.prepareAudio(44100, true, 128 * 1000, Live.voiceDenoise.value, Live.voiceDenoise.value)
        if (!ok) throw IllegalStateException("This phone could not set up the encoder. Try 720p.")
        stream = gs
        currentUrl = url
        gs.startStream(url)
    }

    /** Picks the right microphone path for the current settings. Called whenever mic or voice studio changes. */
    private fun refreshAudioMode() {
        val mp = projection ?: return
        val gs = stream ?: return
        val studio = Live.voiceStudio.value
        val mic = Live.micOn.value
        if (studio) {
            if (!studioApplied) {
                runCatching { gs.changeAudioSource(InternalAudioSource(mp)) }
                studioApplied = true
                micApplied = false
            }
            if (mic) {
                if (voice == null) {
                    val v = VoiceProcessor()
                    voice = v
                    v.start()
                }
            } else {
                voice?.stop()
                voice = null
            }
        } else {
            voice?.stop()
            voice = null
            if (studioApplied || mic != micApplied) {
                runCatching { gs.changeAudioSource(if (mic) MixAudioSource(mp) else InternalAudioSource(mp)) }
                micApplied = mic
                studioApplied = false
            }
        }
    }

    private fun acquireWake() {
        runCatching {
            val pm = getSystemService(PowerManager::class.java)
            val w = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "proeditz:stream")
            w.setReferenceCounted(false)
            w.acquire(12 * 60 * 60 * 1000L)
            wake = w
        }
    }

    private fun releaseWake() {
        runCatching { wake?.let { if (it.isHeld) it.release() } }
        wake = null
    }

    // ---------------------------------------------------------------- background music

    /** Real percentage: 40% plays at exactly 40% of full volume, for you and for the stream. */
    private fun musicVolumeF(): Float = (Live.musicVolume.value / 100f).coerceIn(0f, 1f)

    private fun applyMusicVolume() {
        val v = musicVolumeF()
        runCatching { player?.setVolume(v, v) }
    }

    private fun startMusic(cfg: Config) {
        if (cfg.music.isEmpty()) return
        musicList = if (cfg.shuffle) cfg.music.shuffled() else cfg.music
        musicIdx = 0
        musicFailures = 0
        playTrack()
    }

    private fun playTrack() {
        if (stopping || musicList.isEmpty()) return
        runCatching { player?.release() }
        val mp = MediaPlayer()
        player = mp
        try {
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            mp.setDataSource(applicationContext, Uri.parse(musicList[musicIdx % musicList.size]))
            val v = musicVolumeF()
            mp.setVolume(v, v)
            mp.setOnPreparedListener { it.start() }
            mp.setOnCompletionListener {                       // endless loop of the playlist
                main.post {
                    musicIdx++
                    playTrack()
                }
            }
            mp.setOnErrorListener { _, _, _ ->
                if (++musicFailures <= musicList.size * 2) main.post { musicIdx++; playTrack() }
                true
            }
            mp.prepareAsync()
        } catch (e: Exception) {
            if (++musicFailures <= musicList.size * 2) main.post { musicIdx++; playTrack() }
        }
    }

    private fun toggleMusic() {
        val p = player ?: return
        runCatching { if (p.isPlaying) p.pause() else p.start() }
    }

    // ---------------------------------------------------------------- monitoring and shutdown

    private suspend fun monitor() {
        val ctx = applicationContext
        var tries = 0
        while (!stopping && tries < 60) {
            delay(4000)
            tries++
            try {
                if (YouTubeApi.streamStatus(ctx, streamId!!) == "active") {
                    when (YouTubeApi.broadcastStatus(ctx, broadcastId!!)) {
                        "live" -> {
                            wentLive = true
                            Live.set("live", "You are live. Switch to your game. Use the neon bubble or the notification to control the stream.")
                            return
                        }
                        "ready", "testing" -> runCatching { YouTubeApi.transition(ctx, broadcastId!!, "live") }
                        "complete", "revoked" -> {
                            end(Live.State("error", "YouTube ended this broadcast."))
                            return
                        }
                    }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (_: Exception) {
                // keep trying
            }
        }
        if (!stopping) end(Live.State("error", "YouTube did not receive video after 4 minutes. Check your internet and try again."))
    }

    /** Stops everything. [finalState] is the state to show afterwards (null = normal end). */
    private fun end(finalState: Live.State?) {
        if (stopping) return
        stopping = true
        if (finalState == null) Live.set("ending", "Ending your stream...")
        job?.cancel()
        controlJobs.forEach { it.cancel() }
        controlJobs.clear()
        scope.launch {
            runCatching { voice?.stop() }
            voice = null
            releaseWake()
            runCatching { player?.release() }
            player = null
            runCatching { stream?.let { if (it.isStreaming) it.stopStream(); it.release() } }
            stream = null
            runCatching { projection?.stop() }
            projection = null
            broadcastId?.let { id ->
                runCatching { YouTubeApi.transition(applicationContext, id, "complete") }
                    .onFailure { runCatching { YouTubeApi.deleteBroadcast(applicationContext, id) } }
            }
            if (finalState != null) Live.state.value = finalState
            else Live.reset("idle", "Stream ended. The replay is on your channel.")
            job = null
            plainUrl = null
            Live.broadcastId = null
            Live.chatId = null
            ServiceCompat.stopForeground(this@StreamService, ServiceCompat.STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    private fun friendly(e: Exception): String = when {
        e is YouTubeApi.YtException && e.reason == "liveStreamingNotEnabled" ->
            "Live streaming is not enabled on this channel yet. Turn it on at youtube.com/features (phone verification, up to 24 hours)."
        e is YouTubeApi.YtException && (e.reason == "quotaExceeded" || e.reason == "rateLimitExceeded") ->
            "Your YouTube API daily quota is used up. It resets at midnight Pacific time."
        e is YouTubeApi.YtException && e.status == 401 ->
            "Google login expired. Tap Sign out, then Sign in with Google again. (" + e.message + ")"
        else -> e.message ?: "Something went wrong."
    }

    private fun showForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Live stream", NotificationManager.IMPORTANCE_LOW))
        val stopIntent = PendingIntent.getService(
            this, 1, Intent(this, StreamService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val open = PendingIntent.getActivity(
            this, 2, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE,
        )
        val n: Notification = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("Pro Editz NEW is streaming")
            .setContentText("Tap to open, or end the stream below")
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(0, "End stream", stopIntent)
            .build()
        // The microphone type is always included so the mic can be switched on during the stream.
        val type = ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
        ServiceCompat.startForeground(this, NOTIF_ID, n, type)
    }

    override fun onDestroy() {
        scope.cancel()
        runCatching { player?.release() }
        super.onDestroy()
    }

    // ---- RootEncoder connection callbacks ----
    override fun onConnectionStarted(url: String) {}

    override fun onConnectionSuccess() {
        main.post {
            reconnects = 0
            restarting = false
            if (wentLive && !stopping) Live.set("live", "Back online. You are live.")
        }
    }

    override fun onConnectionFailed(reason: String) {
        main.post {
            if (stopping) return@post
            val plain = plainUrl
            if (usedSecure && plain != null) {
                // Secure (RTMPS) failed on this network: try the standard link once.
                usedSecure = false
                currentUrl = plain
                runCatching { stream?.stopStream() }
                runCatching { stream?.startStream(plain) }
                return@post
            }
            scheduleReconnect(reason)
        }
    }

    /** Internet dropped? Keep trying for a long time, so an unattended stream comes back by itself. */
    private fun scheduleReconnect(why: String) {
        if (stopping || restarting) return
        if (System.currentTimeMillis() - lastRestart < 4000) return
        if (reconnects >= 40) {
            end(Live.State("error", "Lost the connection to YouTube. $why"))
            return
        }
        reconnects++
        restarting = true
        Live.set("waiting", "Connection lost. Reconnecting (try $reconnects)...")
        main.postDelayed({
            if (stopping) return@postDelayed
            val url = currentUrl
            if (url != null) {
                runCatching { stream?.stopStream() }
                runCatching { stream?.startStream(url) }
            }
            lastRestart = System.currentTimeMillis()
            restarting = false
        }, 5000L)
    }

    override fun onNewBitrate(bitrate: Long) {}
    override fun onDisconnect() {
        main.post { scheduleReconnect("The connection closed.") }
    }
    override fun onAuthError() {}
    override fun onAuthSuccess() {}
}
