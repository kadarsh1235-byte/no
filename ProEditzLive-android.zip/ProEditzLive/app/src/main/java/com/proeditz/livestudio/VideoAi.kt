package com.proeditz.livestudio

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import com.google.mlkit.vision.label.ImageLabeling
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.abs

/**
 * On-device AI (Google ML Kit, not a chatbot). It looks at pictures from your video or a screenshot:
 * it recognises what is in them (objects, scenes), reads text on the screen (game names, menus),
 * and picks the best looking frame for your thumbnail (sharp, bright, with faces). Nothing leaves your phone.
 */
object VideoAi {
    data class Result(val labels: List<String>, val words: List<String>, val bestFrame: Bitmap?)

    private fun sharpness(src: Bitmap): Float {
        val b = Bitmap.createScaledBitmap(src, 96, 54, true)
        val px = IntArray(96 * 54)
        b.getPixels(px, 0, 96, 0, 0, 96, 54)
        var sum = 0f
        var n = 0
        for (y in 0 until 54) {
            for (x in 1 until 96) {
                val a = px[y * 96 + x - 1]
                val c = px[y * 96 + x]
                val la = (a shr 16 and 255) * 0.3f + (a shr 8 and 255) * 0.59f + (a and 255) * 0.11f
                val lc = (c shr 16 and 255) * 0.3f + (c shr 8 and 255) * 0.59f + (c and 255) * 0.11f
                sum += abs(lc - la)
                n++
            }
        }
        return if (n == 0) 0f else sum / n / 40f
    }

    private fun words(text: String): List<String> =
        text.lowercase().split(Regex("[^\\p{L}\\p{N}]+"))
            .filter { it.length in 3..14 && !it.all { c -> c.isDigit() } && !SeoEngine.isStopWord(it) }

    /** Works on a video file or a picture. Runs away from the screen thread. */
    suspend fun analyze(ctx: Context, uri: Uri, onProgress: (String) -> Unit): Result = withContext(Dispatchers.Default) {
        val labeler = ImageLabeling.getClient(ImageLabelerOptions.DEFAULT_OPTIONS)
        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        val detector = FaceDetection.getClient(
            FaceDetectorOptions.Builder().setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST).build()
        )
        val labelScores = linkedMapOf<String, Float>()
        val wordCount = linkedMapOf<String, Int>()
        var best: Bitmap? = null

        fun look(frame: Bitmap): Float {
            val img = InputImage.fromBitmap(frame, 0)
            val labels = runCatching { Tasks.await(labeler.process(img)) }.getOrNull().orEmpty()
            for (l in labels) labelScores[l.text] = (labelScores[l.text] ?: 0f) + l.confidence
            val txt = runCatching { Tasks.await(recognizer.process(img)).text }.getOrNull().orEmpty()
            for (w in words(txt)) wordCount[w] = (wordCount[w] ?: 0) + 1
            val faces = runCatching { Tasks.await(detector.process(img)) }.getOrNull().orEmpty()
            return labels.sumOf { it.confidence.toDouble() }.toFloat() + faces.size * 0.6f + sharpness(frame)
        }

        val mmr = MediaMetadataRetriever()
        try {
            var isVideo = true
            try {
                mmr.setDataSource(ctx, uri)
            } catch (e: Exception) {
                isVideo = false
            }
            val durMs = if (isVideo) mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L else 0L
            if (isVideo && durMs > 0) {
                val n = 8
                var bestT = 0L
                var bestScore = -1f
                for (i in 0 until n) {
                    onProgress("AI is looking at picture ${i + 1} of $n...")
                    val t = durMs * 1000L * (i + 1) / (n + 1)
                    val small = mmr.getScaledFrameAtTime(t, MediaMetadataRetriever.OPTION_CLOSEST_SYNC, 480, 270) ?: continue
                    val score = look(small)
                    if (score > bestScore) {
                        bestScore = score
                        bestT = t
                    }
                }
                best = mmr.getFrameAtTime(bestT, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
            } else {
                onProgress("AI is looking at your picture...")
                val bmp = ctx.contentResolver.openInputStream(uri)?.use { android.graphics.BitmapFactory.decodeStream(it) }
                if (bmp != null) {
                    look(Bitmap.createScaledBitmap(bmp, 480, maxOf(1, bmp.height * 480 / maxOf(1, bmp.width)), true))
                    best = bmp
                }
            }
        } finally {
            runCatching { mmr.release() }
        }
        val labels = labelScores.entries.sortedByDescending { it.value }.map { it.key.lowercase() }.take(6)
        val wordsTop = wordCount.entries.sortedWith(compareByDescending<Map.Entry<String, Int>> { it.value }.thenByDescending { it.key.length })
            .map { it.key }.take(6)
        Result(labels, wordsTop, best)
    }
}
