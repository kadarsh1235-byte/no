package com.proeditz.livestudio

import android.annotation.SuppressLint
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.media.audiofx.AutomaticGainControl
import android.media.audiofx.NoiseSuppressor
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tanh

/**
 * Voice studio: records your microphone, cleans it (noise suppression, auto gain, noise gate),
 * changes the voice in real time, and plays the result as normal media audio.
 * The stream captures that audio together with your game sound, so viewers hear the changed voice.
 * Use headphones, otherwise the microphone hears the speaker.
 */
class VoiceProcessor {
    @Volatile private var running = false
    private var thread: Thread? = null

    fun start() {
        if (running) return
        running = true
        val t = Thread { loop() }
        t.priority = Thread.MAX_PRIORITY
        thread = t
        t.start()
    }

    fun stop() {
        running = false
        runCatching { thread?.join(600) }
        thread = null
    }

    /** Classic two-tap crossfading delay line: changes pitch without changing speed. */
    private class PitchShifter {
        private val size = 8192
        private val mask = size - 1
        private val buf = FloatArray(size)
        private var w = 0
        private var phase = 0f
        private val win = 1600f

        fun process(x: Float, ratio: Float): Float {
            buf[w] = x
            phase += (1f - ratio) / win
            if (phase >= 1f) phase -= 1f
            if (phase < 0f) phase += 1f
            val p2 = (phase + 0.5f) % 1f
            val y = read(phase * win) * g(phase) + read(p2 * win) * g(p2)
            w = (w + 1) and mask
            return y
        }

        private fun g(p: Float): Float = 0.5f - 0.5f * cos(2f * PI.toFloat() * p)

        private fun read(delay: Float): Float {
            var pos = w - delay
            if (pos < 0f) pos += size.toFloat()
            val i0 = pos.toInt() and mask
            val i1 = (i0 + 1) and mask
            val f = pos - pos.toInt()
            return buf[i0] * (1f - f) + buf[i1] * f
        }
    }

    @SuppressLint("MissingPermission")
    private fun loop() {
        val sr = 44100
        val block = 882                       // 20 ms
        var rec: AudioRecord? = null
        var track: AudioTrack? = null
        var ns: NoiseSuppressor? = null
        var agc: AutomaticGainControl? = null
        try {
            val minRec = AudioRecord.getMinBufferSize(sr, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val r = AudioRecord(
                MediaRecorder.AudioSource.MIC, sr, AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT, maxOf(minRec, block * 8),
            )
            rec = r
            val minTrack = AudioTrack.getMinBufferSize(sr, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val tr = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sr)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(maxOf(minTrack, block * 6))
                .setTransferMode(AudioTrack.MODE_STREAM)
                .setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
                .build()
            track = tr

            if (NoiseSuppressor.isAvailable()) ns = NoiseSuppressor.create(r.audioSessionId)
            if (AutomaticGainControl.isAvailable()) agc = AutomaticGainControl.create(r.audioSessionId)

            r.startRecording()
            tr.play()

            val pcm = ShortArray(block)
            val out = ShortArray(block)
            val shifter = PitchShifter()
            val echo = FloatArray(sr * 22 / 100)
            var echoPos = 0
            var gain = 0f
            var ringPhase = 0f
            var tremPhase = 0f
            var hp = 0f
            var hpPrev = 0f
            var blocks = 0
            val twoPi = 2f * PI.toFloat()

            while (running) {
                val n = r.read(pcm, 0, block)
                if (n <= 0) continue
                if (blocks++ % 20 == 0) {
                    val clean = Live.voiceDenoise.value
                    ns?.setEnabled(clean)
                    agc?.setEnabled(clean)
                }
                val mode = Live.voiceMode.value
                val gate = Live.voiceGate.value / 100f

                // Noise gate: when you are not speaking, quiet hiss and distant voices are cut.
                var sum = 0f
                for (i in 0 until n) {
                    val x = pcm[i] / 32768f
                    sum += x * x
                }
                val rms = sqrt(sum / n)
                val target = if (gate <= 0f || rms > gate * 0.04f) 1f else 0f

                for (i in 0 until n) {
                    val k = if (target > gain) 0.05f else 0.003f
                    gain += (target - gain) * k
                    val x = pcm[i] / 32768f * gain
                    val y: Float = when (mode) {
                        1 -> shifter.process(x, 0.78f)                                   // deep man
                        2 -> tanh(2.2f * shifter.process(x, 0.6f)) * 0.8f                // demon
                        3 -> shifter.process(x, 1.25f)                                   // woman
                        4 -> shifter.process(x, 1.55f)                                   // child
                        5 -> {                                                           // robot
                            ringPhase += twoPi * 55f / sr
                            if (ringPhase > twoPi) ringPhase -= twoPi
                            shifter.process(x, 0.92f) * (0.35f + 0.65f * sin(ringPhase))
                        }
                        6 -> {                                                           // alien
                            tremPhase += twoPi * 7f / sr
                            if (tremPhase > twoPi) tremPhase -= twoPi
                            shifter.process(x, 1.35f) * (0.7f + 0.3f * sin(tremPhase))
                        }
                        7 -> {                                                           // echo
                            val d = echo[echoPos]
                            echo[echoPos] = x + 0.4f * d
                            echoPos = (echoPos + 1) % echo.size
                            x + 0.45f * d
                        }
                        8 -> {                                                           // megaphone
                            hp = 0.97f * (hp + x - hpPrev)
                            hpPrev = x
                            tanh(4f * hp) * 0.7f
                        }
                        else -> x
                    }
                    out[i] = (y.coerceIn(-1f, 1f) * 32767f).toInt().toShort()
                }
                tr.write(out, 0, n)
            }
        } catch (e: Exception) {
            // microphone busy or not allowed: the voice studio simply stays off
        } finally {
            runCatching { ns?.release() }
            runCatching { agc?.release() }
            runCatching { rec?.stop() }
            runCatching { rec?.release() }
            runCatching { track?.stop() }
            runCatching { track?.release() }
        }
    }
}
