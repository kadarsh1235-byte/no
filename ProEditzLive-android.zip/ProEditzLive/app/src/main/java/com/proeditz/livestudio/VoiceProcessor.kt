package com.proeditz.livestudio

import android.annotation.SuppressLint
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.media.audiofx.AutomaticGainControl
import android.media.audiofx.NoiseSuppressor
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tanh

private val TWO_PI = 2f * PI.toFloat()

/**
 * Voice studio: records your microphone, cleans it (noise suppression, auto gain, noise gate),
 * changes the voice in real time with 23 effects, and plays the result as normal media audio.
 * The stream captures that audio together with your game sound, so viewers hear the changed voice.
 * Use headphones, otherwise the microphone hears the speaker.
 */
class VoiceProcessor {
    @Volatile private var running = false
    private var thread: Thread? = null

    fun start() {
        if (running) return
        running = true
        val t = Thread { loop() }
        t.priority = Thread.MAX_PRIORITY
        thread = t
        t.start()
    }

    /** Does not wait for the audio thread, so the screen never stalls. The thread cleans up by itself. */
    fun stop() {
        running = false
        thread = null
    }

    /** Two-tap crossfading delay line: changes pitch without changing speed. */
    private class PitchShifter {
        private val size = 8192
        private val mask = size - 1
        private val buf = FloatArray(size)
        private var w = 0
        private var phase = 0f
        private val win = 1600f

        fun process(x: Float, ratio: Float): Float {
            buf[w] = x
            phase += (1f - ratio) / win
            if (phase >= 1f) phase -= 1f
            if (phase < 0f) phase += 1f
            val p2 = (phase + 0.5f) % 1f
            val y = read(phase * win) * g(phase) + read(p2 * win) * g(p2)
            w = (w + 1) and mask
            return y
        }

        private fun g(p: Float): Float = 0.5f - 0.5f * cos(TWO_PI * p)

        private fun read(delay: Float): Float {
            var pos = w - delay
            if (pos < 0f) pos += size.toFloat()
            val i0 = pos.toInt() and mask
            val i1 = (i0 + 1) and mask
            val f = pos - pos.toInt()
            return buf[i0] * (1f - f) + buf[i1] * f
        }
    }

    private class Lp(private val a: Float) {
        private var y = 0f
        fun p(x: Float): Float {
            y += a * (x - y)
            return y
        }
    }

    private class Hp(private val a: Float) {
        private var y = 0f
        private var px = 0f
        fun p(x: Float): Float {
            y = a * (y + x - px)
            px = x
            return y
        }
    }

    /** Small room reverb: four comb filters and two all-pass filters. */
    private class Reverb {
        private val cl = intArrayOf(1116, 1188, 1277, 1356)
        private val cb = Array(4) { FloatArray(cl[it]) }
        private val ci = IntArray(4)
        private val al = intArrayOf(556, 441)
        private val ab = Array(2) { FloatArray(al[it]) }
        private val ai = IntArray(2)

        fun process(x: Float, fb: Float): Float {
            var s = 0f
            for (k in 0 until 4) {
                val o = cb[k][ci[k]]
                cb[k][ci[k]] = x * 0.3f + o * fb
                ci[k] = (ci[k] + 1) % cl[k]
                s += o
            }
            s *= 0.25f
            for (k in 0 until 2) {
                val bo = ab[k][ai[k]]
                val y = -s + bo
                ab[k][ai[k]] = s + bo * 0.5f
                ai[k] = (ai[k] + 1) % al[k]
                s = y
            }
            return s
        }
    }

    /** All the effect state lives here, so switching effects while you talk is smooth. */
    private class Effects(private val sr: Int) {
        private val p1 = PitchShifter()
        private val p2 = PitchShifter()
        private val rev = Reverb()
        private val echo = FloatArray(sr * 6 / 10)
        private var ep = 0
        private var ring = 0f
        private var trem = 0f
        private var vib = 0f
        private var hold = 0f
        private var holdN = 0
        private val lpTel = Lp(lpA(3000f))
        private val hpTel = Hp(hpA(300f))
        private val hpMega = Hp(hpA(500f))
        private val lpRadio = Lp(lpA(7000f))
        private val hpRadio = Hp(hpA(90f))
        private val lpWater = Lp(lpA(900f))
        private val lpOld = Lp(lpA(3500f))

        private fun lpA(fc: Float) = 1f - exp(-TWO_PI * fc / sr)
        private fun hpA(fc: Float) = 1f / (1f + TWO_PI * fc / sr)
        private fun adv(ph: Float, hz: Float): Float {
            var p = ph + TWO_PI * hz / sr
            if (p > TWO_PI) p -= TWO_PI
            return p
        }
        private fun tap(ms: Int): Float = echo[(ep - sr * ms / 1000 + echo.size) % echo.size]

        fun run(mode: Int, x: Float, custom: Float): Float {
            echo[ep] = x
            val y: Float = when (mode) {
                1 -> p1.process(x, 0.78f)                                                        // deep man
                2 -> tanh(2.2f * p1.process(x, 0.6f)) * 0.8f                                     // demon
                3 -> p1.process(x, 1.25f)                                                        // woman
                4 -> p1.process(x, 1.55f)                                                        // child
                5 -> {                                                                           // robot
                    ring = adv(ring, 55f)
                    p1.process(x, 0.92f) * (0.35f + 0.65f * sin(ring))
                }
                6 -> {                                                                           // alien
                    trem = adv(trem, 7f)
                    p1.process(x, 1.35f) * (0.7f + 0.3f * sin(trem))
                }
                7 -> {                                                                           // echo hall
                    val d = tap(220)
                    echo[ep] = x + 0.4f * d
                    x + 0.45f * d
                }
                8 -> tanh(4f * hpMega.p(x)) * 0.7f                                               // megaphone
                9 -> p1.process(x, 0.5f)                                                         // giant
                10 -> p1.process(x, 1.9f)                                                        // chipmunk
                11 -> {                                                                          // monster
                    ring = adv(ring, 30f)
                    tanh(2.5f * p1.process(x, 0.55f)) * (0.5f + 0.5f * sin(ring))
                }
                12 -> {                                                                          // ghost
                    trem = adv(trem, 4f)
                    val v = p1.process(x, 0.9f)
                    (v * 0.5f + rev.process(v, 0.84f) * 1.3f) * (0.75f + 0.25f * sin(trem))
                }
                13 -> lpTel.p(hpTel.p(x)) * 1.4f                                                 // telephone
                14 -> tanh(1.8f * lpRadio.p(hpRadio.p(x))) * 0.85f                               // radio host
                15 -> {                                                                          // underwater
                    vib = adv(vib, 5f)
                    lpWater.p(p1.process(x, 1f + 0.02f * sin(vib))) * 1.6f
                }
                16 -> rev.process(x, 0.88f) * 1.6f + x * 0.5f                                    // cave
                17 -> {                                                                          // stadium
                    val d = (tap(120) + tap(260) * 0.8f + tap(420) * 0.6f) / 2.4f
                    echo[ep] = x + 0.3f * d
                    x * 0.8f + d * 0.7f + rev.process(x, 0.8f) * 0.5f
                }
                18 -> (p1.process(x, 1.02f) + p2.process(x, 0.98f)) * 0.6f + x * 0.4f            // chorus
                19 -> {                                                                          // cartoon
                    vib = adv(vib, 6f)
                    p1.process(x, 1.7f * (1f + 0.04f * sin(vib)))
                }
                20 -> {                                                                          // old man
                    trem = adv(trem, 5f)
                    lpOld.p(p1.process(x, 0.88f)) * (0.8f + 0.2f * sin(trem)) * 1.3f
                }
                21 -> {                                                                          // 8-bit game
                    holdN++
                    if (holdN >= 6) {
                        holdN = 0
                        hold = (x * 16f).roundToInt() / 16f
                    }
                    hold
                }
                22 -> {                                                                          // singer vibrato
                    vib = adv(vib, 5.5f)
                    p1.process(x, 1f + 0.035f * sin(vib))
                }
                23 -> p1.process(x, custom)                                                      // custom pitch
                else -> x
            }
            ep = (ep + 1) % echo.size
            return y
        }
    }

    @SuppressLint("MissingPermission")
    private fun loop() {
        val sr = 44100
        val block = 882                       // 20 ms
        var rec: AudioRecord? = null
        var track: AudioTrack? = null
        var ns: NoiseSuppressor? = null
        var agc: AutomaticGainControl? = null
        try {
            val minRec = AudioRecord.getMinBufferSize(sr, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val r = AudioRecord(
                MediaRecorder.AudioSource.MIC, sr, AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT, maxOf(minRec, block * 8),
            )
            rec = r
            val minTrack = AudioTrack.getMinBufferSize(sr, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val tr = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sr)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(maxOf(minTrack, block * 6))
                .setTransferMode(AudioTrack.MODE_STREAM)
                .setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
                .build()
            track = tr

            if (NoiseSuppressor.isAvailable()) ns = NoiseSuppressor.create(r.audioSessionId)
            if (AutomaticGainControl.isAvailable()) agc = AutomaticGainControl.create(r.audioSessionId)

            r.startRecording()
            tr.play()

            val pcm = ShortArray(block)
            val out = ShortArray(block)
            val fx = Effects(sr)
            var gain = 0f
            var blocks = 0

            while (running) {
                val n = r.read(pcm, 0, block)
                if (n <= 0) continue
                if (blocks++ % 20 == 0) {
                    val clean = Live.voiceDenoise.value
                    ns?.setEnabled(clean)
                    agc?.setEnabled(clean)
                }
                val mode = Live.voiceMode.value
                val gate = Live.voiceGate.value / 100f
                val mic = Live.voiceGain.value / 100f
                val custom = (Live.voicePitch.value / 100f).coerceIn(0.5f, 2f)

                // Noise gate: when you are not speaking, quiet hiss and distant voices are cut.
                var sum = 0f
                for (i in 0 until n) {
                    val x = pcm[i] / 32768f
                    sum += x * x
                }
                val rms = sqrt(sum / n)
                val target = if (gate <= 0f || rms > gate * 0.04f) 1f else 0f

                for (i in 0 until n) {
                    val k = if (target > gain) 0.05f else 0.003f
                    gain += (target - gain) * k
                    val x = pcm[i] / 32768f * gain * mic
                    val y = fx.run(mode, x, custom)
                    out[i] = (y.coerceIn(-1f, 1f) * 32767f).toInt().toShort()
                }
                tr.write(out, 0, n)
            }
        } catch (e: Exception) {
            // microphone busy or not allowed: the voice studio simply stays off
        } finally {
            runCatching { ns?.release() }
            runCatching { agc?.release() }
            runCatching { rec?.stop() }
            runCatching { rec?.release() }
            runCatching { track?.stop() }
            runCatching { track?.release() }
        }
    }
}
