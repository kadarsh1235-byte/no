package com.proeditz.livestudio

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** YouTube Data API v3: broadcast, stream, bind, go live, end. */
object YouTubeApi {
    private const val BASE = "https://www.googleapis.com/youtube/v3"

    class YtException(message: String, val reason: String?, val status: Int) : Exception(message)
    data class Created(val id: String, val chatId: String?)
    data class Ingest(val id: String, val url: String)

    private suspend fun call(
        ctx: Context,
        path: String,
        method: String = "GET",
        query: Map<String, String?> = emptyMap(),
        body: JSONObject? = null,
    ): JSONObject = withContext(Dispatchers.IO) {
        val token = Auth.token(ctx)
        val qs = query.filterValues { !it.isNullOrEmpty() }.entries.joinToString("&") {
            "${URLEncoder.encode(it.key, "UTF-8")}=${URLEncoder.encode(it.value!!, "UTF-8")}"
        }
        val conn = URL("$BASE$path?$qs").openConnection() as HttpURLConnection
        try {
            conn.requestMethod = method
            conn.connectTimeout = 15000
            conn.readTimeout = 30000
            conn.setRequestProperty("Authorization", "Bearer $token")
            conn.setRequestProperty("Accept", "application/json")
            if (body != null) {
                conn.doOutput = true
                conn.setRequestProperty("Content-Type", "application/json")
                conn.outputStream.use { it.write(body.toString().toByteArray()) }
            } else if (method == "POST") {
                conn.doOutput = true
                conn.setFixedLengthStreamingMode(0)
            }
            val code = conn.responseCode
            val text = (if (code < 400) conn.inputStream else conn.errorStream)
                ?.bufferedReader()?.use { it.readText() }.orEmpty()
            val json = if (text.isBlank()) JSONObject() else JSONObject(text)
            if (code >= 400) {
                val err = json.optJSONObject("error")
                throw YtException(
                    err?.optString("message") ?: "YouTube error $code",
                    err?.optJSONArray("errors")?.optJSONObject(0)?.optString("reason"),
                    code,
                )
            }
            json
        } finally {
            conn.disconnect()
        }
    }

    suspend fun myChannel(ctx: Context): String? =
        call(ctx, "/channels", query = mapOf("part" to "snippet", "mine" to "true"))
            .optJSONArray("items")?.optJSONObject(0)?.optJSONObject("snippet")?.optString("title")

    suspend fun createBroadcast(ctx: Context, c: Config): Created {
        val iso = java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", java.util.Locale.US)
            .apply { timeZone = java.util.TimeZone.getTimeZone("UTC") }
            .format(java.util.Date(System.currentTimeMillis() + 10_000))
        val body = JSONObject()
            .put("snippet", JSONObject()
                .put("title", c.title.take(100))
                .put("description", c.description)
                .put("scheduledStartTime", iso))
            .put("status", JSONObject()
                .put("privacyStatus", c.privacy)
                .put("selfDeclaredMadeForKids", false))
            .put("contentDetails", JSONObject()
                .put("enableAutoStart", true)
                .put("enableAutoStop", true)
                .put("enableDvr", true)
                .put("enableEmbed", true)
                .put("latencyPreference", c.latency)
                .put("monitorStream", JSONObject().put("enableMonitorStream", false)))
        val r = call(ctx, "/liveBroadcasts", "POST", mapOf("part" to "snippet,contentDetails,status"), body)
        return Created(r.getString("id"), r.optJSONObject("snippet")?.optString("liveChatId"))
    }

    suspend fun createStream(ctx: Context, title: String): Ingest {
        val body = JSONObject()
            .put("snippet", JSONObject().put("title", title.take(100)))
            .put("cdn", JSONObject()
                .put("frameRate", "variable")
                .put("ingestionType", "rtmp")
                .put("resolution", "variable"))
            .put("contentDetails", JSONObject().put("isReusable", false))
        val r = call(ctx, "/liveStreams", "POST", mapOf("part" to "snippet,cdn,contentDetails,status"), body)
        val info = r.getJSONObject("cdn").getJSONObject("ingestionInfo")
        return Ingest(r.getString("id"), info.getString("ingestionAddress") + "/" + info.getString("streamName"))
    }

    suspend fun bind(ctx: Context, broadcastId: String, streamId: String) {
        call(ctx, "/liveBroadcasts/bind", "POST", mapOf("id" to broadcastId, "streamId" to streamId, "part" to "id,contentDetails"))
    }

    suspend fun transition(ctx: Context, broadcastId: String, status: String) {
        call(ctx, "/liveBroadcasts/transition", "POST", mapOf("id" to broadcastId, "broadcastStatus" to status, "part" to "status"))
    }

    suspend fun streamStatus(ctx: Context, streamId: String): String? =
        call(ctx, "/liveStreams", query = mapOf("part" to "status", "id" to streamId))
            .optJSONArray("items")?.optJSONObject(0)?.optJSONObject("status")?.optString("streamStatus")

    suspend fun broadcastStatus(ctx: Context, broadcastId: String): String? =
        call(ctx, "/liveBroadcasts", query = mapOf("part" to "status", "id" to broadcastId))
            .optJSONArray("items")?.optJSONObject(0)?.optJSONObject("status")?.optString("lifeCycleStatus")

    suspend fun deleteBroadcast(ctx: Context, broadcastId: String) {
        call(ctx, "/liveBroadcasts", "DELETE", mapOf("id" to broadcastId))
    }

    suspend fun updateVideo(ctx: Context, videoId: String, c: Config) {
        val tags = JSONArray()
        c.tags.split(",").map { it.trim() }.filter { it.isNotEmpty() }.forEach { tags.put(it) }
        val body = JSONObject().put("id", videoId).put("snippet", JSONObject()
            .put("title", c.title.take(100))
            .put("description", c.description)
            .put("categoryId", c.category)
            .put("tags", tags))
        call(ctx, "/videos", "PUT", mapOf("part" to "snippet"), body)
    }

    suspend fun setThumbnail(ctx: Context, videoId: String, uri: Uri) = withContext(Dispatchers.IO) {
        val bytes = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() }
            ?: throw IllegalStateException("Could not read the thumbnail image.")
        val type = ctx.contentResolver.getType(uri) ?: "image/jpeg"
        val conn = URL("https://www.googleapis.com/upload/youtube/v3/thumbnails/set?videoId=$videoId&uploadType=media")
            .openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.doOutput = true
            conn.setRequestProperty("Authorization", "Bearer ${Auth.token(ctx)}")
            conn.setRequestProperty("Content-Type", type)
            conn.outputStream.use { it.write(bytes) }
            val code = conn.responseCode
            if (code >= 400) throw YtException("Thumbnail upload failed ($code)", null, code)
            Unit
        } finally {
            conn.disconnect()
        }
    }
}
