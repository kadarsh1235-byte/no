@echo off
setlocal
set "APP_HOME=%~dp0"
set "JAR=%APP_HOME%gradle\wrapper\gradle-wrapper.jar"
if exist "%JAR%" (
  java -classpath "%JAR%" org.gradle.wrapper.GradleWrapperMain %*
  exit /b %ERRORLEVEL%
)
set "VERSION=8.9"
set "BASE=%USERPROFILE%\.gradle\proeditz-gradle"
set "DIR=%BASE%\gradle-%VERSION%"
if not exist "%DIR%\bin\gradle.bat" (
  if not exist "%BASE%" mkdir "%BASE%"
  echo Downloading Gradle %VERSION% (one time)...
  powershell -NoProfile -Command "[Net.ServicePointManager]::SecurityProtocol='Tls12'; Invoke-WebRequest 'https://services.gradle.org/distributions/gradle-%VERSION%-bin.zip' -OutFile '%BASE%\g.zip'; Expand-Archive -Force '%BASE%\g.zip' '%BASE%'"
  if errorlevel 1 (
    echo Download failed
    exit /b 1
  )
  del "%BASE%\g.zip"
)
call "%DIR%\bin\gradle.bat" %*
exit /b %ERRORLEVEL%
